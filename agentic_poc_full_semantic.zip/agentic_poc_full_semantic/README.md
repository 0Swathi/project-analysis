# Semantic SQL Workbench

Generate SQL from a user question and a semantic model.

The active codebase is split into:

- `backend/` for the FastAPI API, semantic-model normalization, prompt building, and LangChain-based SQL generation
- `frontend/` for the Streamlit workbench UI

This project is currently scoped to **SQL generation only**. It does not execute queries.

## What It Does

You provide:

- a semantic model JSON
- a natural-language question

The system returns:

- generated SQL
- a short explanation
- warnings and optional debug trace

## API Endpoints

- `GET /health`
- `POST /api/v1/semantic-models/validate`
- `POST /api/v1/sql/generate`

## Backend

### Requirements

- Python 3.11+
- an `OPENAI_API_KEY`

### Local install

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r backend/requirements.txt
```

### Run the API

```bash
uvicorn backend.app.api.main:app --host 0.0.0.0 --port 8000 --reload
```

The API will be available at:

- `http://localhost:8000`

## Streamlit UI

### Requirements

- Python 3.11+

### Local install

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r frontend/requirements.txt
```

### Run the workbench

```bash
set BACKEND_API_BASE_URL=http://localhost:8000
streamlit run frontend/app.py
```

The UI will be available at:

- `http://localhost:8501`

The Streamlit UI calls the backend API from Python, so you do not need Node.js or npm.

## Docker

### Configure environment

Copy `.env.example` to `.env` and set `OPENAI_API_KEY`.

The backend container reads runtime variables from `.env` via Compose `env_file`, so the OpenAI key and optional model overrides come from the file itself instead of shell interpolation.

### Build and run

```bash
docker compose up --build
```

Services:

- frontend: `http://localhost:8501`
- backend: `http://localhost:8000`

The frontend container uses `BACKEND_API_BASE_URL=http://backend:8000` so the Streamlit app can call the backend container directly.
The backend container is the running SQL-generation service. There is no separate long-lived agent process to start.

If you change `.env`, recreate the backend container so the new values are loaded:

```bash
docker compose up -d --force-recreate backend
```

## Semantic Model Behavior

- On first load, the Streamlit UI defaults to `archives/medicare-physician-4t-semantic.payload.json` when that file is available.
- In Docker, that default file is copied into the frontend image so the same behavior works in the container.
- If that file is not present, the UI falls back to a small built-in demo semantic model.
- Every semantic model uploaded through the Streamlit UI is saved into `data/semantic-models/`.
- In Docker, `./data/semantic-models` on your machine is mounted into the frontend container at `/app/data/semantic-models`, so uploads survive container restarts.
- The uploaded file is still sent to the backend as part of the generate request. The backend does not need to read the file from disk.

## Example Request

```json
{
  "question": "count providers by entity type code",
  "semantic_model": {
    "dataset_name": "demo_dataset",
    "tables": [
      {
        "table_name": "providers",
        "fields": [
          { "name": "entity_type_code", "description": "Entity type code" }
        ]
      }
    ]
  },
  "model": "gpt-5.4",
  "debug": true
}
```

## Tests

Run the current backend test suite with:

```bash
python -m unittest discover -s tests -v
```

## Current Layout

```text
backend/
  app/
    api/
    adapters/
    agents/
    core/
    llm/
    prompts/
    schemas/
    services/
    utils/
frontend/
tests/
```

## Notes

- The system accepts either `tables`-style or `entities`-style semantic model payloads and normalizes them internally.
- The Streamlit workbench is intended for manual testing and iteration.
- The scope is intentionally limited to generation. Query execution is not part of the current runtime path.
