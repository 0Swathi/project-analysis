from __future__ import annotations

import argparse
from pathlib import Path

from backend.app.schemas.requests import GenerateSqlRequest
from backend.app.services.sql_generation_service import SqlGenerationService
from backend.app.utils.cli import (
    DEFAULT_MODEL,
    auto_load_env,
    discover_payload_path,
    load_raw_payload,
    resolve_questions,
)


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate BigQuery SQL from natural language using the extracted backend service.",
    )
    parser.add_argument("--payload", help="Path to the semantic model payload JSON.")
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"OpenAI model to use. Default: {DEFAULT_MODEL}")
    parser.add_argument("--question", help="Single natural-language question to convert to SQL.")
    parser.add_argument(
        "--questions-file",
        help="Optional text file of questions to convert to SQL.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Include backend debug information in the CLI output.",
    )
    return parser


def main() -> None:
    args = build_arg_parser().parse_args()
    auto_load_env()

    payload_path = discover_payload_path(args.payload)
    raw_payload = load_raw_payload(payload_path)
    questions = resolve_questions(
        question=args.question,
        questions_file=Path(args.questions_file) if args.questions_file else None,
    )
    service = SqlGenerationService()

    for question in questions:
        print(f"\n{'-' * 70}")
        print(f"Q: {question}")
        print("-" * 70)
        result = service.generate(
            GenerateSqlRequest(
                question=question,
                semantic_model=raw_payload,
                model=args.model,
                debug=args.debug,
            )
        )
        print(result.sql)
        print(f"\n-> {result.explanation}")
        if result.warnings:
            print("\nWarnings:")
            for warning in result.warnings:
                print(f"- {warning}")
        if result.debug and result.debug.trace:
            print("\nDebug Trace:")
            for line in result.debug.trace:
                print(f"- {line}")


if __name__ == "__main__":
    main()
