from __future__ import annotations

import unittest

from backend.app.adapters.semantic_model_adapter import SemanticModelAdapter
from backend.app.core.errors import SemanticModelError


class SemanticModelAdapterTests(unittest.TestCase):
    def setUp(self) -> None:
        self.adapter = SemanticModelAdapter()

    def test_adapts_tables_payload(self) -> None:
        raw_model = {
            "dataset_name": "demo",
            "dataset_description": "Demo dataset",
            "domain": "healthcare_analytics",
            "selection_hints": ["Prefer provider master for provider counts."],
            "tables": [
                {
                    "table_name": "claims",
                    "table_description": "Claims fact table",
                    "canonical_entity": "claim_line",
                    "preferred_entity_key": "claim_id",
                    "grain_description": "One row per claim line.",
                    "source_of_truth_for": ["reimbursement", "utilization"],
                    "selection_hints": ["Use for payment and service analysis."],
                    "fields": [
                        {
                            "name": "amount",
                            "description": "Average amount",
                            "data_type": "STRING",
                            "selection_hints": ["Use for charge and payment metrics."],
                        },
                        {"name": "state", "description": "Provider state"},
                    ],
                },
                {
                    "table_name": "providers",
                    "fields": [{"name": "npi"}],
                },
            ],
        }

        adapted = self.adapter.adapt(raw_model)

        self.assertEqual(adapted.semantic_model.source_format, "tables")
        self.assertEqual(adapted.semantic_model.name, "demo")
        self.assertEqual(adapted.semantic_model.domain, "healthcare_analytics")
        self.assertEqual(len(adapted.semantic_model.tables), 2)
        self.assertEqual(adapted.semantic_model.tables[0].name, "claims")
        self.assertEqual(adapted.semantic_model.tables[0].fields[0].name, "amount")
        self.assertEqual(adapted.semantic_model.tables[0].preferred_entity_key, "claim_id")
        self.assertEqual(
            adapted.semantic_model.tables[0].source_of_truth_for,
            ["reimbursement", "utilization"],
        )
        self.assertEqual(
            adapted.semantic_model.tables[0].fields[0].selection_hints,
            ["Use for charge and payment metrics."],
        )
        self.assertIn(
            "Semantic model has multiple tables but no declared relationships.",
            adapted.warnings,
        )

    def test_adapts_entities_payload(self) -> None:
        raw_model = {
            "name": "legacy",
            "entities": [
                {
                    "name": "Claims",
                    "description": "Claims entity",
                    "base_table": {
                        "qualified_name": "project.dataset.claims",
                        "database": "project",
                        "schema": "dataset",
                        "table": "claims",
                    },
                    "fields": [
                        {"name": "amount", "description": "Average amount", "data_type": "STRING"},
                    ],
                }
            ],
        }

        adapted = self.adapter.adapt(raw_model)

        self.assertEqual(adapted.semantic_model.source_format, "entities")
        self.assertEqual(adapted.semantic_model.tables[0].qualified_name, "project.dataset.claims")
        self.assertEqual(adapted.semantic_model.tables[0].metadata["database"], "project")

    def test_rejects_unknown_payload_shape(self) -> None:
        with self.assertRaises(SemanticModelError):
            self.adapter.adapt({"foo": "bar"})
