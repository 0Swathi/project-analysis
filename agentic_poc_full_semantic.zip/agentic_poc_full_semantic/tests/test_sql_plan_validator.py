from __future__ import annotations

import unittest

from backend.app.schemas.asset_selection import AssetSelectionPlan, SelectedJoin, SelectedTable
from backend.app.services.sql_plan_validator import SqlPlanValidator


def _providers_plan(**kwargs) -> AssetSelectionPlan:
    return AssetSelectionPlan(
        base_table=kwargs.get("base_table", "project.dataset.providers"),
        selected_tables=kwargs.get("selected_tables", [
            SelectedTable(
                table_name="providers",
                qualified_name="project.dataset.providers",
                role="base",
                required_fields=["npi"],
            )
        ]),
        **{k: v for k, v in kwargs.items() if k not in ("base_table", "selected_tables")},
    )


def _claims_providers_plan(*, with_join: bool = False) -> AssetSelectionPlan:
    tables = [
        SelectedTable(
            table_name="claims",
            qualified_name="project.dataset.claims",
            role="base",
            required_fields=["npi", "claim_id"],
        ),
        SelectedTable(
            table_name="providers",
            qualified_name="project.dataset.providers",
            role="join",
            required_fields=["npi", "provider_id"],
        ),
    ]
    joins = [
        SelectedJoin(
            left_table_name="claims",
            left_field_name="npi",
            right_table_name="providers",
            right_field_name="npi",
            join_type="inner",
        )
    ] if with_join else []
    return AssetSelectionPlan(
        base_table="project.dataset.claims",
        selected_tables=tables,
        selected_joins=joins,
    )


class SqlPlanValidatorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.validator = SqlPlanValidator()

    # ------------------------------------------------------------------
    # Original test suite — updated for new referenced_tables format
    # (sqlglot returns unquoted, lowercased FQNs)
    # ------------------------------------------------------------------

    def test_validate_passes_for_single_allowed_base_table(self) -> None:
        plan = _providers_plan()
        result = self.validator.validate(
            sql="SELECT COUNT(DISTINCT p.npi) FROM `project.dataset.providers` AS p",
            asset_selection_plan=plan,
        )
        self.assertTrue(result.valid)
        self.assertEqual(result.violations, [])
        self.assertEqual(result.referenced_tables, ["project.dataset.providers"])

    def test_validate_fails_for_disallowed_table_reference(self) -> None:
        plan = _providers_plan()
        result = self.validator.validate(
            sql="SELECT COUNT(*) FROM `project.dataset.claims`",
            asset_selection_plan=plan,
        )
        self.assertFalse(result.valid)
        self.assertTrue(any("outside the grounded plan" in v for v in result.violations))

    def test_validate_fails_when_base_table_does_not_match(self) -> None:
        plan = _claims_providers_plan()
        result = self.validator.validate(
            sql=(
                "SELECT COUNT(*) "
                "FROM `project.dataset.claims` AS c "
                "JOIN `project.dataset.providers` AS p ON c.npi = p.npi"
            ),
            asset_selection_plan=plan,
        )
        # claims is the base table; this SQL starts from claims — should pass base check.
        # (The plan base_table is claims, and the SQL FROM is also claims.)
        self.assertTrue(result.valid)

    def test_validate_fails_when_sql_starts_from_wrong_base_table(self) -> None:
        plan = _claims_providers_plan()
        result = self.validator.validate(
            sql=(
                "SELECT COUNT(*) "
                "FROM `project.dataset.providers` AS p "
                "JOIN `project.dataset.claims` AS c ON p.npi = c.npi"
            ),
            asset_selection_plan=plan,
        )
        self.assertFalse(result.valid)
        self.assertTrue(any("different base table" in v for v in result.violations))

    def test_validate_passes_when_base_table_is_short_name_but_sql_uses_qualified_name(self) -> None:
        plan = AssetSelectionPlan(
            base_table="CMS_Specialty_Taxonomy_Crosswalk",
            selected_tables=[
                SelectedTable(
                    table_name="CMS_Specialty_Taxonomy_Crosswalk",
                    qualified_name=(
                        "vertex-poc-465616.medicarePhysicianFT."
                        "CMS_Specialty_Taxonomy_Crosswalk"
                    ),
                    role="base",
                    required_fields=["CMS_SPECIALTY_CODE"],
                )
            ],
            entity="CMS specialty",
            entity_key_field="CMS_SPECIALTY_CODE",
        )

        result = self.validator.validate(
            sql=(
                "WITH cleaned_specialties AS ("
                " SELECT SAFE_CAST(NULLIF(TRIM(CMS_SPECIALTY_CODE), '') AS FLOAT64)"
                " AS cms_specialty_code"
                " FROM `vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk`"
                ")"
                " SELECT COUNT(DISTINCT cms_specialty_code)"
                " FROM cleaned_specialties"
                " WHERE cms_specialty_code IS NOT NULL"
            ),
            asset_selection_plan=plan,
        )

        self.assertTrue(result.valid)
        self.assertEqual(result.violations, [])
        self.assertEqual(
            result.referenced_tables,
            ["vertex-poc-465616.medicarephysicianft.cms_specialty_taxonomy_crosswalk"],
        )

    def test_validate_passes_when_base_table_only_in_base_table_field_and_sql_uses_fqn(self) -> None:
        # Reproduces the case where base_table = "npidata" (short name only in base_table,
        # not in selected_tables), but the SQL generator correctly writes the FQN.
        # The validator must accept the FQN even though only the short name was registered.
        plan = AssetSelectionPlan(
            base_table="npidata",  # short name, NOT in selected_tables
            selected_tables=[
                SelectedTable(
                    table_name="MedicareBillingData",
                    qualified_name="project.dataset.MedicareBillingData",
                    role="join",
                )
            ],
            selected_joins=[
                SelectedJoin(
                    left_table_name="npidata",
                    left_field_name="npi",
                    right_table_name="MedicareBillingData",
                    right_field_name="Rndrng_NPI",
                )
            ],
        )

        result = self.validator.validate(
            sql=(
                "SELECT n.npi, b.Avg_Mdcr_Pymt_Amt"
                " FROM `project.dataset.npidata` AS n"
                " INNER JOIN `project.dataset.MedicareBillingData` AS b"
                " ON TRIM(n.npi) = TRIM(b.Rndrng_NPI)"
            ),
            asset_selection_plan=plan,
        )

        self.assertTrue(result.valid, result.violations)

    def test_validate_fails_for_join_condition_outside_grounded_plan(self) -> None:
        plan = _claims_providers_plan(with_join=True)

        result = self.validator.validate(
            sql=(
                "SELECT COUNT(*) "
                "FROM `project.dataset.claims` AS c "
                "JOIN `project.dataset.providers` AS p ON c.claim_id = p.provider_id"
            ),
            asset_selection_plan=plan,
        )

        self.assertFalse(result.valid)
        self.assertTrue(any("join condition outside the grounded plan" in v for v in result.violations))

    def test_validate_skips_when_no_grounded_plan_is_present(self) -> None:
        result = self.validator.validate(
            sql="SELECT COUNT(*) FROM `project.dataset.claims`",
            asset_selection_plan=None,
        )
        self.assertTrue(result.valid)
        self.assertEqual(result.violations, [])

    # ------------------------------------------------------------------
    # Bug fixes: WITH RECURSIVE
    # ------------------------------------------------------------------

    def test_validate_passes_for_with_recursive_cte(self) -> None:
        # BigQuery supports WITH RECURSIVE; use BQ dialect and backtick quoting.
        plan = AssetSelectionPlan(
            base_table="project.dataset.employees",
            selected_tables=[
                SelectedTable(
                    table_name="employees",
                    qualified_name="project.dataset.employees",
                    role="base",
                    required_fields=["id", "manager_id"],
                )
            ],
        )

        result = self.validator.validate(
            sql=(
                "WITH RECURSIVE org_tree AS ("
                " SELECT id, manager_id, 0 AS depth"
                " FROM `project.dataset.employees`"
                " WHERE manager_id IS NULL"
                " UNION ALL"
                " SELECT e.id, e.manager_id, ot.depth + 1"
                " FROM `project.dataset.employees` AS e"
                " JOIN org_tree AS ot ON e.manager_id = ot.id"
                ")"
                " SELECT * FROM org_tree"
            ),
            asset_selection_plan=plan,
            dialect="bigquery",
        )

        self.assertTrue(result.valid, result.violations)
        self.assertEqual(result.violations, [])

    # ------------------------------------------------------------------
    # Bug fixes: comma-separated (implicit cross) joins
    # ------------------------------------------------------------------

    def test_validate_passes_for_comma_join_with_allowed_tables(self) -> None:
        plan = _claims_providers_plan()

        result = self.validator.validate(
            sql=(
                "SELECT c.claim_id, p.npi "
                "FROM `project.dataset.claims` c, `project.dataset.providers` p "
                "WHERE c.npi = p.npi"
            ),
            asset_selection_plan=plan,
        )

        self.assertTrue(result.valid, result.violations)
        self.assertIn("project.dataset.claims", result.referenced_tables)
        self.assertIn("project.dataset.providers", result.referenced_tables)

    def test_validate_fails_for_comma_join_with_disallowed_table(self) -> None:
        plan = _providers_plan()

        result = self.validator.validate(
            sql=(
                "SELECT p.npi, c.claim_id "
                "FROM `project.dataset.providers` p, `project.dataset.claims` c "
                "WHERE p.npi = c.npi"
            ),
            asset_selection_plan=plan,
        )

        self.assertFalse(result.valid)
        self.assertTrue(any("outside the grounded plan" in v for v in result.violations))

    # ------------------------------------------------------------------
    # Bug fixes: SQL comments no longer cause false violations
    # ------------------------------------------------------------------

    def test_validate_passes_when_commented_out_table_is_not_in_plan(self) -> None:
        plan = _providers_plan()

        result = self.validator.validate(
            sql=(
                "-- Alternative: FROM project.dataset.claims\n"
                "SELECT COUNT(*) FROM `project.dataset.providers`\n"
                "/* another approach: JOIN project.dataset.claims c ON ... */"
            ),
            asset_selection_plan=plan,
        )

        self.assertTrue(result.valid, result.violations)
        self.assertEqual(result.violations, [])

    # ------------------------------------------------------------------
    # Bug fixes: USING joins are validated
    # ------------------------------------------------------------------

    def test_validate_passes_for_using_join_matching_plan(self) -> None:
        # Use plain postgres SQL (no backtick quoting) with unqualified table names.
        plan = AssetSelectionPlan(
            base_table="claims",
            selected_tables=[
                SelectedTable(table_name="claims", role="base", required_fields=["npi"]),
                SelectedTable(table_name="providers", role="join", required_fields=["npi"]),
            ],
            selected_joins=[
                SelectedJoin(
                    left_table_name="claims",
                    left_field_name="npi",
                    right_table_name="providers",
                    right_field_name="npi",
                    join_type="inner",
                )
            ],
        )

        result = self.validator.validate(
            sql="SELECT COUNT(*) FROM claims AS c JOIN providers AS p USING (npi)",
            asset_selection_plan=plan,
            dialect="postgres",
        )

        self.assertTrue(result.valid, result.violations)

    def test_validate_fails_for_using_join_outside_plan(self) -> None:
        # Allowed join is on npi; SQL joins on claim_id via USING — should fail.
        plan = AssetSelectionPlan(
            base_table="claims",
            selected_tables=[
                SelectedTable(table_name="claims", role="base", required_fields=["npi", "claim_id"]),
                SelectedTable(table_name="providers", role="join", required_fields=["npi"]),
            ],
            selected_joins=[
                SelectedJoin(
                    left_table_name="claims",
                    left_field_name="npi",
                    right_table_name="providers",
                    right_field_name="npi",
                    join_type="inner",
                )
            ],
        )

        result = self.validator.validate(
            sql="SELECT COUNT(*) FROM claims AS c JOIN providers AS p USING (claim_id)",
            asset_selection_plan=plan,
            dialect="postgres",
        )

        self.assertFalse(result.valid)
        self.assertTrue(any("join condition outside the grounded plan" in v for v in result.violations))

    # ------------------------------------------------------------------
    # Bug fixes: SQL keywords no longer captured as aliases
    # ------------------------------------------------------------------

    def test_validate_passes_for_inner_join_keyword_not_captured_as_alias(self) -> None:
        plan = _claims_providers_plan(with_join=True)

        result = self.validator.validate(
            sql=(
                "SELECT COUNT(*) "
                "FROM `project.dataset.claims` INNER JOIN `project.dataset.providers`"
                " ON `project.dataset.claims`.npi = `project.dataset.providers`.npi"
            ),
            asset_selection_plan=plan,
        )

        self.assertTrue(result.valid, result.violations)

    # ------------------------------------------------------------------
    # Multi-dialect support
    # ------------------------------------------------------------------

    def test_validate_passes_for_postgres_double_quote_identifiers(self) -> None:
        plan = AssetSelectionPlan(
            base_table="myschema.orders",
            selected_tables=[
                SelectedTable(
                    table_name="orders",
                    qualified_name="myschema.orders",
                    role="base",
                    required_fields=["order_id"],
                )
            ],
        )

        result = self.validator.validate(
            sql='SELECT COUNT(*) FROM "myschema"."orders"',
            asset_selection_plan=plan,
            dialect="postgres",
        )

        self.assertTrue(result.valid, result.violations)
        self.assertEqual(result.referenced_tables, ["myschema.orders"])

    def test_validate_passes_for_mssql_bracket_identifiers(self) -> None:
        plan = AssetSelectionPlan(
            base_table="dbo.Orders",
            selected_tables=[
                SelectedTable(
                    table_name="Orders",
                    qualified_name="dbo.Orders",
                    role="base",
                    required_fields=["OrderId"],
                )
            ],
        )

        result = self.validator.validate(
            sql="SELECT COUNT(*) FROM [dbo].[Orders]",
            asset_selection_plan=plan,
            dialect="tsql",
        )

        self.assertTrue(result.valid, result.violations)
        self.assertEqual(result.referenced_tables, ["dbo.orders"])

    def test_validate_fails_for_disallowed_table_in_mysql_dialect(self) -> None:
        plan = AssetSelectionPlan(
            base_table="orders",
            selected_tables=[
                SelectedTable(table_name="orders", role="base", required_fields=["id"])
            ],
        )

        result = self.validator.validate(
            sql="SELECT * FROM `orders` JOIN `payments` ON `orders`.id = `payments`.order_id",
            asset_selection_plan=plan,
            dialect="mysql",
        )

        self.assertFalse(result.valid)
        self.assertTrue(any("outside the grounded plan" in v for v in result.violations))

    # ------------------------------------------------------------------
    # Parse failure handling
    # ------------------------------------------------------------------

    def test_validate_returns_violation_for_unparseable_sql(self) -> None:
        plan = _providers_plan()

        result = self.validator.validate(
            sql="THIS IS NOT SQL @@@",
            asset_selection_plan=plan,
        )

        self.assertFalse(result.valid)
        self.assertTrue(any("could not be parsed" in v for v in result.violations))


if __name__ == "__main__":
    unittest.main()
