from __future__ import annotations

import unittest

from backend.app.schemas.asset_selection import AssetSelectionPlan, SelectedTable
from backend.app.prompts.sql_prompt_builder import SqlPromptBuilder
from backend.app.schemas.semantic_model import SemanticField, SemanticModel, SemanticTable
from backend.app.services.semantic_projection_service import SemanticProjectionService


class SqlPromptBuilderTests(unittest.TestCase):
    def setUp(self) -> None:
        self.builder = SqlPromptBuilder()
        self.projection_service = SemanticProjectionService()
        self.semantic_model = SemanticModel(
            name="demo",
            tables=[
                SemanticTable(
                    name="claims",
                    qualified_name="project.dataset.claims",
                    description="Claims fact table",
                    fields=[
                        SemanticField(name="Average Amount", data_type="STRING", kind="measure", description="Average payment amount"),
                        SemanticField(name="state", data_type="STRING", kind="dimension", description="Provider state"),
                    ],
                ),
                SemanticTable(
                    name="providers",
                    qualified_name="project.dataset.providers",
                    description="Providers table",
                    fields=[
                        SemanticField(name="state", data_type="STRING", kind="dimension", description="Provider state"),
                    ],
                ),
            ],
        )

    def test_build_system_prompt_includes_expected_sections(self) -> None:
        prompt = self.builder.build_system_prompt(self.semantic_model)

        self.assertIn("SEMANTIC MODEL:", prompt)
        self.assertIn("Table: project.dataset.claims", prompt)
        self.assertIn("Average Amount (STRING, measure) [needs-backtick-quoting, likely-numeric-STRING]", prompt)
        self.assertIn("POTENTIAL JOIN KEYS", prompt)
        self.assertIn("project.dataset.claims.STATE = project.dataset.providers.STATE", prompt)

    def test_build_context_report_returns_expected_shape(self) -> None:
        report = self.builder.build_context_report(
            semantic_model=self.semantic_model,
            question="count providers by state",
            model_name="gpt-5.4",
            context_window=self.builder.get_context_window("gpt-5.4"),
        )

        self.assertIsNotNone(report.context_window)
        self.assertGreater(report.semantic_layer_tokens or 0, 0)
        self.assertGreater(report.estimated_input_tokens or 0, 0)
        self.assertFalse(report.exceeds_window)

    def test_projected_model_produces_narrower_prompt_context(self) -> None:
        projected = self.projection_service.project(
            semantic_model=self.semantic_model,
            asset_selection_plan=AssetSelectionPlan(
                base_table="project.dataset.providers",
                selected_tables=[
                    SelectedTable(
                        table_name="providers",
                        qualified_name="project.dataset.providers",
                        role="base",
                        required_fields=["state"],
                    )
                ],
                entity="provider",
                entity_key_field="state",
                grain_description="One row per provider.",
            ),
        )

        prompt = self.builder.build_system_prompt(projected.semantic_model)

        self.assertIn("Table: project.dataset.providers", prompt)
        self.assertNotIn("Table: project.dataset.claims", prompt)

    def test_grounded_system_prompt_includes_data_plan_and_selected_asset_constraints(self) -> None:
        projected = self.projection_service.project(
            semantic_model=self.semantic_model,
            asset_selection_plan=AssetSelectionPlan(
                base_table="project.dataset.providers",
                selected_tables=[
                    SelectedTable(
                        table_name="providers",
                        qualified_name="project.dataset.providers",
                        role="base",
                        required_fields=["state"],
                    )
                ],
                entity="provider",
                entity_key_field="npi",
                grain_description="One row per provider.",
                measure_intent="count providers",
                rationale="Use the provider master table for provider counting.",
            ),
        )

        prompt = self.builder.build_system_prompt(
            projected.semantic_model,
            AssetSelectionPlan(
                base_table="project.dataset.providers",
                selected_tables=[
                    SelectedTable(
                        table_name="providers",
                        qualified_name="project.dataset.providers",
                        role="base",
                        required_fields=["state"],
                    )
                ],
                entity="provider",
                entity_key_field="npi",
                grain_description="One row per provider.",
                measure_intent="count providers",
                rationale="Use the provider master table for provider counting.",
            ),
        )

        self.assertIn("--- GROUNDED DATA PLAN ---", prompt)
        self.assertIn("- Base table: project.dataset.providers", prompt)
        self.assertIn("- Allowed tables: project.dataset.providers [base]", prompt)
        self.assertIn("- Entity key field: npi", prompt)
        self.assertIn("Treat the grounded data plan as authoritative.", prompt)
        self.assertNotIn("POTENTIAL JOIN KEYS", prompt)

    def test_grounded_prompt_resolves_base_table_to_qualified_name(self) -> None:
        # When base_table is a short name ("npidata") but the projected semantic model
        # has the qualified name ("dataset.schema.npidata"), the prompt must use the
        # qualified name so the SQL generator doesn't write unqualified FROM clauses.
        from backend.app.schemas.semantic_model import SemanticField
        model_with_qualified = SemanticModel(
            name="demo",
            tables=[
                SemanticTable(
                    name="npidata",
                    qualified_name="project.dataset.npidata",
                    fields=[SemanticField(name="npi")],
                )
            ],
        )
        plan = AssetSelectionPlan(
            base_table="npidata",  # short name — as the asset selector returns it
            selected_tables=[
                SelectedTable(
                    table_name="npidata",
                    qualified_name="project.dataset.npidata",
                    role="base",
                )
            ],
        )
        prompt = self.builder.build_system_prompt(model_with_qualified, plan)
        # Prompt must use the fully qualified name, not the short name
        self.assertIn("- Base table: project.dataset.npidata", prompt)
        self.assertNotIn("- Base table: npidata\n", prompt)

    def test_dimension_field_with_count_in_description_is_not_flagged_as_numeric(self) -> None:
        # CMS_SPECIALTY_CODE is STRING/dimension with "Count distinct values from this field"
        # in its description. "count" must NOT trigger [likely-numeric-STRING].
        model = SemanticModel(
            name="demo",
            tables=[
                SemanticTable(
                    name="CMS_Specialty_Taxonomy_Crosswalk",
                    qualified_name="project.dataset.CMS_Specialty_Taxonomy_Crosswalk",
                    fields=[
                        SemanticField(
                            name="CMS_SPECIALTY_CODE",
                            data_type="STRING",
                            kind="dimension",
                            description=(
                                "Canonical CMS Medicare specialty code. "
                                "Count distinct values from this field when the user asks "
                                "how many CMS specialties exist."
                            ),
                        )
                    ],
                )
            ],
        )
        plan = AssetSelectionPlan(
            base_table="CMS_Specialty_Taxonomy_Crosswalk",
            selected_tables=[
                SelectedTable(
                    table_name="CMS_Specialty_Taxonomy_Crosswalk",
                    qualified_name="project.dataset.CMS_Specialty_Taxonomy_Crosswalk",
                    role="base",
                )
            ],
        )
        prompt = self.builder.build_system_prompt(model, plan)
        # The static rule text always contains "likely-numeric-STRING"; check that the
        # CMS_SPECIALTY_CODE field line itself does NOT carry the flag.
        self.assertNotIn("CMS_SPECIALTY_CODE (STRING, dimension) [likely-numeric-STRING]", prompt)
        self.assertIn("CMS_SPECIALTY_CODE (STRING, dimension)", prompt)

    def test_measure_field_with_numeric_keyword_is_still_flagged(self) -> None:
        # A STRING measure with "total" in its name should still get the flag — kind=measure
        # is not excluded.
        model = SemanticModel(
            name="demo",
            tables=[
                SemanticTable(
                    name="payments",
                    qualified_name="project.dataset.payments",
                    fields=[
                        SemanticField(
                            name="total_amount_str",
                            data_type="STRING",
                            kind="measure",
                            description="Payment total stored as string",
                        )
                    ],
                )
            ],
        )
        plan = AssetSelectionPlan(
            base_table="payments",
            selected_tables=[
                SelectedTable(
                    table_name="payments",
                    qualified_name="project.dataset.payments",
                    role="base",
                )
            ],
        )
        prompt = self.builder.build_system_prompt(model, plan)
        self.assertIn("likely-numeric-STRING", prompt)

    def test_build_agent_input_mentions_grounded_plan_when_present(self) -> None:
        report = self.builder.build_context_report(
            semantic_model=self.semantic_model,
            asset_selection_plan=AssetSelectionPlan(
                base_table="project.dataset.providers",
                selected_tables=[
                    SelectedTable(
                        table_name="providers",
                        qualified_name="project.dataset.providers",
                        role="base",
                        required_fields=["state"],
                    )
                ],
                entity="provider",
            ),
            question="count providers by state",
            model_name="gpt-5.4",
            context_window=self.builder.get_context_window("gpt-5.4"),
        )

        agent_input = self.builder.build_agent_input(
            "count providers by state",
            report,
            AssetSelectionPlan(
                base_table="project.dataset.providers",
                selected_tables=[
                    SelectedTable(
                        table_name="providers",
                        qualified_name="project.dataset.providers",
                        role="base",
                        required_fields=["state"],
                    )
                ],
                entity="provider",
            ),
        )

        self.assertIn("The grounded data plan in the system prompt is authoritative.", agent_input)
