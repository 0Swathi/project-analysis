from __future__ import annotations

import unittest

from backend.app.memory.graph import MemoryWrapperGraph
from backend.app.memory.reasoner import FakeMemoryReasoner
from backend.app.memory.state import (
    ActiveContext,
    AnalyticalContext,
    AnalyticalCohort,
    AnalyticalFilter,
    AnalyticalMeasure,
    AnalyticalTimeScope,
    ContextSnapshot,
    GraphTurnState,
    SemanticChangeRequest,
    SessionMemory,
)
from backend.app.memory.store import InMemorySessionStore
from backend.app.schemas.asset_selection import (
    AssetSelectionPlan,
    SelectedTable,
    SelectionClarification,
)
from backend.app.schemas.responses import GenerateSqlResponse
from backend.app.services.asset_selector_service import FakeAssetSelectorService


class FakeSqlExecutor:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    def execute(
        self,
        *,
        question: str,
        semantic_model: dict,
        asset_selection_plan=None,
        prior_sql: str | None = None,
        semantic_change_request=None,
        model: str | None = None,
        debug: bool = False,
    ) -> GenerateSqlResponse:
        self.calls.append(
            {
                "question": question,
                "semantic_model": semantic_model,
                "asset_selection_plan": asset_selection_plan,
                "prior_sql": prior_sql,
                "semantic_change_request": semantic_change_request,
                "model": model,
                "debug": debug,
            }
        )
        return GenerateSqlResponse(
            sql=f"SELECT '{question}' AS resolved_question",
            explanation="Synthetic SQL response for testing.",
        )


class MemoryGraphTests(unittest.TestCase):
    def test_fresh_turn_runs_sql_and_initializes_active_context(self) -> None:
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "fresh",
                "resolved_question": "How many specialties are there?",
                "use_active_context": False,
                "state_patch": {
                    "topic_id": "topic-1",
                    "topic_label": "specialty analysis",
                    "tables": ["vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk"],
                    "metric": "count_distinct_specialty_code",
                },
            }
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(store=store, reasoner=reasoner, sql_executor=sql_executor)

        result = graph.invoke(
            GraphTurnState(
                session_id="session-1",
                incoming_message="How many specialties are there?",
                semantic_model={"dataset_name": "medicarePhysicianFT", "tables": [{"table_name": "CMS_Specialty_Taxonomy_Crosswalk"}]},
                semantic_model_key="default-model",
                model="gpt-5.4",
            )
        )

        self.assertEqual(result.turn_type, "fresh")
        self.assertEqual(len(sql_executor.calls), 1)
        self.assertIn("SELECT", result.assistant_message)

        saved_session = store.get("session-1")
        self.assertEqual(saved_session.turn_index, 1)
        self.assertEqual(saved_session.active_context.topic_label, "specialty analysis")
        self.assertEqual(saved_session.active_context.metric, "count_distinct_specialty_code")
        self.assertEqual(len(saved_session.messages), 2)

    def test_follow_up_uses_active_context_and_merges_patch(self) -> None:
        store = InMemorySessionStore()
        store.save(
            SessionMemory(
                session_id="session-2",
                semantic_model_key="default-model",
                turn_index=1,
                active_context=ActiveContext(
                    topic_id="topic-1",
                    topic_label="specialty analysis",
                    semantic_model_key="default-model",
                    dataset_name="medicarePhysicianFT",
                    tables=["vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk"],
                    metric="count_distinct_specialty_code",
                ),
            )
        )
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "follow_up",
                "resolved_question": "Count specialties by state.",
                "use_active_context": True,
                "state_patch": {
                    "dimensions": ["state"],
                    "filters": {"year": 2024},
                },
            }
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(store=store, reasoner=reasoner, sql_executor=sql_executor)

        graph.invoke(
            GraphTurnState(
                session_id="session-2",
                incoming_message="Now do it by state for 2024.",
                semantic_model={"dataset_name": "medicarePhysicianFT", "tables": [{"table_name": "CMS_Specialty_Taxonomy_Crosswalk"}]},
                semantic_model_key="default-model",
            )
        )

        saved_session = store.get("session-2")
        self.assertEqual(saved_session.turn_index, 2)
        self.assertEqual(saved_session.active_context.metric, "count_distinct_specialty_code")
        self.assertEqual(saved_session.active_context.dimensions, ["state"])
        self.assertEqual(saved_session.active_context.filters["year"], 2024)

    def test_historical_callback_reactivates_snapshot(self) -> None:
        store = InMemorySessionStore()
        store.save(
            SessionMemory(
                session_id="session-3",
                semantic_model_key="default-model",
                turn_index=4,
                active_context=ActiveContext(
                    topic_id="topic-current",
                    topic_label="specialty analysis",
                    tables=["vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk"],
                    metric="count_distinct_specialty_code",
                ),
                snapshots=[
                    ContextSnapshot(
                        snapshot_id="snap-1",
                        topic_id="topic-reimbursement",
                        topic_label="provider reimbursement",
                        tables=["vertex-poc-465616.medicarePhysicianFT.MedicareBillingData"],
                        metric="avg_medicare_payment",
                        dimensions=["state"],
                        filters={"year": 2023},
                    )
                ],
            )
        )
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "historical_callback",
                "resolved_question": "Return to the reimbursement analysis by state for 2024.",
                "use_active_context": False,
                "target_snapshot_id": "snap-1",
                "state_patch": {"filters": {"year": 2024}},
            }
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(store=store, reasoner=reasoner, sql_executor=sql_executor)

        graph.invoke(
            GraphTurnState(
                session_id="session-3",
                incoming_message="Go back to the reimbursement question, but for 2024.",
                semantic_model={"dataset_name": "medicarePhysicianFT", "tables": [{"table_name": "MedicareBillingData"}]},
                semantic_model_key="default-model",
            )
        )

        saved_session = store.get("session-3")
        self.assertEqual(saved_session.active_context.topic_label, "provider reimbursement")
        self.assertEqual(saved_session.active_context.metric, "avg_medicare_payment")
        self.assertEqual(saved_session.active_context.filters["year"], 2024)

    def test_clarification_path_skips_sql_execution(self) -> None:
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "historical_callback",
                "clarification_required": True,
                "clarification_question": "Which earlier analysis do you want to continue?",
                "state_patch": {},
            }
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(store=store, reasoner=reasoner, sql_executor=sql_executor)

        result = graph.invoke(
            GraphTurnState(
                session_id="session-4",
                incoming_message="Go back to that earlier one.",
                semantic_model={"dataset_name": "medicarePhysicianFT", "tables": [{"table_name": "CMS_Specialty_Taxonomy_Crosswalk"}]},
                semantic_model_key="default-model",
            )
        )

        self.assertEqual(result.assistant_message, "Which earlier analysis do you want to continue?")
        self.assertEqual(len(sql_executor.calls), 0)
        saved_session = store.get("session-4")
        self.assertEqual(saved_session.turn_index, 1)
        # No SQL result stored — clarification skipped SQL generation entirely.
        self.assertIsNone(saved_session.active_context.last_sql if saved_session.active_context else None)

    def test_semantic_model_switch_snapshots_old_active_context(self) -> None:
        store = InMemorySessionStore()
        store.save(
            SessionMemory(
                session_id="session-5",
                semantic_model_key="model-a",
                semantic_model_fingerprint="sha256:old",
                turn_index=2,
                active_context=ActiveContext(
                    topic_id="topic-1",
                    topic_label="specialty analysis",
                    semantic_model_key="model-a",
                    dataset_name="medicarePhysicianFT",
                    tables=["vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk"],
                    metric="count_distinct_specialty_code",
                    last_resolved_question="How many specialties are there?",
                    last_sql="SELECT ...",
                ),
            )
        )
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "fresh",
                "resolved_question": "How many providers are there?",
                "use_active_context": False,
                "state_patch": {
                    "topic_id": "topic-2",
                    "topic_label": "provider count",
                    "tables": ["vertex-poc-465616.medicarePhysicianFT.npidata"],
                    "metric": "count_distinct_provider",
                },
            }
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(store=store, reasoner=reasoner, sql_executor=sql_executor)

        graph.invoke(
            GraphTurnState(
                session_id="session-5",
                incoming_message="How many providers are there?",
                semantic_model={"dataset_name": "medicarePhysicianFT", "tables": [{"table_name": "npidata"}]},
                semantic_model_key="model-b",
            )
        )

        saved_session = store.get("session-5")
        self.assertEqual(saved_session.active_context.topic_label, "provider count")
        self.assertEqual(len(saved_session.snapshots), 1)
        self.assertEqual(saved_session.snapshots[0].topic_label, "specialty analysis")

    def test_follow_up_uses_grounded_analytical_context_without_relying_on_state_patch(self) -> None:
        store = InMemorySessionStore()
        store.save(
            SessionMemory(
                session_id="session-6",
                semantic_model_key="default-model",
                turn_index=1,
                active_context=ActiveContext(
                    topic_id="topic-provider-count",
                    topic_label="Texas providers",
                    semantic_model_key="default-model",
                    dataset_name="medicarePhysicianFT",
                    analytical_context=AnalyticalContext(
                        topic_summary="Count Texas providers.",
                        entity="provider",
                        entity_key="npi",
                        cohort=AnalyticalCohort(
                            filters=[
                                AnalyticalFilter(
                                    field_key="provider_state",
                                    operator="=",
                                    value="Texas",
                                )
                            ]
                        ),
                        measure=AnalyticalMeasure(
                            name="provider_count",
                            aggregation="count_distinct",
                            target="provider",
                        ),
                    ),
                ),
            )
        )
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "follow_up",
                "operation_type": "add_filter",
                "resolved_question": "How many Texas providers are oncologists?",
                "use_active_context": True,
                "semantic_change_request": {
                    "filters_to_add": [
                        {
                            "field_key": "provider_specialty",
                            "operator": "=",
                            "value": "oncologist",
                            "source_field": None,
                            "rationale": "The user is narrowing the provider cohort.",
                        }
                    ],
                    "filters_to_replace": [],
                    "grouping_changes": [],
                    "measure_change": None,
                    "time_scope_change": None,
                    "ranking_change": None,
                    "notes": "Refine the current provider cohort to oncologists.",
                },
                "state_patch": {},
            }
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(store=store, reasoner=reasoner, sql_executor=sql_executor)

        graph.invoke(
            GraphTurnState(
                session_id="session-6",
                incoming_message="How many of them are oncologists?",
                semantic_model={"dataset_name": "medicarePhysicianFT", "tables": [{"table_name": "npidata"}]},
                semantic_model_key="default-model",
            )
        )

        saved_session = store.get("session-6")
        self.assertEqual(saved_session.active_context.metric, "provider_count")
        self.assertEqual(
            saved_session.active_context.filters["provider_state"],
            "Texas",
        )
        self.assertEqual(
            saved_session.active_context.filters["provider_specialty"],
            "oncologist",
        )
        self.assertEqual(
            [filter_item.field_key for filter_item in saved_session.active_context.analytical_context.cohort.filters],
            ["provider_state", "provider_specialty"],
        )

    def test_historical_callback_uses_snapshot_analytical_context_without_state_patch(self) -> None:
        store = InMemorySessionStore()
        store.save(
            SessionMemory(
                session_id="session-7",
                semantic_model_key="default-model",
                turn_index=3,
                active_context=ActiveContext(
                    topic_id="topic-current",
                    topic_label="specialty analysis",
                    metric="count_distinct_specialty_code",
                ),
                snapshots=[
                    ContextSnapshot(
                        snapshot_id="snap-1",
                        topic_id="topic-reimbursement",
                        topic_label="provider reimbursement",
                        analytical_context=AnalyticalContext(
                            topic_summary="Highest reimbursement from Texas in 2020.",
                            entity="provider",
                            entity_key="Rndrng_NPI",
                            cohort=AnalyticalCohort(
                                filters=[
                                    AnalyticalFilter(
                                        field_key="provider_state",
                                        operator="=",
                                        value="Texas",
                                    )
                                ]
                            ),
                            measure=AnalyticalMeasure(
                                name="estimated_total_reimbursement",
                                aggregation="sum",
                                target="provider_reimbursement",
                            ),
                            time_scope=AnalyticalTimeScope(
                                field_key="service_year",
                                source_field="year",
                                year=2020,
                            ),
                        ),
                    )
                ],
            )
        )
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "historical_callback",
                "operation_type": "return_to_snapshot",
                "resolved_question": "Highest reimbursement from Texas in 2021?",
                "use_active_context": False,
                "target_snapshot_id": "snap-1",
                "semantic_change_request": {
                    "filters_to_add": [],
                    "filters_to_replace": [],
                    "grouping_changes": [],
                    "measure_change": None,
                    "time_scope_change": {
                        "field_key": "service_year",
                        "source_field": "year",
                        "year": 2021,
                        "start_year": None,
                        "end_year": None,
                        "description": "Move the reimbursement analysis to 2021.",
                    },
                    "ranking_change": None,
                    "notes": "Restore the reimbursement context and update its year.",
                },
                "state_patch": {},
            }
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(store=store, reasoner=reasoner, sql_executor=sql_executor)

        graph.invoke(
            GraphTurnState(
                session_id="session-7",
                incoming_message="Do the same for 2021.",
                semantic_model={"dataset_name": "medicarePhysicianFT", "tables": [{"table_name": "MedicareBillingData"}]},
                semantic_model_key="default-model",
            )
        )

        saved_session = store.get("session-7")
        self.assertEqual(saved_session.active_context.topic_label, "provider reimbursement")
        self.assertEqual(saved_session.active_context.metric, "estimated_total_reimbursement")
        self.assertEqual(saved_session.active_context.filters["provider_state"], "Texas")
        self.assertEqual(saved_session.active_context.filters["service_year"], 2021)
        self.assertEqual(saved_session.active_context.analytical_context.time_scope.year, 2021)

    def test_selector_projects_semantic_model_before_sql_and_persists_selected_assets(self) -> None:
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "fresh",
                "resolved_question": "How many providers are from Texas?",
                "use_active_context": False,
                "state_patch": {
                    "topic_id": "provider-count",
                    "topic_label": "Texas providers",
                },
            }
        )
        asset_selector = FakeAssetSelectorService(
            default_plan=AssetSelectionPlan(
                base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
                selected_tables=[
                    SelectedTable(
                        table_name="npidata",
                        qualified_name="vertex-poc-465616.medicarePhysicianFT.npidata",
                        role="base",
                        required_fields=[
                            "npi",
                            "provider_business_practice_location_address_state_name",
                        ],
                        rationale="Canonical provider master for provider identity and location.",
                    )
                ],
                entity="provider",
                entity_key_field="npi",
                grain_description="One row per provider record.",
                rationale="Provider counting by location should start from the provider master table.",
            )
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(
            store=store,
            reasoner=reasoner,
            sql_executor=sql_executor,
            asset_selector=asset_selector,
        )

        graph.invoke(
            GraphTurnState(
                session_id="session-8",
                incoming_message="How many providers are from Texas?",
                semantic_model={
                    "name": "medicarePhysicianFT",
                    "tables": [
                        {
                            "name": "npidata",
                            "qualified_name": "vertex-poc-465616.medicarePhysicianFT.npidata",
                            "fields": [
                                {"name": "npi"},
                                {"name": "provider_business_practice_location_address_state_name"},
                                {"name": "provider_first_name"},
                            ],
                        },
                        {
                            "name": "MedicareBillingData",
                            "qualified_name": "vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                            "fields": [
                                {"name": "Rndrng_NPI"},
                                {"name": "Avg_Mdcr_Pymt_Amt"},
                            ],
                        },
                    ],
                },
                semantic_model_key="default-model",
            )
        )

        self.assertEqual(len(asset_selector.calls), 1)
        self.assertEqual(len(sql_executor.calls), 1)
        projected_model = sql_executor.calls[0]["semantic_model"]
        self.assertEqual(
            [table["name"] for table in projected_model["tables"]],
            ["npidata"],
        )
        self.assertEqual(
            [field["name"] for field in projected_model["tables"][0]["fields"]],
            ["npi", "provider_business_practice_location_address_state_name"],
        )
        self.assertIsNotNone(sql_executor.calls[0]["asset_selection_plan"])
        self.assertEqual(
            sql_executor.calls[0]["asset_selection_plan"].base_table,
            "vertex-poc-465616.medicarePhysicianFT.npidata",
        )

        saved_session = store.get("session-8")
        self.assertEqual(
            saved_session.active_context.base_table,
            "vertex-poc-465616.medicarePhysicianFT.npidata",
        )
        self.assertEqual(
            saved_session.active_context.tables_used,
            ["vertex-poc-465616.medicarePhysicianFT.npidata"],
        )
        self.assertEqual(saved_session.active_context.entity_key_field, "npi")
        self.assertEqual(
            saved_session.active_context.grain_description,
            "One row per provider record.",
        )
        self.assertIsNotNone(saved_session.active_context.asset_selection_plan)
        self.assertEqual(
            saved_session.active_context.analytical_context.resolved_assets.base_table,
            "vertex-poc-465616.medicarePhysicianFT.npidata",
        )

    def test_selector_clarification_skips_sql_and_returns_selector_question(self) -> None:
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "follow_up",
                "resolved_question": "How many of them are specialists?",
                "use_active_context": True,
                "state_patch": {},
            }
        )
        asset_selector = FakeAssetSelectorService(
            default_plan=AssetSelectionPlan(
                clarification=SelectionClarification(
                    required=True,
                    question="Which provider group should I use for that follow-up?",
                    reason="The follow-up does not identify which earlier provider cohort it refers to.",
                )
            )
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(
            store=store,
            reasoner=reasoner,
            sql_executor=sql_executor,
            asset_selector=asset_selector,
        )

        result = graph.invoke(
            GraphTurnState(
                session_id="session-9",
                incoming_message="How many of them are specialists?",
                semantic_model={"dataset_name": "medicarePhysicianFT", "tables": [{"table_name": "npidata"}]},
                semantic_model_key="default-model",
            )
        )

        self.assertEqual(len(asset_selector.calls), 1)
        self.assertEqual(len(sql_executor.calls), 0)
        self.assertTrue(result.clarification_required)
        self.assertEqual(
            result.clarification_question,
            "Which provider group should I use for that follow-up?",
        )
        self.assertEqual(
            result.assistant_message,
            "Which provider group should I use for that follow-up?",
        )

    # ------------------------------------------------------------------ Gap #5

    def test_reasoner_failure_falls_back_to_fresh_turn_and_returns_sql(self) -> None:
        """If the memory reasoner raises, the turn must fall back to a fresh
        context (full schema, no memory reuse) and still return SQL."""

        class ExplodingReasoner:
            def reason(self, **_kwargs):
                raise RuntimeError("simulated reasoner API failure")

        store = InMemorySessionStore()
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(
            store=store,
            reasoner=ExplodingReasoner(),
            sql_executor=sql_executor,
        )

        result = graph.invoke(
            GraphTurnState(
                session_id="session-reasoner-fallback",
                incoming_message="How many specialties?",
                semantic_model={"tables": [{"table_name": "Specialties"}]},
                semantic_model_key="default-model",
            )
        )

        # The turn must succeed and produce SQL.
        self.assertIsNotNone(result.sql_result)
        self.assertEqual(len(sql_executor.calls), 1)
        # Fallback decision is fresh with no active context.
        self.assertEqual(result.turn_type, "fresh")
        self.assertFalse(result.clarification_required)
        # The SQL call must have received the full (unprojected) semantic model.
        self.assertIn("Specialties", str(sql_executor.calls[0]["semantic_model"]))

    def test_reasoner_failure_does_not_inherit_stale_context(self) -> None:
        """After a reasoner failure the turn is treated as fresh — the fallback
        must NOT pick up use_active_context=True or a snapshot target."""

        class ExplodingReasoner:
            def reason(self, **_kwargs):
                raise RuntimeError("simulated failure")

        store = InMemorySessionStore()
        store.save(
            SessionMemory(
                session_id="session-ctx-isolation",
                turn_index=2,
                active_context=ActiveContext(
                    topic_label="Old topic",
                    last_sql="SELECT 1",
                ),
            )
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(
            store=store,
            reasoner=ExplodingReasoner(),
            sql_executor=sql_executor,
        )

        result = graph.invoke(
            GraphTurnState(
                session_id="session-ctx-isolation",
                incoming_message="New unrelated question",
                semantic_model={"tables": [{"table_name": "T"}]},
            )
        )

        self.assertIsNotNone(result.sql_result)
        # Fallback must be fresh — prior_sql must NOT have been forwarded.
        self.assertIsNone(sql_executor.calls[0]["prior_sql"])

    def test_asset_selector_failure_falls_back_to_full_schema(self) -> None:
        """If the asset selector raises, the turn must fall back to a full-schema
        SQL generation and still return SQL — no 502 for the user."""

        class ExplodingSelector:
            def select_assets(self, **_kwargs):
                raise RuntimeError("simulated asset selector timeout")

        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "fresh",
                "resolved_question": "How many providers?",
                "use_active_context": False,
                "state_patch": {"topic_id": "t1", "topic_label": "providers"},
            }
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(
            store=store,
            reasoner=reasoner,
            sql_executor=sql_executor,
            asset_selector=ExplodingSelector(),
        )

        result = graph.invoke(
            GraphTurnState(
                session_id="session-selector-fallback",
                incoming_message="How many providers?",
                semantic_model={"tables": [{"table_name": "npidata"}, {"table_name": "billing"}]},
                semantic_model_key="default-model",
            )
        )

        self.assertIsNotNone(result.sql_result)
        self.assertEqual(len(sql_executor.calls), 1)
        self.assertFalse(result.clarification_required)
        # Fallback means both tables passed through (full schema, no projection).
        passed_tables = {t["table_name"] for t in sql_executor.calls[0]["semantic_model"]["tables"]}
        self.assertEqual(passed_tables, {"npidata", "billing"})

    def test_both_failures_together_still_produce_sql(self) -> None:
        """If both reasoner AND asset selector fail, the turn must still succeed
        via double fallback (fresh + full schema)."""

        class ExplodingReasoner:
            def reason(self, **_kwargs):
                raise RuntimeError("reasoner down")

        class ExplodingSelector:
            def select_assets(self, **_kwargs):
                raise RuntimeError("selector down")

        store = InMemorySessionStore()
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(
            store=store,
            reasoner=ExplodingReasoner(),
            sql_executor=sql_executor,
            asset_selector=ExplodingSelector(),
        )

        result = graph.invoke(
            GraphTurnState(
                session_id="session-double-fallback",
                incoming_message="How many specialties?",
                semantic_model={"tables": [{"table_name": "Specialties"}]},
            )
        )

        self.assertIsNotNone(result.sql_result)
        self.assertEqual(len(sql_executor.calls), 1)

    # ------------------------------------------------------------------ Gap #2


class SnapshotCandidateSelectionTests(unittest.TestCase):
    """Tests for _select_snapshot_candidates relevance-aware selection."""

    _SEMANTIC_MODEL = {"tables": [{"table_name": "T"}]}

    def _make_graph(self, snapshots: list, max_candidates: int = 3) -> tuple:
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "fresh",
                "resolved_question": "test",
                "use_active_context": False,
                "state_patch": {},
            }
        )
        sql_executor = FakeSqlExecutor()
        graph = MemoryWrapperGraph(
            store=store,
            reasoner=reasoner,
            sql_executor=sql_executor,
            max_candidate_snapshots=max_candidates,
        )
        store.save(
            SessionMemory(
                session_id="s",
                turn_index=len(snapshots),
                snapshots=snapshots,
            )
        )
        return graph, store

    def test_fewer_snapshots_than_cap_returns_all(self) -> None:
        snaps = [
            ContextSnapshot(snapshot_id="a", topic_label="alpha"),
            ContextSnapshot(snapshot_id="b", topic_label="beta"),
        ]
        graph, store = self._make_graph(snaps, max_candidates=5)
        result = graph.invoke(
            GraphTurnState(
                session_id="s",
                incoming_message="anything",
                semantic_model=self._SEMANTIC_MODEL,
            )
        )
        candidate_ids = {s.snapshot_id for s in result.candidate_snapshots}
        self.assertEqual(candidate_ids, {"a", "b"})

    def test_anchor_always_included_regardless_of_relevance(self) -> None:
        """The oldest snapshot must always appear in candidates even if its
        tokens don't overlap with the query at all."""
        snaps = [
            ContextSnapshot(snapshot_id="old", topic_label="unrelated zebra topic"),
            ContextSnapshot(snapshot_id="r1", topic_label="provider count Texas"),
            ContextSnapshot(snapshot_id="r2", topic_label="provider reimbursement"),
            ContextSnapshot(snapshot_id="r3", topic_label="provider state breakdown"),
            ContextSnapshot(snapshot_id="r4", topic_label="provider specialty filter"),
        ]
        graph, store = self._make_graph(snaps, max_candidates=3)
        result = graph.invoke(
            GraphTurnState(
                session_id="s",
                incoming_message="How many providers are there?",
                semantic_model=self._SEMANTIC_MODEL,
            )
        )
        candidate_ids = [s.snapshot_id for s in result.candidate_snapshots]
        self.assertIn("old", candidate_ids)
        self.assertEqual(len(candidate_ids), 3)

    def test_relevant_snapshot_selected_over_recency(self) -> None:
        """A middle snapshot that matches the query keywords must be preferred
        over a recent snapshot with no overlap."""
        snaps = [
            ContextSnapshot(snapshot_id="snap-1", topic_label="specialty taxonomy"),
            ContextSnapshot(snapshot_id="snap-2", topic_label="reimbursement Texas 2020"),
            ContextSnapshot(snapshot_id="snap-3", topic_label="provider specialty filter"),
            ContextSnapshot(snapshot_id="snap-4", topic_label="billing summary"),
            ContextSnapshot(snapshot_id="snap-5", topic_label="billing summary 2021"),
        ]
        graph, store = self._make_graph(snaps, max_candidates=3)
        result = graph.invoke(
            GraphTurnState(
                session_id="s",
                incoming_message="Go back to the reimbursement Texas analysis",
                semantic_model=self._SEMANTIC_MODEL,
            )
        )
        candidate_ids = [s.snapshot_id for s in result.candidate_snapshots]
        # snap-1 is anchor; snap-2 has max overlap with "reimbursement Texas"
        self.assertIn("snap-1", candidate_ids)
        self.assertIn("snap-2", candidate_ids)

    def test_no_snapshots_returns_empty(self) -> None:
        graph, store = self._make_graph([], max_candidates=3)
        result = graph.invoke(
            GraphTurnState(
                session_id="s",
                incoming_message="How many providers?",
                semantic_model=self._SEMANTIC_MODEL,
            )
        )
        self.assertEqual(result.candidate_snapshots, [])

    def test_cap_zero_returns_empty(self) -> None:
        snaps = [ContextSnapshot(snapshot_id="x", topic_label="something")]
        graph, store = self._make_graph(snaps, max_candidates=0)
        result = graph.invoke(
            GraphTurnState(
                session_id="s",
                incoming_message="something",
                semantic_model=self._SEMANTIC_MODEL,
            )
        )
        self.assertEqual(result.candidate_snapshots, [])

    def test_deduplication_within_candidates(self) -> None:
        """If two snapshots share the same snapshot_id, only one must appear."""
        snaps = [
            ContextSnapshot(snapshot_id="dup", topic_label="provider count"),
            ContextSnapshot(snapshot_id="dup", topic_label="provider count duplicate"),
            ContextSnapshot(snapshot_id="other", topic_label="specialty"),
        ]
        graph, store = self._make_graph(snaps, max_candidates=3)
        result = graph.invoke(
            GraphTurnState(
                session_id="s",
                incoming_message="provider count",
                semantic_model=self._SEMANTIC_MODEL,
            )
        )
        ids = [s.snapshot_id for s in result.candidate_snapshots]
        self.assertEqual(len(ids), len(set(ids)))

    def test_tokenizer_helpers_directly(self) -> None:
        from backend.app.memory.graph import _snapshot_tokens, _tokenize

        # Stop words stripped, alphanumeric only
        tokens = _tokenize("How many providers are there?")
        self.assertIn("providers", tokens)
        self.assertNotIn("how", tokens)
        self.assertNotIn("many", tokens)
        self.assertNotIn("are", tokens)
        self.assertNotIn("there", tokens)

        # Empty string is safe
        self.assertEqual(_tokenize(""), frozenset())

        # Snapshot tokens aggregate all text fields
        snap = ContextSnapshot(
            snapshot_id="x",
            topic_label="Texas providers",
            summary="Count providers in Texas",
            metric="provider_count",
        )
        st = _snapshot_tokens(snap)
        self.assertIn("texas", st)
        self.assertIn("providers", st)


if __name__ == "__main__":
    unittest.main()
