from __future__ import annotations

import unittest

from fastapi.testclient import TestClient

from backend.app.api.deps import get_chat_session_service
from backend.app.api.main import create_app
from backend.app.schemas.chat import ChatTurnResponse, MemoryDebugPayload
from backend.app.schemas.responses import GenerateSqlResponse, ResponseMetadata


class FakeChatSessionService:
    def __init__(self) -> None:
        self.calls = []

    def handle_turn(self, request):
        self.calls.append(request)
        if request.message == "Go back to that one.":
            return ChatTurnResponse(
                session_id=request.session_id,
                turn_type="historical_callback",
                assistant_message="Which earlier analysis do you want to continue?",
                clarification_required=True,
                clarification_question="Which earlier analysis do you want to continue?",
                sql_result=None,
                memory_debug=MemoryDebugPayload(
                    used_active_context=False,
                    used_snapshot_id=None,
                    candidate_snapshot_ids=["snap-1", "snap-2"],
                    semantic_model_changed=False,
                ),
            )

        return ChatTurnResponse(
            session_id=request.session_id,
            turn_type="fresh",
            assistant_message="Synthetic SQL response for testing.",
            resolved_question="How many specialties are there?",
            clarification_required=False,
            sql_result=GenerateSqlResponse(
                sql="SELECT COUNT(*) FROM specialties",
                explanation="Synthetic SQL response for testing.",
                metadata=ResponseMetadata(model="gpt-5.4", prompt_version="v1"),
            ),
            memory_debug=MemoryDebugPayload(
                used_active_context=False,
                used_snapshot_id=None,
                candidate_snapshot_ids=[],
                semantic_model_changed=False,
            ),
        )


class ApiChatTests(unittest.TestCase):
    def setUp(self) -> None:
        self.app = create_app()
        self.fake_service = FakeChatSessionService()
        self.app.dependency_overrides[get_chat_session_service] = lambda: self.fake_service
        self.client = TestClient(self.app)

    def tearDown(self) -> None:
        self.app.dependency_overrides.clear()

    def test_chat_turn_endpoint_returns_sql_response(self) -> None:
        response = self.client.post(
            "/api/v1/chat/turn",
            json={
                "session_id": "session-1",
                "message": "How many specialties are there?",
                "semantic_model": {
                    "tables": [
                        {
                            "table_name": "specialties",
                            "fields": [{"name": "specialty_code"}],
                        }
                    ]
                },
                "semantic_model_key": "default-model",
                "debug": True,
            },
        )

        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertEqual(body["status"], "ok")
        self.assertEqual(body["session_id"], "session-1")
        self.assertEqual(body["turn_type"], "fresh")
        self.assertEqual(body["resolved_question"], "How many specialties are there?")
        self.assertFalse(body["clarification_required"])
        self.assertEqual(body["sql_result"]["sql"], "SELECT COUNT(*) FROM specialties")
        self.assertEqual(body["memory_debug"]["candidate_snapshot_ids"], [])
        self.assertEqual(len(self.fake_service.calls), 1)

    def test_chat_turn_endpoint_returns_clarification_response(self) -> None:
        response = self.client.post(
            "/api/v1/chat/turn",
            json={
                "session_id": "session-2",
                "message": "Go back to that one.",
                "semantic_model": {
                    "tables": [
                        {
                            "table_name": "specialties",
                            "fields": [{"name": "specialty_code"}],
                        }
                    ]
                },
                "semantic_model_key": "default-model",
                "debug": True,
            },
        )

        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertTrue(body["clarification_required"])
        self.assertEqual(
            body["clarification_question"],
            "Which earlier analysis do you want to continue?",
        )
        self.assertIsNone(body["sql_result"])
        self.assertEqual(body["memory_debug"]["candidate_snapshot_ids"], ["snap-1", "snap-2"])

    def test_chat_turn_request_validation_error_shape(self) -> None:
        response = self.client.post(
            "/api/v1/chat/turn",
            json={
                "session_id": "session-3",
                "semantic_model": {"tables": []},
            },
        )

        self.assertEqual(response.status_code, 422)
        body = response.json()
        self.assertEqual(body["error"]["code"], "request_validation_error")
        self.assertIn("errors", body["error"]["details"])


if __name__ == "__main__":
    unittest.main()
