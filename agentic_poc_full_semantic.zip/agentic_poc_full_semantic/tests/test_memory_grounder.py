from __future__ import annotations

import unittest

from backend.app.memory.grounder import ContextGrounder
from backend.app.memory.memory_contracts import ContextPacket
from backend.app.memory.state import (
    AnalyticalContext,
    AnalyticalCohort,
    AnalyticalFilter,
    AnalyticalGrouping,
    AnalyticalMeasure,
    AnalyticalRanking,
    AnalyticalTimeScope,
    ResolvedAssets,
    SemanticChangeRequest,
)


class MemoryGrounderTests(unittest.TestCase):
    def test_add_filter_preserves_active_context_and_adds_new_constraint(self) -> None:
        grounder = ContextGrounder()
        active_context = AnalyticalContext(
            topic_summary="Texas provider count.",
            entity="provider",
            entity_key="npi",
            cohort=AnalyticalCohort(
                entity_scope="provider",
                filters=[
                    AnalyticalFilter(
                        field_key="provider_state",
                        operator="=",
                        value="Texas",
                    )
                ],
            ),
            measure=AnalyticalMeasure(
                name="provider_count",
                aggregation="count_distinct",
                target="provider",
            ),
            resolved_assets=ResolvedAssets(
                base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
                tables_used=["vertex-poc-465616.medicarePhysicianFT.npidata"],
                entity_key_field="npi",
            ),
        )
        packet = ContextPacket(
            session_id="session-1",
            user_message="How many of them are oncologists?",
            requested_operation="add_filter",
            turn_type="follow_up",
            active_context=active_context,
            locked_constraints=active_context,
            change_request=SemanticChangeRequest(
                filters_to_add=[
                    AnalyticalFilter(
                        field_key="provider_specialty",
                        operator="=",
                        value="oncologist",
                    )
                ],
                notes="Refine the current provider cohort to oncologists.",
            ),
        )

        result = grounder.ground(packet)

        self.assertTrue(result.preserved_active_context)
        self.assertEqual(result.grounded_context.entity, "provider")
        self.assertEqual(result.grounded_context.measure.name, "provider_count")
        self.assertEqual(
            [filter_item.field_key for filter_item in result.grounded_context.cohort.filters],
            ["provider_state", "provider_specialty"],
        )
        self.assertEqual(
            result.tables_used,
            ["vertex-poc-465616.medicarePhysicianFT.npidata"],
        )

    def test_return_to_snapshot_uses_snapshot_context_and_replaces_time_scope(self) -> None:
        grounder = ContextGrounder()
        snapshot_context = AnalyticalContext(
            topic_summary="Highest reimbursement from Texas in 2020.",
            entity="provider",
            entity_key="Rndrng_NPI",
            cohort=AnalyticalCohort(
                entity_scope="provider",
                filters=[
                    AnalyticalFilter(
                        field_key="provider_state",
                        operator="=",
                        value="Texas",
                    )
                ],
            ),
            measure=AnalyticalMeasure(
                name="estimated_total_reimbursement",
                aggregation="sum",
                target="provider_reimbursement",
            ),
            time_scope=AnalyticalTimeScope(
                field_key="service_year",
                source_field="year",
                year=2020,
            ),
            ranking=AnalyticalRanking(
                sort_by="estimated_total_reimbursement",
                direction="desc",
                limit=1,
            ),
        )
        packet = ContextPacket(
            session_id="session-2",
            user_message="Do the same for 2021.",
            requested_operation="return_to_snapshot",
            turn_type="historical_callback",
            snapshot_context=snapshot_context,
            target_snapshot_id="snap-1",
            change_request=SemanticChangeRequest(
                time_scope_change=AnalyticalTimeScope(
                    field_key="service_year",
                    source_field="year",
                    year=2021,
                ),
                notes="Restore the reimbursement context and move it to 2021.",
            ),
        )

        result = grounder.ground(packet)

        self.assertFalse(result.preserved_active_context)
        self.assertEqual(result.grounded_context.measure.name, "estimated_total_reimbursement")
        self.assertEqual(result.grounded_context.time_scope.year, 2021)
        self.assertEqual(result.grounded_context.ranking.limit, 1)

    def test_change_grouping_replaces_existing_groupings_and_keeps_measure(self) -> None:
        grounder = ContextGrounder()
        active_context = AnalyticalContext(
            topic_summary="Provider count by state.",
            entity="provider",
            entity_key="npi",
            cohort=AnalyticalCohort(
                filters=[
                    AnalyticalFilter(
                        field_key="provider_state",
                        operator="=",
                        value="Texas",
                    )
                ],
            ),
            measure=AnalyticalMeasure(
                name="provider_count",
                aggregation="count_distinct",
                target="provider",
            ),
            groupings=[AnalyticalGrouping(key="state")],
        )
        packet = ContextPacket(
            session_id="session-3",
            user_message="Break it down by specialty instead.",
            requested_operation="change_grouping",
            turn_type="follow_up",
            active_context=active_context,
            locked_constraints=active_context,
            change_request=SemanticChangeRequest(
                grouping_changes=[AnalyticalGrouping(key="provider_specialty")],
                notes="Replace the state grouping with specialty.",
            ),
        )

        result = grounder.ground(packet)

        self.assertTrue(result.preserved_active_context)
        self.assertEqual(
            [grouping.key for grouping in result.grounded_context.groupings],
            ["provider_specialty"],
        )
        self.assertEqual(result.grounded_context.measure.name, "provider_count")
        self.assertEqual(result.grounded_context.cohort.filters[0].value, "Texas")

    def test_switch_topic_starts_clean_context_without_reusing_locked_constraints(self) -> None:
        grounder = ContextGrounder()
        prior_context = AnalyticalContext(
            topic_summary="Texas provider count.",
            entity="provider",
            entity_key="npi",
            cohort=AnalyticalCohort(
                filters=[
                    AnalyticalFilter(
                        field_key="provider_state",
                        operator="=",
                        value="Texas",
                    )
                ],
            ),
            measure=AnalyticalMeasure(
                name="provider_count",
                aggregation="count_distinct",
                target="provider",
            ),
        )
        packet = ContextPacket(
            session_id="session-4",
            user_message="How many specialties are there by state?",
            requested_operation="switch_topic",
            turn_type="fresh",
            active_context=prior_context,
            locked_constraints=prior_context,
            change_request=SemanticChangeRequest(
                grouping_changes=[AnalyticalGrouping(key="state")],
                measure_change=AnalyticalMeasure(
                    name="specialty_count",
                    aggregation="count_distinct",
                    target="specialty",
                ),
                notes="Start a new specialty analysis by state.",
            ),
        )

        result = grounder.ground(packet)

        self.assertFalse(result.preserved_active_context)
        self.assertIsNone(result.grounded_context.entity)
        self.assertIsNone(result.grounded_context.cohort)
        self.assertEqual(result.grounded_context.measure.name, "specialty_count")
        self.assertEqual(
            [grouping.key for grouping in result.grounded_context.groupings],
            ["state"],
        )


if __name__ == "__main__":
    unittest.main()
