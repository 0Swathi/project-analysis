from __future__ import annotations

import unittest

from backend.app.core.errors import MemoryReasoningError
from backend.app.memory.reasoner import FakeMemoryReasoner, OpenAIMemoryReasoner
from backend.app.memory.state import (
    ActiveContext,
    AnalyticalFilter,
    AnalyticalGrouping,
    AnalyticalMeasure,
    AnalyticalTimeScope,
    ContextSnapshot,
    ConversationMessage,
    SessionMemory,
)
from backend.app.prompts.memory_reasoner_prompt import MemoryReasonerPromptBuilder


class StubResponsesClient:
    def __init__(self, payload):
        self.payload = payload
        self.calls: list[dict] = []

    def generate_json(self, **kwargs):
        self.calls.append(kwargs)
        return self.payload


class MemoryReasonerContractTests(unittest.TestCase):
    def test_prompt_builder_includes_message_active_context_and_snapshots(self) -> None:
        builder = MemoryReasonerPromptBuilder()
        session = SessionMemory(
            session_id="session-1",
            turn_index=3,
            rolling_summary="User is comparing specialty counts and reimbursement analyses.",
            messages=[
                ConversationMessage(role="user", content="How many specialties are there?", turn_index=1),
                ConversationMessage(role="assistant", content="There are 42 specialties.", turn_index=1),
            ],
            active_context=ActiveContext(
                topic_id="topic-1",
                topic_label="specialty analysis",
                dataset_name="medicarePhysicianFT",
                tables=["vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk"],
                metric="count_distinct_specialty_code",
            ),
        )
        snapshots = [
            ContextSnapshot(
                snapshot_id="snap-1",
                topic_label="provider reimbursement",
                summary="Average reimbursement by state for 2024.",
            )
        ]

        prompt = builder.build_user_prompt(
            message="Now do it by state.",
            session=session,
            candidate_snapshots=snapshots,
            semantic_model={
                "dataset_name": "medicarePhysicianFT",
                "tables": [{"qualified_name": "vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk"}],
            },
            semantic_model_key="default-model",
        )

        self.assertIn("Now do it by state.", prompt)
        self.assertIn("specialty analysis", prompt)
        self.assertIn("snap-1", prompt)
        self.assertIn("default-model", prompt)

    def test_response_schema_closes_state_patch_and_semantic_change_request(self) -> None:
        builder = MemoryReasonerPromptBuilder()

        schema = builder.build_response_schema()["schema"]
        state_patch = schema["properties"]["state_patch"]
        filters = state_patch["properties"]["filters"]
        semantic_change_request = schema["properties"]["semantic_change_request"]
        semantic_filters = semantic_change_request["properties"]["filters_to_add"]

        self.assertFalse(schema["additionalProperties"])
        self.assertFalse(state_patch["additionalProperties"])
        self.assertFalse(filters["anyOf"][0]["items"]["additionalProperties"])
        self.assertFalse(semantic_change_request["additionalProperties"])
        self.assertFalse(semantic_filters["items"]["additionalProperties"])
        self.assertIn("filters", state_patch["required"])
        self.assertIn("operation_type", schema["required"])
        self.assertIn("semantic_change_request", schema["required"])

    def test_fake_memory_reasoner_returns_decision_and_records_call(self) -> None:
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "follow_up",
                "operation_type": "change_grouping",
                "resolved_question": "Using the current specialty analysis, break the result down by state.",
                "use_active_context": True,
                "semantic_change_request": {
                    "filters_to_add": [],
                    "filters_to_replace": [],
                    "grouping_changes": [
                        {
                            "key": "state",
                            "label": "state",
                            "source_field": None,
                            "granularity": None,
                        }
                    ],
                    "measure_change": None,
                    "time_scope_change": None,
                    "ranking_change": None,
                    "notes": "Add a state breakdown to the current analysis.",
                },
                "state_patch": {"dimensions": ["state"]},
            }
        )
        session = SessionMemory(session_id="session-1")
        snapshots = [ContextSnapshot(snapshot_id="snap-1", topic_label="older topic")]

        decision = reasoner.reason(
            message="Now do it by state.",
            session=session,
            candidate_snapshots=snapshots,
            semantic_model={"dataset_name": "demo", "tables": [{"table_name": "providers"}]},
            semantic_model_key="default-model",
            model="gpt-5.4-mini",
        )

        self.assertEqual(decision.turn_type, "follow_up")
        self.assertEqual(decision.operation_type, "change_grouping")
        self.assertEqual(decision.semantic_change_request.grouping_changes[0].key, "state")
        self.assertEqual(reasoner.calls[0].candidate_snapshot_ids, ["snap-1"])
        self.assertEqual(reasoner.calls[0].model, "gpt-5.4-mini")

    def test_openai_memory_reasoner_uses_client_and_validates_payload(self) -> None:
        client = StubResponsesClient(
            {
                "turn_type": "historical_callback",
                "operation_type": "return_to_snapshot",
                "resolved_question": "Return to the earlier reimbursement analysis by state.",
                "use_active_context": False,
                "target_snapshot_id": "snap-2",
                "semantic_change_request": {
                    "filters_to_add": [],
                    "filters_to_replace": [],
                    "grouping_changes": [],
                    "measure_change": None,
                    "time_scope_change": {
                        "field_key": "service_year",
                        "source_field": "year",
                        "year": 2024,
                        "start_year": None,
                        "end_year": None,
                        "description": "Focus on 2024.",
                    },
                    "ranking_change": None,
                    "notes": "Restore the earlier reimbursement topic and keep its year focus.",
                },
                "state_patch": {
                    "topic_id": None,
                    "topic_label": None,
                    "semantic_model_key": None,
                    "dataset_name": None,
                    "tables": None,
                    "metric": "avg_medicare_payment",
                    "dimensions": None,
                    "filters": [{"key": "year", "value": 2024}],
                },
                "clarification_required": False,
                "clarification_question": None,
                "topic_label": None,
                "reason": "The user explicitly referenced the earlier reimbursement question.",
            }
        )
        reasoner = OpenAIMemoryReasoner(client=client)
        session = SessionMemory(
            session_id="session-1",
            active_context=ActiveContext(topic_label="specialty analysis"),
        )

        decision = reasoner.reason(
            message="Go back to the reimbursement question.",
            session=session,
            candidate_snapshots=[ContextSnapshot(snapshot_id="snap-2", topic_label="provider reimbursement")],
            semantic_model={"dataset_name": "demo", "tables": [{"table_name": "providers"}]},
            semantic_model_key="default-model",
            model="gpt-5.4-mini",
        )

        self.assertEqual(decision.turn_type, "historical_callback")
        self.assertEqual(decision.operation_type, "return_to_snapshot")
        self.assertEqual(decision.target_snapshot_id, "snap-2")
        self.assertEqual(decision.state_patch.metric, "avg_medicare_payment")
        self.assertEqual(decision.state_patch.filters, {"year": 2024})
        self.assertEqual(decision.semantic_change_request.time_scope_change.year, 2024)
        self.assertEqual(client.calls[0]["model"], "gpt-5.4-mini")
        self.assertIn("system_prompt", client.calls[0])
        self.assertIn("user_prompt", client.calls[0])
        self.assertIn("schema", client.calls[0])

    def test_openai_memory_reasoner_backfills_new_fields_for_legacy_payloads(self) -> None:
        client = StubResponsesClient(
            {
                "turn_type": "follow_up",
                "resolved_question": "Using the current context, refine the cohort to oncologists.",
                "use_active_context": True,
                "state_patch": {
                    "topic_id": None,
                    "topic_label": None,
                    "semantic_model_key": None,
                    "dataset_name": None,
                    "tables": None,
                    "metric": None,
                    "dimensions": None,
                    "filters": [{"key": "specialty", "value": "oncologist"}],
                },
                "clarification_required": False,
                "clarification_question": None,
                "topic_label": "Texas providers",
                "reason": "The user is narrowing the active cohort.",
            }
        )
        reasoner = OpenAIMemoryReasoner(client=client)

        decision = reasoner.reason(
            message="How many of them are oncologists?",
            session=SessionMemory(session_id="session-1"),
            candidate_snapshots=[],
            semantic_model={"dataset_name": "demo", "tables": [{"table_name": "providers"}]},
        )

        self.assertEqual(decision.operation_type, "refine_current_context")
        self.assertIsNotNone(decision.semantic_change_request)
        self.assertEqual(decision.semantic_change_request.filters_to_add, [])
        self.assertEqual(decision.state_patch.filters, {"specialty": "oncologist"})

    def test_openai_memory_reasoner_rejects_invalid_structured_output(self) -> None:
        client = StubResponsesClient({"resolved_question": "Missing turn_type field"})
        reasoner = OpenAIMemoryReasoner(client=client)

        with self.assertRaises(MemoryReasoningError):
            reasoner.reason(
                message="Now do it by state.",
                session=SessionMemory(session_id="session-1"),
                candidate_snapshots=[],
                semantic_model={"dataset_name": "demo", "tables": [{"table_name": "providers"}]},
            )


if __name__ == "__main__":
    unittest.main()
