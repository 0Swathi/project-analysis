from __future__ import annotations

import unittest

from backend.app.schemas.asset_selection import (
    AssetSelectionPlan,
    SelectedJoin,
    SelectedTable,
)
from backend.app.schemas.semantic_model import (
    RelationshipEndpoint,
    SemanticField,
    SemanticModel,
    SemanticRelationship,
    SemanticTable,
)
from backend.app.services.semantic_projection_service import SemanticProjectionService


class SemanticProjectionServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.service = SemanticProjectionService()
        self.semantic_model = SemanticModel(
            name="medicarePhysicianFT",
            description="Demo healthcare model",
            domain="healthcare_analytics",
            tables=[
                SemanticTable(
                    name="npidata",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.npidata",
                    description="Provider master",
                    fields=[
                        SemanticField(name="npi", kind="identifier"),
                        SemanticField(
                            name="provider_business_practice_location_address_state_name",
                            kind="dimension",
                        ),
                        SemanticField(name="entity_type_code", kind="dimension"),
                        SemanticField(
                            name="healthcare_provider_taxonomy_code_1",
                            kind="dimension",
                        ),
                    ],
                ),
                SemanticTable(
                    name="CMS_Specialty_Taxonomy_Crosswalk",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                    description="Specialty crosswalk",
                    fields=[
                        SemanticField(name="PROVIDER_TAXONOMY_CODE", kind="identifier"),
                        SemanticField(name="CMS_SPECIALTY_CODE", kind="dimension"),
                        SemanticField(name="CMS_SPECIALTY_DESCRIPTION", kind="dimension"),
                    ],
                ),
                SemanticTable(
                    name="MedicareBillingData",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                    description="Billing fact",
                    fields=[
                        SemanticField(name="Rndrng_NPI", kind="identifier"),
                        SemanticField(name="Avg_Mdcr_Pymt_Amt", kind="measure"),
                    ],
                ),
            ],
            relationships=[
                SemanticRelationship(
                    left=RelationshipEndpoint(
                        table_name="npidata",
                        field_name="npi",
                    ),
                    right=RelationshipEndpoint(
                        table_name="MedicareBillingData",
                        field_name="Rndrng_NPI",
                    ),
                    relationship_type="one_to_many",
                    description="Join provider master to billing fact on NPI.",
                ),
                SemanticRelationship(
                    left=RelationshipEndpoint(
                        table_name="npidata",
                        field_name="healthcare_provider_taxonomy_code_1",
                    ),
                    right=RelationshipEndpoint(
                        table_name="CMS_Specialty_Taxonomy_Crosswalk",
                        field_name="PROVIDER_TAXONOMY_CODE",
                    ),
                    relationship_type="many_to_one",
                    description="Join provider taxonomy to CMS specialty mapping.",
                ),
            ],
        )

    def test_project_selects_only_requested_tables_and_required_fields(self) -> None:
        plan = AssetSelectionPlan(
            base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
            selected_tables=[
                SelectedTable(
                    table_name="npidata",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.npidata",
                    role="base",
                    required_fields=[
                        "provider_business_practice_location_address_state_name",
                    ],
                ),
                SelectedTable(
                    table_name="CMS_Specialty_Taxonomy_Crosswalk",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                    role="join",
                    required_fields=["CMS_SPECIALTY_CODE"],
                ),
            ],
            selected_joins=[
                SelectedJoin(
                    left_table_name="npidata",
                    left_field_name="healthcare_provider_taxonomy_code_1",
                    right_table_name="CMS_Specialty_Taxonomy_Crosswalk",
                    right_field_name="PROVIDER_TAXONOMY_CODE",
                    join_type="inner",
                    relationship_type="many_to_one",
                )
            ],
            entity="provider",
            entity_key_field="npi",
            grain_description="One row per provider after specialty filtering.",
        )

        result = self.service.project(
            semantic_model=self.semantic_model,
            asset_selection_plan=plan,
        )

        self.assertEqual(result.projected_table_count, 2)
        self.assertEqual(result.projected_relationship_count, 1)
        projected_tables = {
            table.name: table for table in result.semantic_model.tables
        }
        self.assertNotIn("MedicareBillingData", projected_tables)
        self.assertEqual(
            [field.name for field in projected_tables["npidata"].fields],
            [
                "npi",
                "provider_business_practice_location_address_state_name",
                "healthcare_provider_taxonomy_code_1",
            ],
        )
        self.assertEqual(
            [field.name for field in projected_tables["CMS_Specialty_Taxonomy_Crosswalk"].fields],
            ["PROVIDER_TAXONOMY_CODE", "CMS_SPECIALTY_CODE"],
        )

    def test_project_preserves_full_table_when_required_fields_are_missing(self) -> None:
        plan = AssetSelectionPlan(
            base_table="vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
            selected_tables=[
                SelectedTable(
                    table_name="MedicareBillingData",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                    role="base",
                    required_fields=[],
                )
            ],
            entity="provider",
            entity_key_field="Rndrng_NPI",
            grain_description="One row per billing grain.",
        )

        result = self.service.project(
            semantic_model=self.semantic_model,
            asset_selection_plan=plan,
        )

        self.assertEqual(result.projected_table_count, 1)
        self.assertEqual(
            [field.name for field in result.semantic_model.tables[0].fields],
            ["Rndrng_NPI", "Avg_Mdcr_Pymt_Amt"],
        )

    def test_project_can_synthesize_relationship_when_plan_join_is_not_declared(self) -> None:
        plan = AssetSelectionPlan(
            base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
            selected_tables=[
                SelectedTable(
                    table_name="npidata",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.npidata",
                    role="base",
                ),
                SelectedTable(
                    table_name="CMS_Specialty_Taxonomy_Crosswalk",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                    role="join",
                ),
            ],
            selected_joins=[
                SelectedJoin(
                    left_table_name="npidata",
                    left_field_name="healthcare_provider_taxonomy_code_2",
                    right_table_name="CMS_Specialty_Taxonomy_Crosswalk",
                    right_field_name="PROVIDER_TAXONOMY_CODE",
                    join_type="left",
                    relationship_type="many_to_one",
                    rationale="Selector chose taxonomy slot 2 even though the semantic model only declared slot 1.",
                )
            ],
            entity="provider",
            entity_key_field="npi",
        )

        result = self.service.project(
            semantic_model=self.semantic_model,
            asset_selection_plan=plan,
        )

        self.assertEqual(result.projected_table_count, 2)
        # The synthetic join for slot 2 is produced from selected_joins.
        # The declared relationship for slot 1 is also included because both endpoint
        # tables are in the projected model — giving the SQL generator full join context.
        rel_field_pairs = {
            (r.left.field_name, r.right.field_name)
            for r in result.semantic_model.relationships
        }
        self.assertIn(
            ("healthcare_provider_taxonomy_code_2", "PROVIDER_TAXONOMY_CODE"),
            rel_field_pairs,
        )
        self.assertIn(
            ("healthcare_provider_taxonomy_code_1", "PROVIDER_TAXONOMY_CODE"),
            rel_field_pairs,
        )

    def test_project_preserves_relationships_when_plan_has_no_selected_joins(self) -> None:
        # Reproduces the bug where short table names in relationships ("npidata") failed
        # to match against fully-qualified selected_table_keys
        # ("vertex-poc-465616.medicarePhysicianFT.npidata"), silently dropping all
        # relationships from the projected model.
        plan = AssetSelectionPlan(
            base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
            selected_tables=[
                SelectedTable(
                    table_name="npidata",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.npidata",
                    role="base",
                ),
                SelectedTable(
                    table_name="MedicareBillingData",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                    role="join",
                ),
            ],
            # No selected_joins — exercises the else branch in _select_relationships
            entity="provider",
            entity_key_field="npi",
        )

        result = self.service.project(
            semantic_model=self.semantic_model,
            asset_selection_plan=plan,
        )

        self.assertEqual(result.projected_table_count, 2)
        # The npidata → MedicareBillingData relationship must be preserved.
        self.assertEqual(result.projected_relationship_count, 1)
        rel = result.semantic_model.relationships[0]
        self.assertEqual(rel.left.table_name, "npidata")
        self.assertEqual(rel.right.table_name, "MedicareBillingData")
        # The npidata → CMS_Specialty_Taxonomy_Crosswalk relationship is excluded
        # because CMS_Specialty_Taxonomy_Crosswalk was not selected.
        table_names = {t.name for t in result.semantic_model.tables}
        self.assertNotIn("CMS_Specialty_Taxonomy_Crosswalk", table_names)

    def test_project_preserves_declared_relationship_not_in_selected_joins(self) -> None:
        # When selected_joins only covers taxonomy joins but npidata + MedicareBillingData
        # are both selected, the declared npidata → MedicareBillingData relationship must
        # still appear in the projected model even though it was not in selected_joins.
        plan = AssetSelectionPlan(
            base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
            selected_tables=[
                SelectedTable(
                    table_name="npidata",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.npidata",
                    role="base",
                ),
                SelectedTable(
                    table_name="MedicareBillingData",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                    role="join",
                ),
            ],
            selected_joins=[
                # Only a taxonomy join — npidata → CMS, not npidata → MedicareBillingData
                SelectedJoin(
                    left_table_name="npidata",
                    left_field_name="healthcare_provider_taxonomy_code_1",
                    right_table_name="CMS_Specialty_Taxonomy_Crosswalk",
                    right_field_name="PROVIDER_TAXONOMY_CODE",
                    join_type="inner",
                    relationship_type="many_to_one",
                ),
            ],
            entity="provider",
            entity_key_field="npi",
        )

        result = self.service.project(
            semantic_model=self.semantic_model,
            asset_selection_plan=plan,
        )

        rel_pairs = {
            (r.left.table_name, r.right.table_name)
            for r in result.semantic_model.relationships
        }
        # Declared npidata → MedicareBillingData must be present
        self.assertIn(("npidata", "MedicareBillingData"), rel_pairs)
        # CMS join from selected_joins must also be present
        self.assertIn(("npidata", "CMS_Specialty_Taxonomy_Crosswalk"), rel_pairs)

    def test_project_auto_adds_join_endpoint_table_missing_from_selected_tables(self) -> None:
        # Reproduces the bug where the asset selector lists 2 tables in selected_tables
        # but selected_joins reference a 3rd table — the projection service must add
        # the missing table so the relationship is not silently dropped.
        plan = AssetSelectionPlan(
            base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
            selected_tables=[
                SelectedTable(
                    table_name="npidata",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.npidata",
                    role="base",
                ),
                # MedicareBillingData is omitted — asset selector forgot to add it
            ],
            selected_joins=[
                SelectedJoin(
                    left_table_name="npidata",
                    left_field_name="npi",
                    right_table_name="MedicareBillingData",  # NOT in selected_tables
                    right_field_name="Rndrng_NPI",
                    join_type="inner",
                    relationship_type="one_to_many",
                ),
            ],
            entity="provider",
            entity_key_field="npi",
        )

        result = self.service.project(
            semantic_model=self.semantic_model,
            asset_selection_plan=plan,
        )

        # MedicareBillingData must be auto-added because selected_joins references it
        table_names = {t.name for t in result.semantic_model.tables}
        self.assertIn("MedicareBillingData", table_names)
        self.assertIn("npidata", table_names)
        # The relationship must be preserved
        self.assertEqual(result.projected_relationship_count, 1)

    def test_project_returns_original_model_when_plan_is_empty(self) -> None:
        result = self.service.project(
            semantic_model=self.semantic_model,
            asset_selection_plan=AssetSelectionPlan(),
        )

        self.assertEqual(result.projected_table_count, 3)
        self.assertEqual(result.projected_field_count, 9)
        self.assertEqual(result.projected_relationship_count, 2)


if __name__ == "__main__":
    unittest.main()
