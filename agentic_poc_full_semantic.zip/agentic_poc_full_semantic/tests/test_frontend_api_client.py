from __future__ import annotations

import unittest
from unittest.mock import patch

from frontend.api_client import BackendApiError, chat_turn


class FakeResponse:
    def __init__(self, *, status_code: int, payload: dict, ok: bool | None = None) -> None:
        self.status_code = status_code
        self._payload = payload
        self.ok = status_code < 400 if ok is None else ok

    def json(self):
        return self._payload


class FrontendApiClientTests(unittest.TestCase):
    @patch("frontend.api_client.requests.post")
    def test_chat_turn_posts_expected_payload(self, mock_post) -> None:
        mock_post.return_value = FakeResponse(
            status_code=200,
            payload={
                "status": "ok",
                "session_id": "session-1",
                "assistant_message": "done",
            },
        )

        result = chat_turn(
            session_id="session-1",
            message="How many specialties are there?",
            semantic_model={"tables": [{"table_name": "specialties"}]},
            semantic_model_key="default-model",
            model="gpt-5.4",
            memory_model=None,
            debug=True,
            base_url="http://localhost:8000",
        )

        self.assertEqual(result["assistant_message"], "done")
        _, kwargs = mock_post.call_args
        self.assertEqual(
            kwargs["json"],
            {
                "session_id": "session-1",
                "message": "How many specialties are there?",
                "semantic_model": {"tables": [{"table_name": "specialties"}]},
                "semantic_model_key": "default-model",
                "model": "gpt-5.4",
                "memory_model": None,
                "debug": True,
            },
        )

    @patch("frontend.api_client.requests.post")
    def test_chat_turn_raises_backend_api_error_for_error_response(self, mock_post) -> None:
        mock_post.return_value = FakeResponse(
            status_code=502,
            payload={
                "error": {
                    "code": "chat_session_failed",
                    "message": "Chat session failed.",
                    "details": {},
                }
            },
            ok=False,
        )

        with self.assertRaises(BackendApiError) as context:
            chat_turn(
                session_id="session-1",
                message="Hi",
                semantic_model={"tables": []},
                semantic_model_key="default-model",
                model="gpt-5.4",
                memory_model=None,
                debug=False,
                base_url="http://localhost:8000",
            )

        self.assertEqual(str(context.exception), "Chat session failed.")


if __name__ == "__main__":
    unittest.main()
