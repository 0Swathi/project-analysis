from __future__ import annotations

import unittest

from fastapi.testclient import TestClient

from backend.app.api.deps import get_sql_generation_service
from backend.app.api.main import create_app
from backend.app.schemas.responses import (
    GenerateSqlResponse,
    ResponseMetadata,
    ValidateSemanticModelResponse,
)


class FakeApiService:
    def generate(self, request):
        return GenerateSqlResponse(
            sql="SELECT 1",
            explanation="stub",
            metadata=ResponseMetadata(model="gpt-5.4", prompt_version="v1"),
        )

    def validate_semantic_model(self, raw_model):
        return ValidateSemanticModelResponse(
            status="ok",
            valid=True,
            errors=[],
            warnings=["stub-warning"],
            summary=None,
        )


class ApiSqlTests(unittest.TestCase):
    def setUp(self) -> None:
        self.app = create_app()
        self.app.dependency_overrides[get_sql_generation_service] = lambda: FakeApiService()
        self.client = TestClient(self.app)

    def tearDown(self) -> None:
        self.app.dependency_overrides.clear()

    def test_health_endpoint(self) -> None:
        response = self.client.get("/health")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["status"], "ok")

    def test_generate_sql_endpoint(self) -> None:
        response = self.client.post(
            "/api/v1/sql/generate",
            json={
                "question": "count providers",
                "semantic_model": {"tables": [{"table_name": "providers", "fields": [{"name": "npi"}]}]},
            },
        )

        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertEqual(body["sql"], "SELECT 1")
        self.assertEqual(body["explanation"], "stub")

    def test_validate_semantic_model_endpoint(self) -> None:
        response = self.client.post(
            "/api/v1/semantic-models/validate",
            json={"semantic_model": {"tables": [{"table_name": "providers", "fields": [{"name": "npi"}]}]}},
        )

        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertTrue(body["valid"])
        self.assertEqual(body["warnings"], ["stub-warning"])

    def test_request_validation_error_shape(self) -> None:
        response = self.client.post(
            "/api/v1/sql/generate",
            json={"semantic_model": {"tables": []}},
        )

        self.assertEqual(response.status_code, 422)
        body = response.json()
        self.assertEqual(body["error"]["code"], "request_validation_error")
        self.assertIn("errors", body["error"]["details"])
