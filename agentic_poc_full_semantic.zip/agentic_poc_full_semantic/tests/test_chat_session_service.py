from __future__ import annotations

import unittest

from backend.app.core.errors import ChatSessionError
from backend.app.memory.reasoner import FakeMemoryReasoner
from backend.app.memory.state import ActiveContext, ContextSnapshot, SessionMemory
from backend.app.memory.store import InMemorySessionStore
from backend.app.schemas.asset_selection import AssetSelectionPlan, SelectedTable
from backend.app.schemas.chat import ChatTurnRequest
from backend.app.schemas.responses import GenerateSqlResponse, ResponseMetadata
from backend.app.services.asset_selector_service import FakeAssetSelectorService
from backend.app.services.chat_session_service import ChatSessionService


class FakeSqlGenerationService:
    def __init__(self) -> None:
        self.calls = []

    def generate(self, request):
        self.calls.append(request)
        return GenerateSqlResponse(
            sql=f"SELECT '{request.question}' AS resolved_question",
            explanation="Synthetic SQL response for testing.",
            metadata=ResponseMetadata(model=request.model, prompt_version="test"),
        )


class ExplodingGraph:
    def invoke(self, state):
        raise RuntimeError("graph exploded")


class ChatSessionServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.raw_semantic_model = {
            "dataset_name": "medicarePhysicianFT",
            "tables": [
                {
                    "table_name": "CMS_Specialty_Taxonomy_Crosswalk",
                    "qualified_name": "vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                    "fields": [{"name": "CMS_SPECIALTY_CODE"}],
                }
            ],
        }

    def test_handle_turn_returns_sql_result_and_memory_debug(self) -> None:
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "fresh",
                "resolved_question": "How many specialties are there?",
                "use_active_context": False,
                "state_patch": {
                    "topic_id": "specialty-count",
                    "topic_label": "Specialty count",
                    "tables": [
                        "vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk"
                    ],
                    "metric": "specialty_count",
                },
            }
        )
        sql_service = FakeSqlGenerationService()
        service = ChatSessionService(
            sql_generation_service=sql_service,
            store=store,
            reasoner=reasoner,
        )

        response = service.handle_turn(
            ChatTurnRequest(
                session_id="session-1",
                message="How many specialties are there?",
                semantic_model=self.raw_semantic_model,
                semantic_model_key="default-model",
                model="gpt-5.4",
                memory_model="gpt-5.4-mini",
                debug=True,
            )
        )

        self.assertEqual(response.status, "ok")
        self.assertEqual(response.turn_type, "fresh")
        self.assertIsNotNone(response.sql_result)
        self.assertEqual(response.sql_result.sql, "SELECT 'How many specialties are there?' AS resolved_question")
        self.assertEqual(response.memory_debug.used_active_context, False)
        self.assertEqual(response.memory_debug.candidate_snapshot_ids, [])
        self.assertFalse(response.memory_debug.semantic_model_changed)

        self.assertEqual(len(sql_service.calls), 1)
        sql_request = sql_service.calls[0]
        self.assertEqual(sql_request.question, "How many specialties are there?")
        self.assertEqual(sql_request.model, "gpt-5.4")
        self.assertEqual(sql_request.semantic_model["source_format"], "tables")
        self.assertEqual(
            sql_request.semantic_model["tables"][0]["qualified_name"],
            "vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
        )

    def test_handle_turn_forwards_asset_selection_plan_into_sql_request(self) -> None:
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "fresh",
                "resolved_question": "How many specialties are there?",
                "use_active_context": False,
                "state_patch": {
                    "topic_id": "specialty-count",
                    "topic_label": "Specialty count",
                },
            }
        )
        asset_selector = FakeAssetSelectorService(
            default_plan=AssetSelectionPlan(
                base_table="vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                selected_tables=[
                    SelectedTable(
                        table_name="CMS_Specialty_Taxonomy_Crosswalk",
                        qualified_name="vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                        role="base",
                        required_fields=["CMS_SPECIALTY_CODE"],
                    )
                ],
                entity="specialty",
                entity_key_field="CMS_SPECIALTY_CODE",
                grain_description="One row per specialty crosswalk record.",
                rationale="Specialty counting should stay on the crosswalk reference table.",
            )
        )
        sql_service = FakeSqlGenerationService()
        service = ChatSessionService(
            sql_generation_service=sql_service,
            store=store,
            reasoner=reasoner,
            asset_selector_service=asset_selector,
        )

        service.handle_turn(
            ChatTurnRequest(
                session_id="session-asset-plan",
                message="How many specialties are there?",
                semantic_model=self.raw_semantic_model,
                semantic_model_key="default-model",
                model="gpt-5.4",
            )
        )

        self.assertEqual(len(sql_service.calls), 1)
        sql_request = sql_service.calls[0]
        self.assertIsNotNone(sql_request.asset_selection_plan)
        self.assertEqual(
            sql_request.asset_selection_plan.base_table,
            "vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
        )
        self.assertEqual(
            sql_request.asset_selection_plan.entity_key_field,
            "CMS_SPECIALTY_CODE",
        )

    def test_handle_turn_includes_follow_up_snapshot_debug(self) -> None:
        store = InMemorySessionStore()
        store.save(
            SessionMemory(
                session_id="session-2",
                semantic_model_key="default-model",
                turn_index=2,
                active_context=ActiveContext(
                    topic_id="specialty-count",
                    topic_label="Specialty count",
                    semantic_model_key="default-model",
                    dataset_name="medicarePhysicianFT",
                    tables=["vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk"],
                    metric="specialty_count",
                ),
                snapshots=[
                    ContextSnapshot(snapshot_id="snap-1", topic_label="Provider count"),
                    ContextSnapshot(snapshot_id="snap-2", topic_label="Payment analysis"),
                ],
            )
        )
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "follow_up",
                "resolved_question": "How many specialties are there in Texas?",
                "use_active_context": True,
                "state_patch": {"filters": {"state": "TX"}},
            }
        )
        sql_service = FakeSqlGenerationService()
        service = ChatSessionService(
            sql_generation_service=sql_service,
            store=store,
            reasoner=reasoner,
        )

        response = service.handle_turn(
            ChatTurnRequest(
                session_id="session-2",
                message="Now only Texas.",
                semantic_model=self.raw_semantic_model,
                semantic_model_key="default-model",
                debug=True,
            )
        )

        self.assertEqual(response.turn_type, "follow_up")
        self.assertTrue(response.memory_debug.used_active_context)
        self.assertEqual(response.memory_debug.candidate_snapshot_ids, ["snap-1", "snap-2"])
        self.assertFalse(response.memory_debug.semantic_model_changed)

    def test_handle_turn_flags_semantic_model_change(self) -> None:
        store = InMemorySessionStore()
        store.save(
            SessionMemory(
                session_id="session-3",
                semantic_model_key="old-model",
                semantic_model_fingerprint="sha256:old",
                active_context=ActiveContext(topic_label="Old topic"),
            )
        )
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "fresh",
                "resolved_question": "How many providers are there?",
                "use_active_context": False,
                "state_patch": {
                    "topic_id": "provider-count",
                    "topic_label": "Provider count",
                    "tables": ["vertex-poc-465616.medicarePhysicianFT.npidata"],
                    "metric": "provider_count",
                },
            }
        )
        sql_service = FakeSqlGenerationService()
        service = ChatSessionService(
            sql_generation_service=sql_service,
            store=store,
            reasoner=reasoner,
        )

        new_model = {
            "dataset_name": "medicarePhysicianFT",
            "tables": [
                {
                    "table_name": "npidata",
                    "qualified_name": "vertex-poc-465616.medicarePhysicianFT.npidata",
                    "fields": [{"name": "NPI"}],
                }
            ],
        }
        response = service.handle_turn(
            ChatTurnRequest(
                session_id="session-3",
                message="How many providers are there?",
                semantic_model=new_model,
                semantic_model_key="new-model",
                debug=True,
            )
        )

        self.assertTrue(response.memory_debug.semantic_model_changed)

    def test_handle_turn_returns_clarification_without_sql_call(self) -> None:
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "historical_callback",
                "use_active_context": False,
                "clarification_required": True,
                "clarification_question": "Which earlier analysis do you want to continue?",
                "state_patch": {},
            }
        )
        sql_service = FakeSqlGenerationService()
        service = ChatSessionService(
            sql_generation_service=sql_service,
            store=store,
            reasoner=reasoner,
        )

        response = service.handle_turn(
            ChatTurnRequest(
                session_id="session-4",
                message="Go back to that one.",
                semantic_model=self.raw_semantic_model,
                semantic_model_key="default-model",
                debug=True,
            )
        )

        self.assertTrue(response.clarification_required)
        self.assertEqual(
            response.clarification_question,
            "Which earlier analysis do you want to continue?",
        )
        self.assertIsNone(response.sql_result)
        self.assertEqual(len(sql_service.calls), 0)

    def test_handle_turn_wraps_unexpected_graph_failure(self) -> None:
        service = ChatSessionService(
            sql_generation_service=FakeSqlGenerationService(),
            store=InMemorySessionStore(),
            reasoner=FakeMemoryReasoner(
                default_decision={
                    "turn_type": "fresh",
                    "resolved_question": "ignored",
                    "state_patch": {},
                }
            ),
            graph=ExplodingGraph(),
        )

        with self.assertRaises(ChatSessionError) as context:
            service.handle_turn(
                ChatTurnRequest(
                    session_id="session-5",
                    message="Hello",
                    semantic_model=self.raw_semantic_model,
                    semantic_model_key="default-model",
                )
            )

        self.assertEqual(context.exception.code, "chat_session_failed")

    # ------------------------------------------------------------------ Gap #1

    def test_store_get_called_exactly_once_per_turn(self) -> None:
        """store.get() must be called once (inside _load_session) not twice
        (previously once in _semantic_model_changed + once in _load_session)."""

        class CountingStore(InMemorySessionStore):
            def __init__(self) -> None:
                super().__init__()
                self.get_call_count = 0

            def get(self, session_id):
                self.get_call_count += 1
                return super().get(session_id)

        store = CountingStore()
        service = ChatSessionService(
            sql_generation_service=FakeSqlGenerationService(),
            store=store,
            reasoner=FakeMemoryReasoner(
                default_decision={
                    "turn_type": "fresh",
                    "resolved_question": "How many specialties?",
                    "state_patch": {"topic_id": "t1", "topic_label": "specialties"},
                }
            ),
        )
        service.handle_turn(
            ChatTurnRequest(
                session_id="session-count",
                message="How many specialties?",
                semantic_model=self.raw_semantic_model,
                semantic_model_key="default-model",
            )
        )
        self.assertEqual(store.get_call_count, 1)

    def test_semantic_model_changed_false_on_repeated_same_model(self) -> None:
        """A second turn with the identical semantic model must report changed=False."""
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "fresh",
                "resolved_question": "How many specialties?",
                "state_patch": {"topic_id": "t1", "topic_label": "specialties"},
            }
        )
        service = ChatSessionService(
            sql_generation_service=FakeSqlGenerationService(),
            store=store,
            reasoner=reasoner,
        )
        request = ChatTurnRequest(
            session_id="session-same-model",
            message="How many specialties?",
            semantic_model=self.raw_semantic_model,
            semantic_model_key="default-model",
            debug=True,
        )
        service.handle_turn(request)  # first turn plants the fingerprint
        response2 = service.handle_turn(request)  # second turn: same model
        self.assertFalse(response2.memory_debug.semantic_model_changed)

    def test_semantic_model_changed_true_when_key_changes(self) -> None:
        """Changing semantic_model_key between turns must report changed=True even
        when the model bytes are identical, because the caller may serve a
        semantically different model under a new key."""
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "fresh",
                "resolved_question": "How many specialties?",
                "state_patch": {"topic_id": "t1", "topic_label": "specialties"},
            }
        )
        service = ChatSessionService(
            sql_generation_service=FakeSqlGenerationService(),
            store=store,
            reasoner=reasoner,
        )
        service.handle_turn(
            ChatTurnRequest(
                session_id="session-key-change",
                message="How many specialties?",
                semantic_model=self.raw_semantic_model,
                semantic_model_key="model-v1",
                debug=True,
            )
        )
        response2 = service.handle_turn(
            ChatTurnRequest(
                session_id="session-key-change",
                message="Same question again",
                semantic_model=self.raw_semantic_model,
                semantic_model_key="model-v2",
                debug=True,
            )
        )
        self.assertTrue(response2.memory_debug.semantic_model_changed)

    def test_semantic_model_changed_true_when_content_changes(self) -> None:
        """Changing the actual semantic model content between turns must report
        changed=True even when the key is the same."""
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            default_decision={
                "turn_type": "fresh",
                "resolved_question": "How many providers?",
                "state_patch": {"topic_id": "t1", "topic_label": "providers"},
            }
        )
        service = ChatSessionService(
            sql_generation_service=FakeSqlGenerationService(),
            store=store,
            reasoner=reasoner,
        )
        service.handle_turn(
            ChatTurnRequest(
                session_id="session-content-change",
                message="How many providers?",
                semantic_model=self.raw_semantic_model,
                semantic_model_key="stable-key",
                debug=True,
            )
        )
        different_model = {
            "dataset_name": "medicarePhysicianFT",
            "tables": [
                {
                    "table_name": "npidata",
                    "qualified_name": "vertex-poc-465616.medicarePhysicianFT.npidata",
                    "fields": [{"name": "NPI"}],
                }
            ],
        }
        response2 = service.handle_turn(
            ChatTurnRequest(
                session_id="session-content-change",
                message="How many providers from this model?",
                semantic_model=different_model,
                semantic_model_key="stable-key",
                debug=True,
            )
        )
        self.assertTrue(response2.memory_debug.semantic_model_changed)


class CoerceSemanticChangeRequestTests(unittest.TestCase):
    """Unit tests for _coerce_semantic_change_request (Gap #10)."""

    def setUp(self) -> None:
        from backend.app.memory.state import (
            AnalyticalFilter,
            AnalyticalMeasure,
            SemanticChangeRequest,
        )
        from backend.app.schemas.requests import SemanticChangeRequestPayload
        from backend.app.services.chat_session_service import _coerce_semantic_change_request

        self.coerce = _coerce_semantic_change_request
        self.SemanticChangeRequest = SemanticChangeRequest
        self.SemanticChangeRequestPayload = SemanticChangeRequestPayload
        self.AnalyticalFilter = AnalyticalFilter
        self.AnalyticalMeasure = AnalyticalMeasure

    def test_none_returns_none(self) -> None:
        self.assertIsNone(self.coerce(None))

    def test_payload_passthrough_returns_same_object(self) -> None:
        payload = self.SemanticChangeRequestPayload(notes="pass through")
        result = self.coerce(payload)
        self.assertIs(result, payload)

    def test_typed_state_model_converted_correctly(self) -> None:
        scr = self.SemanticChangeRequest(
            filters_to_add=[
                self.AnalyticalFilter(field_key="provider_state", operator="=", value="Texas")
            ],
            measure_change=self.AnalyticalMeasure(
                name="provider_count",
                aggregation="count_distinct",
            ),
            notes="Count Texas providers.",
        )
        result = self.coerce(scr)
        self.assertIsInstance(result, self.SemanticChangeRequestPayload)
        self.assertEqual(len(result.filters_to_add), 1)
        self.assertEqual(result.filters_to_add[0]["field_key"], "provider_state")
        self.assertEqual(result.measure_change["name"], "provider_count")
        self.assertEqual(result.notes, "Count Texas providers.")

    def test_dict_input_validated_into_payload(self) -> None:
        data = {
            "filters_to_add": [{"field_key": "year", "operator": "=", "value": 2024}],
            "notes": "Year filter.",
        }
        result = self.coerce(data)
        self.assertIsInstance(result, self.SemanticChangeRequestPayload)
        self.assertEqual(result.notes, "Year filter.")
        self.assertEqual(result.filters_to_add[0]["field_key"], "year")

    def test_empty_dict_produces_empty_payload(self) -> None:
        result = self.coerce({})
        self.assertIsInstance(result, self.SemanticChangeRequestPayload)
        self.assertEqual(result.filters_to_add, [])
        self.assertIsNone(result.notes)

    def test_empty_state_model_produces_empty_payload(self) -> None:
        scr = self.SemanticChangeRequest()
        result = self.coerce(scr)
        self.assertIsInstance(result, self.SemanticChangeRequestPayload)
        self.assertEqual(result.filters_to_add, [])

    def test_unknown_type_raises_type_error(self) -> None:
        with self.assertRaises(TypeError) as ctx:
            self.coerce(42)  # type: ignore[arg-type]
        self.assertIn("int", str(ctx.exception))

    def test_object_without_model_dump_raises_type_error(self) -> None:
        class Mystery:
            pass

        with self.assertRaises(TypeError):
            self.coerce(Mystery())  # type: ignore[arg-type]


if __name__ == "__main__":
    unittest.main()
