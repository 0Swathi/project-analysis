from __future__ import annotations

import unittest

from backend.app.agents.sql_generator_agent import SqlAgentInvocationResult
from backend.app.agents.orchestrator import GenerationOrchestrator
from backend.app.core.errors import BadRequestError, SqlValidationError
from backend.app.prompts.sql_prompt_builder import SqlPromptBuilder
from backend.app.schemas.asset_selection import AssetSelectionPlan, SelectedTable
from backend.app.schemas.requests import GenerateSqlRequest
from backend.app.services.semantic_model_service import SemanticModelService
from backend.app.services.sql_generation_service import SqlGenerationService


class FakeOrchestrator(GenerationOrchestrator):
    def __init__(
        self,
        *,
        sql: str = "SELECT COUNT(*) AS provider_count FROM `providers`",
        explanation: str = "Count providers from the providers table.",
    ) -> None:
        self.calls = []
        self.sql = sql
        self.explanation = explanation

    def generate_sql(
        self,
        *,
        system_prompt: str,
        user_input: str,
        asset_selection_plan: AssetSelectionPlan | None = None,
        model_name: str | None = None,
        debug: bool = False,
    ) -> SqlAgentInvocationResult:
        self.calls.append(
            {
                "system_prompt": system_prompt,
                "user_input": user_input,
                "asset_selection_plan": asset_selection_plan,
                "model_name": model_name,
                "debug": debug,
            }
        )
        return SqlAgentInvocationResult(
            sql=self.sql,
            explanation=self.explanation,
            trace=["fake_orchestrator_called=true"],
        )


class SequencedFakeOrchestrator(GenerationOrchestrator):
    """Returns SQL from a fixed sequence; repeats the last entry once the sequence is exhausted."""

    def __init__(self, responses: list[tuple[str, str]]) -> None:
        self.calls: list[dict] = []
        self._responses = responses

    def generate_sql(
        self,
        *,
        system_prompt: str,
        user_input: str,
        asset_selection_plan: AssetSelectionPlan | None = None,
        model_name: str | None = None,
        debug: bool = False,
    ) -> SqlAgentInvocationResult:
        self.calls.append({"system_prompt": system_prompt, "user_input": user_input})
        idx = min(len(self.calls) - 1, len(self._responses) - 1)
        sql, explanation = self._responses[idx]
        return SqlAgentInvocationResult(sql=sql, explanation=explanation, trace=[])


class TinyWindowPromptBuilder(SqlPromptBuilder):
    def get_context_window(
        self,
        model_name: str,
        explicit_context_window: int | None = None,
    ) -> int | None:
        return 10


class SqlGenerationServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.raw_model = {
            "dataset_name": "demo",
            "tables": [
                {
                    "table_name": "providers",
                    "fields": [
                        {"name": "entity_type_code", "description": "Entity type code"},
                    ],
                }
            ],
        }

    def test_generate_returns_sql_and_debug_trace(self) -> None:
        orchestrator = FakeOrchestrator()
        service = SqlGenerationService(
            semantic_model_service=SemanticModelService(),
            prompt_builder=SqlPromptBuilder(),
            orchestrator=orchestrator,
        )

        result = service.generate(
            GenerateSqlRequest(
                question="count providers by entity type code",
                semantic_model=self.raw_model,
                model="gpt-5.4",
                debug=True,
                request_id="req-123",
            )
        )

        self.assertEqual(result.sql, "SELECT COUNT(*) AS provider_count FROM `providers`")
        self.assertEqual(result.metadata.request_id, "req-123")
        self.assertIsNotNone(result.debug)
        self.assertIn("sql_prompt_mode=full_schema", result.debug.trace)
        self.assertIn("fake_orchestrator_called=true", result.debug.trace)
        self.assertEqual(len(orchestrator.calls), 1)

    def test_generate_threads_asset_selection_plan_into_orchestrator_and_grounded_input(self) -> None:
        orchestrator = FakeOrchestrator()
        service = SqlGenerationService(
            semantic_model_service=SemanticModelService(),
            prompt_builder=SqlPromptBuilder(),
            orchestrator=orchestrator,
        )
        asset_selection_plan = AssetSelectionPlan(
            base_table="project.dataset.providers",
            selected_tables=[
                SelectedTable(
                    table_name="providers",
                    qualified_name="project.dataset.providers",
                    role="base",
                    required_fields=["entity_type_code"],
                )
            ],
            entity="provider",
            entity_key_field="npi",
            grain_description="One row per provider record.",
            measure_intent="count providers",
            rationale="Provider counting should stay on the provider master table.",
        )

        result = service.generate(
            GenerateSqlRequest(
                question="count providers by entity type code",
                semantic_model=self.raw_model,
                asset_selection_plan=asset_selection_plan,
                model="gpt-5.4",
                debug=True,
            )
        )

        self.assertEqual(len(orchestrator.calls), 1)
        orchestrator_call = orchestrator.calls[0]
        self.assertEqual(orchestrator_call["asset_selection_plan"], asset_selection_plan)
        self.assertIn("--- GROUNDED DATA PLAN ---", orchestrator_call["system_prompt"])
        self.assertIn("- Base table: project.dataset.providers", orchestrator_call["system_prompt"])
        self.assertIn("- Entity key field: npi", orchestrator_call["system_prompt"])
        self.assertIn("- Expected grain: One row per provider record.", orchestrator_call["system_prompt"])
        self.assertIn(
            "The grounded data plan in the system prompt is authoritative.",
            orchestrator_call["user_input"],
        )
        self.assertIn("sql_prompt_mode=grounded", result.debug.trace)
        self.assertIn("asset_selection_plan_present=true", result.debug.trace)
        self.assertIn("asset_selection_base_table=project.dataset.providers", result.debug.trace)

    def test_generate_raises_when_context_window_is_too_small(self) -> None:
        service = SqlGenerationService(
            semantic_model_service=SemanticModelService(),
            prompt_builder=TinyWindowPromptBuilder(),
            orchestrator=FakeOrchestrator(),
        )

        with self.assertRaises(BadRequestError):
            service.generate(
                GenerateSqlRequest(
                    question="count providers by entity type code",
                    semantic_model=self.raw_model,
                    model="gpt-5.4",
                )
            )

    def test_generate_raises_when_sql_violates_grounded_plan(self) -> None:
        asset_selection_plan = AssetSelectionPlan(
            base_table="project.dataset.providers",
            selected_tables=[
                SelectedTable(
                    table_name="providers",
                    qualified_name="project.dataset.providers",
                    role="base",
                    required_fields=["entity_type_code"],
                )
            ],
            entity="provider",
            entity_key_field="npi",
            grain_description="One row per provider record.",
        )
        service = SqlGenerationService(
            semantic_model_service=SemanticModelService(),
            prompt_builder=SqlPromptBuilder(),
            orchestrator=FakeOrchestrator(
                sql="SELECT COUNT(*) FROM `project.dataset.claims`",
                explanation="Wrong table on purpose.",
            ),
            max_validation_retries=0,
        )

        with self.assertRaises(SqlValidationError) as context:
            service.generate(
                GenerateSqlRequest(
                    question="count providers by entity type code",
                    semantic_model=self.raw_model,
                    asset_selection_plan=asset_selection_plan,
                    model="gpt-5.4",
                )
            )

        self.assertIn(
            "Generated SQL violated the grounded data plan",
            context.exception.message,
        )
        self.assertTrue(context.exception.details["attempts"])

    def test_generate_passes_on_retry_after_initial_validation_failure(self) -> None:
        asset_selection_plan = AssetSelectionPlan(
            base_table="project.dataset.providers",
            selected_tables=[
                SelectedTable(
                    table_name="providers",
                    qualified_name="project.dataset.providers",
                    role="base",
                    required_fields=["entity_type_code"],
                )
            ],
            entity="provider",
            entity_key_field="npi",
        )
        orchestrator = SequencedFakeOrchestrator(responses=[
            ("SELECT COUNT(*) FROM `project.dataset.claims`", "wrong table"),
            ("SELECT COUNT(*) FROM `project.dataset.providers`", "correct"),
        ])
        service = SqlGenerationService(
            semantic_model_service=SemanticModelService(),
            prompt_builder=SqlPromptBuilder(),
            orchestrator=orchestrator,
            max_validation_retries=2,
        )

        result = service.generate(
            GenerateSqlRequest(
                question="count providers",
                semantic_model=self.raw_model,
                asset_selection_plan=asset_selection_plan,
                model="gpt-5.4",
                debug=True,
            )
        )

        self.assertEqual(result.sql, "SELECT COUNT(*) FROM `project.dataset.providers`")
        self.assertEqual(len(orchestrator.calls), 2)
        self.assertIn("sql_plan_validator_attempts=2", result.debug.trace)

    def test_generate_retry_user_input_contains_violation_feedback(self) -> None:
        asset_selection_plan = AssetSelectionPlan(
            base_table="project.dataset.providers",
            selected_tables=[
                SelectedTable(
                    table_name="providers",
                    qualified_name="project.dataset.providers",
                    role="base",
                    required_fields=["entity_type_code"],
                )
            ],
        )
        orchestrator = SequencedFakeOrchestrator(responses=[
            ("SELECT COUNT(*) FROM `project.dataset.claims`", "wrong"),
            ("SELECT COUNT(*) FROM `project.dataset.providers`", "correct"),
        ])
        service = SqlGenerationService(
            semantic_model_service=SemanticModelService(),
            prompt_builder=SqlPromptBuilder(),
            orchestrator=orchestrator,
            max_validation_retries=2,
        )

        service.generate(
            GenerateSqlRequest(
                question="count providers",
                semantic_model=self.raw_model,
                asset_selection_plan=asset_selection_plan,
                model="gpt-5.4",
            )
        )

        retry_user_input = orchestrator.calls[1]["user_input"]
        self.assertIn("VALIDATION FEEDBACK", retry_user_input)
        self.assertIn("outside the grounded plan", retry_user_input)
        self.assertIn("project.dataset.claims", retry_user_input)
        # System prompt is unchanged across retries
        self.assertEqual(
            orchestrator.calls[0]["system_prompt"],
            orchestrator.calls[1]["system_prompt"],
        )

    def test_generate_raises_after_all_retries_exhausted(self) -> None:
        asset_selection_plan = AssetSelectionPlan(
            base_table="project.dataset.providers",
            selected_tables=[
                SelectedTable(
                    table_name="providers",
                    qualified_name="project.dataset.providers",
                    role="base",
                    required_fields=["entity_type_code"],
                )
            ],
        )
        orchestrator = FakeOrchestrator(
            sql="SELECT COUNT(*) FROM `project.dataset.claims`",
            explanation="Always wrong.",
        )
        service = SqlGenerationService(
            semantic_model_service=SemanticModelService(),
            prompt_builder=SqlPromptBuilder(),
            orchestrator=orchestrator,
            max_validation_retries=2,
        )

        with self.assertRaises(SqlValidationError) as context:
            service.generate(
                GenerateSqlRequest(
                    question="count providers",
                    semantic_model=self.raw_model,
                    asset_selection_plan=asset_selection_plan,
                    model="gpt-5.4",
                )
            )

        # All 3 attempts (initial + 2 retries) should be recorded
        self.assertEqual(len(orchestrator.calls), 3)
        attempts = context.exception.details["attempts"]
        self.assertEqual(len(attempts), 3)
        self.assertEqual(attempts[0]["attempt"], 1)
        self.assertEqual(attempts[2]["attempt"], 3)
        self.assertTrue(all(a["violations"] for a in attempts))
