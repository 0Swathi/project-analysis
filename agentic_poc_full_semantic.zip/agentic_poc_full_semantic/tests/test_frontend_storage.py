from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from frontend.storage import save_semantic_model_upload


class FrontendStorageTests(unittest.TestCase):
    def test_save_semantic_model_upload_creates_json_file(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            target_dir = Path(temp_dir)

            saved_path = save_semantic_model_upload(
                filename="Medicare Physician Model.json",
                content=b'{"dataset_name":"demo"}',
                storage_dir=target_dir,
            )

            self.assertTrue(saved_path.exists())
            self.assertEqual(saved_path.parent, target_dir)
            self.assertEqual(saved_path.suffix, ".json")
            self.assertIn("medicare-physician-model-", saved_path.name)

    def test_save_semantic_model_upload_normalizes_non_json_extension(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            target_dir = Path(temp_dir)

            saved_path = save_semantic_model_upload(
                filename="semantic model payload.txt",
                content=b"{}",
                storage_dir=target_dir,
            )

            self.assertTrue(saved_path.exists())
            self.assertEqual(saved_path.suffix, ".json")


if __name__ == "__main__":
    unittest.main()
