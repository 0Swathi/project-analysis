from __future__ import annotations

import unittest

from pydantic import ValidationError

from backend.app.memory.state import (
    ActiveContext,
    AnalyticalContext,
    AnalyticalCohort,
    AnalyticalFilter,
    AnalyticalGrouping,
    AnalyticalMeasure,
    SemanticChangeRequest,
    ContextSnapshot,
    GraphTurnState,
    ReasonerDecision,
    SessionMemory,
)
from backend.app.schemas.chat import (
    ChatTurnRequest,
    ChatTurnResponse,
    MemoryDebugPayload,
    OperationType,
)
from backend.app.schemas.responses import GenerateSqlResponse


class ChatSchemaTests(unittest.TestCase):
    def test_chat_turn_request_accepts_expected_fields(self) -> None:
        request = ChatTurnRequest(
            session_id="session-1",
            message="Show specialty counts by state",
            semantic_model={"dataset_name": "demo", "tables": [{"table_name": "providers"}]},
            semantic_model_key="default-model",
            model="gpt-5.4",
            memory_model="gpt-5.4-mini",
            debug=True,
        )

        self.assertEqual(request.session_id, "session-1")
        self.assertEqual(request.message, "Show specialty counts by state")
        self.assertTrue(request.debug)

    def test_chat_turn_request_rejects_blank_values(self) -> None:
        with self.assertRaises(ValidationError):
            ChatTurnRequest(
                session_id="   ",
                message="Question",
                semantic_model={"tables": [{"table_name": "providers"}]},
            )

        with self.assertRaises(ValidationError):
            ChatTurnRequest(
                session_id="session-1",
                message="Question",
                semantic_model={},
            )

    def test_chat_turn_response_supports_sql_and_memory_debug(self) -> None:
        sql_result = GenerateSqlResponse(
            sql="SELECT 1",
            explanation="Simple test query.",
        )
        response = ChatTurnResponse(
            session_id="session-1",
            turn_type="follow_up",
            assistant_message="```sql\nSELECT 1\n```",
            resolved_question="Show the previous result again.",
            sql_result=sql_result,
            memory_debug=MemoryDebugPayload(
                used_active_context=True,
                candidate_snapshot_ids=["snap-1"],
            ),
        )

        self.assertEqual(response.turn_type, "follow_up")
        self.assertIsNotNone(response.sql_result)
        self.assertTrue(response.memory_debug.used_active_context)

    def test_session_memory_models_capture_batch_one_state(self) -> None:
        session = SessionMemory(
            session_id="session-1",
            semantic_model_key="default-model",
            turn_index=3,
            active_context=ActiveContext(
                topic_id="topic-1",
                topic_label="specialty analysis",
                dataset_name="medicarePhysicianFT",
                tables=["vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk"],
                metric="count_distinct_specialty_code",
                dimensions=["state"],
                filters={"year": 2024},
                last_resolved_question="Show specialty counts by state for 2024.",
                last_sql="SELECT ...",
                last_explanation="Counts specialties by state.",
                last_turn_type="fresh",
                analytical_context=AnalyticalContext(
                    entity="specialty",
                    entity_key="CMS_SPECIALTY_CODE",
                    cohort=AnalyticalCohort(
                        description="Specialties in 2024.",
                        filters=[
                            AnalyticalFilter(
                                field_key="service_year",
                                operator="=",
                                value=2024,
                            )
                        ],
                    ),
                    measure=AnalyticalMeasure(
                        name="specialty_count",
                        aggregation="count_distinct",
                        target="specialty",
                    ),
                ),
            ),
            snapshots=[
                ContextSnapshot(
                    snapshot_id="snap-1",
                    topic_id="topic-0",
                    topic_label="provider reimbursement",
                    summary="Average reimbursement by state.",
                    tables=["vertex-poc-465616.medicarePhysicianFT.MedicareBillingData"],
                    metric="avg_medicare_payment",
                    dimensions=["state"],
                    filters={"year": 2024},
                    created_at_turn=1,
                    analytical_context=AnalyticalContext(
                        entity="provider",
                        entity_key="Rndrng_NPI",
                        measure=AnalyticalMeasure(
                            name="avg_medicare_payment",
                            aggregation="average",
                            target="provider_reimbursement",
                        ),
                    ),
                )
            ],
        )

        self.assertEqual(session.active_context.topic_label, "specialty analysis")
        self.assertEqual(session.snapshots[0].snapshot_id, "snap-1")
        self.assertEqual(session.active_context.analytical_context.entity, "specialty")

    def test_reasoner_decision_and_graph_turn_state_validate(self) -> None:
        decision = ReasonerDecision(
            turn_type="historical_callback",
            operation_type="return_to_snapshot",
            resolved_question="Return to the earlier reimbursement analysis by state.",
            use_active_context=False,
            target_snapshot_id="snap-1",
            semantic_change_request=SemanticChangeRequest(
                filters_to_add=[],
                filters_to_replace=[],
                grouping_changes=[
                    AnalyticalGrouping(
                        key="state",
                        label="state",
                    )
                ],
                measure_change=AnalyticalMeasure(
                    name="avg_medicare_payment",
                    aggregation="average",
                    target="provider_reimbursement",
                ),
                notes="Restore the reimbursement analysis grouped by state.",
            ),
            state_patch={"filters": {"year": 2024}},
            clarification_required=False,
            topic_label="provider reimbursement",
        )
        graph_state = GraphTurnState(
            session_id="session-1",
            incoming_message="Go back to the reimbursement question.",
            semantic_model={"dataset_name": "demo", "tables": [{"table_name": "providers"}]},
            reasoner_output=decision,
            resolved_question=decision.resolved_question,
            turn_type=decision.turn_type,
        )

        self.assertEqual(graph_state.turn_type, "historical_callback")
        self.assertEqual(graph_state.reasoner_output.target_snapshot_id, "snap-1")
        self.assertEqual(graph_state.reasoner_output.operation_type, "return_to_snapshot")

    def test_operation_type_contract_includes_analytical_change_operations(self) -> None:
        valid_operations: tuple[OperationType, ...] = (
            "refine_current_context",
            "add_filter",
            "change_time_scope",
            "change_grouping",
            "change_measure",
            "return_to_snapshot",
            "switch_topic",
        )

        self.assertEqual(valid_operations[0], "refine_current_context")
        self.assertIn("change_time_scope", valid_operations)


if __name__ == "__main__":
    unittest.main()
