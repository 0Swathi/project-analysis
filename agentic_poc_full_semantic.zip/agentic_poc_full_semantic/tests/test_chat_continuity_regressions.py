from __future__ import annotations

import unittest

from fastapi.testclient import TestClient

from backend.app.api.deps import get_chat_session_service
from backend.app.api.main import create_app
from backend.app.memory.reasoner import FakeMemoryReasoner
from backend.app.memory.store import InMemorySessionStore
from backend.app.schemas.asset_selection import AssetSelectionPlan, SelectedJoin, SelectedTable
from backend.app.schemas.chat import ChatTurnRequest
from backend.app.schemas.responses import GenerateSqlResponse, ResponseMetadata
from backend.app.services.asset_selector_service import FakeAssetSelectorService
from backend.app.services.chat_session_service import ChatSessionService


class FakeSqlGenerationService:
    def __init__(self) -> None:
        self.calls = []

    def generate(self, request):
        self.calls.append(request)
        return GenerateSqlResponse(
            sql=f"SELECT '{request.question}' AS resolved_question",
            explanation="Synthetic SQL response for continuity regression testing.",
            metadata=ResponseMetadata(
                model=request.model,
                prompt_version="continuity-test",
                duration_ms=7,
            ),
        )


class ChatContinuityRegressionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.semantic_model = {
            "dataset_name": "medicarePhysicianFT",
            "tables": [
                {
                    "table_name": "npidata",
                    "qualified_name": "vertex-poc-465616.medicarePhysicianFT.npidata",
                    "fields": [{"name": "npi"}],
                },
                {
                    "table_name": "MedicareBillingData",
                    "qualified_name": "vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                    "fields": [{"name": "Rndrng_NPI"}, {"name": "year"}],
                },
                {
                    "table_name": "CMS_Specialty_Taxonomy_Crosswalk",
                    "qualified_name": "vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                    "fields": [{"name": "CMS_SPECIALTY_CODE"}],
                },
            ],
        }

    def test_service_regression_preserves_follow_up_and_historical_callback_continuity(self) -> None:
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            decisions=[
                {
                    "turn_type": "fresh",
                    "operation_type": "switch_topic",
                    "resolved_question": "How many providers are from Texas?",
                    "use_active_context": False,
                    "semantic_change_request": {
                        "filters_to_add": [
                            {
                                "field_key": "provider_state",
                                "operator": "=",
                                "value": "Texas",
                                "source_field": None,
                                "rationale": "The user is asking for the Texas provider cohort.",
                            }
                        ],
                        "measure_change": {
                            "name": "provider_count",
                            "aggregation": "count_distinct",
                            "target": "provider",
                            "source_field": "npi",
                            "description": None,
                        },
                        "notes": "Count Texas providers.",
                    },
                    "state_patch": {
                        "topic_id": "topic-provider-count",
                        "topic_label": "Texas providers",
                        "tables": [
                            "vertex-poc-465616.medicarePhysicianFT.npidata"
                        ],
                    },
                },
                {
                    "turn_type": "follow_up",
                    "operation_type": "add_filter",
                    "resolved_question": "How many Texas providers are oncologists?",
                    "use_active_context": True,
                    "semantic_change_request": {
                        "filters_to_add": [
                            {
                                "field_key": "provider_specialty",
                                "operator": "=",
                                "value": "oncologist",
                                "source_field": None,
                                "rationale": "The user is narrowing the provider cohort.",
                            }
                        ],
                        "notes": "Refine the current provider cohort to oncologists.",
                    },
                    "state_patch": {},
                },
                {
                    "turn_type": "fresh",
                    "operation_type": "switch_topic",
                    "resolved_question": "Highest reimbursement from Texas in 2020?",
                    "use_active_context": False,
                    "semantic_change_request": {
                        "filters_to_add": [
                            {
                                "field_key": "provider_state",
                                "operator": "=",
                                "value": "Texas",
                                "source_field": None,
                                "rationale": "Stay within Texas providers.",
                            }
                        ],
                        "measure_change": {
                            "name": "estimated_total_reimbursement",
                            "aggregation": "sum",
                            "target": "provider_reimbursement",
                            "source_field": "Avg_Mdcr_Pymt_Amt",
                            "description": None,
                        },
                        "time_scope_change": {
                            "field_key": "service_year",
                            "source_field": "year",
                            "year": 2020,
                            "start_year": None,
                            "end_year": None,
                            "description": "Focus on 2020.",
                        },
                        "ranking_change": {
                            "sort_by": "estimated_total_reimbursement",
                            "direction": "desc",
                            "limit": 1,
                            "rank": None,
                        },
                        "notes": "Find the top reimbursement in Texas for 2020.",
                    },
                    "state_patch": {
                        "topic_id": "topic-reimbursement",
                        "topic_label": "Texas reimbursement",
                        "tables": [
                            "vertex-poc-465616.medicarePhysicianFT.MedicareBillingData"
                        ],
                    },
                },
                {
                    "turn_type": "follow_up",
                    "operation_type": "change_time_scope",
                    "resolved_question": "Highest reimbursement from Texas in 2021?",
                    "use_active_context": True,
                    "semantic_change_request": {
                        "time_scope_change": {
                            "field_key": "service_year",
                            "source_field": "year",
                            "year": 2021,
                            "start_year": None,
                            "end_year": None,
                            "description": "Move the reimbursement question to 2021.",
                        },
                        "notes": "Keep the reimbursement analysis and change only the year.",
                    },
                    "state_patch": {},
                },
                {
                    "turn_type": "historical_callback",
                    "operation_type": "return_to_snapshot",
                    "resolved_question": "How many Texas providers are oncologists?",
                    "use_active_context": False,
                    "target_snapshot_id": "topic-provider-count",
                    "semantic_change_request": {
                        "notes": "Return to the earlier Texas oncologist provider analysis.",
                    },
                    "state_patch": {},
                },
            ]
        )
        sql_service = FakeSqlGenerationService()
        service = ChatSessionService(
            sql_generation_service=sql_service,
            store=store,
            reasoner=reasoner,
        )

        responses = [
            service.handle_turn(
                ChatTurnRequest(
                    session_id="session-regression",
                    message="How many providers are from Texas?",
                    semantic_model=self.semantic_model,
                    semantic_model_key="default-model",
                    debug=True,
                )
            ),
            service.handle_turn(
                ChatTurnRequest(
                    session_id="session-regression",
                    message="How many of them are oncologists?",
                    semantic_model=self.semantic_model,
                    semantic_model_key="default-model",
                    debug=True,
                )
            ),
            service.handle_turn(
                ChatTurnRequest(
                    session_id="session-regression",
                    message="Highest reimbursement from Texas in 2020?",
                    semantic_model=self.semantic_model,
                    semantic_model_key="default-model",
                    debug=True,
                )
            ),
            service.handle_turn(
                ChatTurnRequest(
                    session_id="session-regression",
                    message="Do the same for 2021.",
                    semantic_model=self.semantic_model,
                    semantic_model_key="default-model",
                    debug=True,
                )
            ),
            service.handle_turn(
                ChatTurnRequest(
                    session_id="session-regression",
                    message="Go back to the provider count one.",
                    semantic_model=self.semantic_model,
                    semantic_model_key="default-model",
                    debug=True,
                )
            ),
        ]

        self.assertEqual(
            responses[1].resolved_question,
            "How many Texas providers are oncologists?",
        )
        self.assertTrue(responses[1].memory_debug.used_active_context)

        self.assertEqual(
            responses[3].resolved_question,
            "Highest reimbursement from Texas in 2021?",
        )
        self.assertTrue(responses[3].memory_debug.used_active_context)

        self.assertEqual(
            responses[4].resolved_question,
            "How many Texas providers are oncologists?",
        )
        self.assertEqual(
            responses[4].memory_debug.used_snapshot_id,
            "topic-provider-count",
        )

        saved_session = store.get("session-regression")
        self.assertEqual(saved_session.active_context.topic_label, "Texas providers")
        self.assertEqual(saved_session.active_context.metric, "provider_count")
        self.assertEqual(saved_session.active_context.filters["provider_state"], "Texas")
        self.assertEqual(
            saved_session.active_context.filters["provider_specialty"],
            "oncologist",
        )
        self.assertEqual(len(saved_session.snapshots), 1)
        self.assertEqual(saved_session.snapshots[0].snapshot_id, "topic-provider-count")

    def test_service_regression_switches_grounded_assets_and_restores_them_within_one_session(self) -> None:
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            decisions=[
                {
                    "turn_type": "fresh",
                    "operation_type": "switch_topic",
                    "resolved_question": "How many providers are from Texas?",
                    "use_active_context": False,
                    "semantic_change_request": {
                        "filters_to_add": [
                            {
                                "field_key": "provider_state",
                                "operator": "=",
                                "value": "Texas",
                                "source_field": None,
                                "rationale": "Create the Texas provider cohort.",
                            }
                        ],
                        "measure_change": {
                            "name": "provider_count",
                            "aggregation": "count_distinct",
                            "target": "provider",
                            "source_field": "npi",
                            "description": None,
                        },
                        "notes": "Count Texas providers.",
                    },
                    "state_patch": {
                        "topic_id": "topic-provider-count",
                        "topic_label": "Texas providers",
                    },
                },
                {
                    "turn_type": "follow_up",
                    "operation_type": "add_filter",
                    "resolved_question": "How many Texas providers are oncologists?",
                    "use_active_context": True,
                    "semantic_change_request": {
                        "filters_to_add": [
                            {
                                "field_key": "provider_specialty",
                                "operator": "=",
                                "value": "oncologist",
                                "source_field": None,
                                "rationale": "Refine the Texas provider cohort to oncologists.",
                            }
                        ],
                        "notes": "Narrow the provider cohort to oncologists.",
                    },
                    "state_patch": {},
                },
                {
                    "turn_type": "fresh",
                    "operation_type": "switch_topic",
                    "resolved_question": "Highest reimbursement from Texas in 2020?",
                    "use_active_context": False,
                    "semantic_change_request": {
                        "filters_to_add": [
                            {
                                "field_key": "provider_state",
                                "operator": "=",
                                "value": "Texas",
                                "source_field": None,
                                "rationale": "Stay inside Texas providers.",
                            }
                        ],
                        "time_scope_change": {
                            "field_key": "service_year",
                            "source_field": "year",
                            "year": 2020,
                            "start_year": None,
                            "end_year": None,
                            "description": "Focus on 2020.",
                        },
                        "ranking_change": {
                            "sort_by": "estimated_total_reimbursement",
                            "direction": "desc",
                            "limit": 1,
                            "rank": None,
                        },
                        "notes": "Switch to the reimbursement ranking analysis.",
                    },
                    "state_patch": {
                        "topic_id": "topic-reimbursement",
                        "topic_label": "Texas reimbursement",
                    },
                },
                {
                    "turn_type": "follow_up",
                    "operation_type": "change_time_scope",
                    "resolved_question": "Highest reimbursement from Texas in 2021?",
                    "use_active_context": True,
                    "semantic_change_request": {
                        "time_scope_change": {
                            "field_key": "service_year",
                            "source_field": "year",
                            "year": 2021,
                            "start_year": None,
                            "end_year": None,
                            "description": "Move the reimbursement analysis to 2021.",
                        },
                        "notes": "Keep the reimbursement analysis and change the year.",
                    },
                    "state_patch": {},
                },
                {
                    "turn_type": "historical_callback",
                    "operation_type": "return_to_snapshot",
                    "resolved_question": "How many Texas providers are oncologists?",
                    "use_active_context": False,
                    "target_snapshot_id": "topic-provider-count",
                    "semantic_change_request": {
                        "notes": "Return to the earlier Texas provider analysis.",
                    },
                    "state_patch": {},
                },
            ]
        )
        asset_selector = FakeAssetSelectorService(
            plans=[
                AssetSelectionPlan(
                    base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
                    selected_tables=[
                        SelectedTable(
                            table_name="npidata",
                            qualified_name="vertex-poc-465616.medicarePhysicianFT.npidata",
                            role="base",
                            required_fields=["npi", "provider_business_practice_location_address_state_name"],
                        )
                    ],
                    entity="provider",
                    entity_key_field="npi",
                    grain_description="One row per provider record.",
                    measure_intent="count providers",
                    rationale="Use the provider master table for provider cohort counting.",
                ),
                AssetSelectionPlan(
                    base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
                    selected_tables=[
                        SelectedTable(
                            table_name="npidata",
                            qualified_name="vertex-poc-465616.medicarePhysicianFT.npidata",
                            role="base",
                            required_fields=["npi", "provider_business_practice_location_address_state_name", "provider_taxonomy_code_1"],
                        ),
                        SelectedTable(
                            table_name="CMS_Specialty_Taxonomy_Crosswalk",
                            qualified_name="vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                            role="join",
                            required_fields=["Provider_Taxonomy_Code", "CMS_SPECIALTY_DESCRIPTION"],
                        ),
                    ],
                    selected_joins=[
                        SelectedJoin(
                            left_table_name="npidata",
                            left_field_name="provider_taxonomy_code_1",
                            right_table_name="CMS_Specialty_Taxonomy_Crosswalk",
                            right_field_name="Provider_Taxonomy_Code",
                            join_type="left",
                        )
                    ],
                    entity="provider",
                    entity_key_field="npi",
                    grain_description="One row per provider after specialty lookup.",
                    measure_intent="count providers",
                    filters_summary=["provider_state = Texas", "provider_specialty = oncologist"],
                    rationale="Stay on provider grain and join to specialty mapping only for specialty filtering.",
                ),
                AssetSelectionPlan(
                    base_table="vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                    selected_tables=[
                        SelectedTable(
                            table_name="MedicareBillingData",
                            qualified_name="vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                            role="base",
                            required_fields=["Rndrng_NPI", "Rndrng_Prvdr_State_Abrvtn", "year", "Avg_Sbmtd_Chrg"],
                        )
                    ],
                    entity="provider",
                    entity_key_field="Rndrng_NPI",
                    grain_description="One row per rendering-provider billing record.",
                    ranking_intent="highest reimbursement",
                    filters_summary=["provider_state = Texas", "service_year = 2020"],
                    rationale="Use the billing fact table for reimbursement ranking.",
                ),
                AssetSelectionPlan(
                    base_table="vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                    selected_tables=[
                        SelectedTable(
                            table_name="MedicareBillingData",
                            qualified_name="vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                            role="base",
                            required_fields=["Rndrng_NPI", "Rndrng_Prvdr_State_Abrvtn", "year", "Avg_Sbmtd_Chrg"],
                        )
                    ],
                    entity="provider",
                    entity_key_field="Rndrng_NPI",
                    grain_description="One row per rendering-provider billing record.",
                    ranking_intent="highest reimbursement",
                    filters_summary=["provider_state = Texas", "service_year = 2021"],
                    rationale="Keep the billing fact table and move only the year.",
                ),
                AssetSelectionPlan(
                    base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
                    selected_tables=[
                        SelectedTable(
                            table_name="npidata",
                            qualified_name="vertex-poc-465616.medicarePhysicianFT.npidata",
                            role="base",
                            required_fields=["npi", "provider_business_practice_location_address_state_name", "provider_taxonomy_code_1"],
                        ),
                        SelectedTable(
                            table_name="CMS_Specialty_Taxonomy_Crosswalk",
                            qualified_name="vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                            role="join",
                            required_fields=["Provider_Taxonomy_Code", "CMS_SPECIALTY_DESCRIPTION"],
                        ),
                    ],
                    selected_joins=[
                        SelectedJoin(
                            left_table_name="npidata",
                            left_field_name="provider_taxonomy_code_1",
                            right_table_name="CMS_Specialty_Taxonomy_Crosswalk",
                            right_field_name="Provider_Taxonomy_Code",
                            join_type="left",
                        )
                    ],
                    entity="provider",
                    entity_key_field="npi",
                    grain_description="One row per provider after specialty lookup.",
                    filters_summary=["provider_state = Texas", "provider_specialty = oncologist"],
                    rationale="Restore the earlier provider-specialty analysis.",
                ),
            ]
        )
        sql_service = FakeSqlGenerationService()
        service = ChatSessionService(
            sql_generation_service=sql_service,
            store=store,
            reasoner=reasoner,
            asset_selector_service=asset_selector,
        )

        responses = [
            service.handle_turn(
                ChatTurnRequest(
                    session_id="session-grounded-regression",
                    message="How many providers are from Texas?",
                    semantic_model=self.semantic_model,
                    semantic_model_key="default-model",
                    debug=True,
                )
            ),
            service.handle_turn(
                ChatTurnRequest(
                    session_id="session-grounded-regression",
                    message="How many of them are oncologists?",
                    semantic_model=self.semantic_model,
                    semantic_model_key="default-model",
                    debug=True,
                )
            ),
            service.handle_turn(
                ChatTurnRequest(
                    session_id="session-grounded-regression",
                    message="Highest reimbursement from Texas in 2020?",
                    semantic_model=self.semantic_model,
                    semantic_model_key="default-model",
                    debug=True,
                )
            ),
            service.handle_turn(
                ChatTurnRequest(
                    session_id="session-grounded-regression",
                    message="Do the same for 2021.",
                    semantic_model=self.semantic_model,
                    semantic_model_key="default-model",
                    debug=True,
                )
            ),
            service.handle_turn(
                ChatTurnRequest(
                    session_id="session-grounded-regression",
                    message="Go back to the provider count one.",
                    semantic_model=self.semantic_model,
                    semantic_model_key="default-model",
                    debug=True,
                )
            ),
        ]

        self.assertEqual(len(sql_service.calls), 5)
        self.assertEqual(
            responses[0].memory_debug.selected_base_table,
            "vertex-poc-465616.medicarePhysicianFT.npidata",
        )
        self.assertEqual(
            [table["qualified_name"] for table in sql_service.calls[0].semantic_model["tables"]],
            ["vertex-poc-465616.medicarePhysicianFT.npidata"],
        )

        self.assertEqual(
            responses[1].memory_debug.selected_base_table,
            "vertex-poc-465616.medicarePhysicianFT.npidata",
        )
        self.assertEqual(
            {
                table["qualified_name"]
                for table in sql_service.calls[1].semantic_model["tables"]
            },
            {
                "vertex-poc-465616.medicarePhysicianFT.npidata",
                "vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
            },
        )

        self.assertEqual(
            responses[2].memory_debug.selected_base_table,
            "vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
        )
        self.assertEqual(
            [table["qualified_name"] for table in sql_service.calls[2].semantic_model["tables"]],
            ["vertex-poc-465616.medicarePhysicianFT.MedicareBillingData"],
        )
        self.assertEqual(
            responses[3].memory_debug.selected_base_table,
            "vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
        )
        self.assertEqual(
            responses[4].memory_debug.selected_base_table,
            "vertex-poc-465616.medicarePhysicianFT.npidata",
        )
        self.assertEqual(
            responses[4].memory_debug.used_snapshot_id,
            "topic-provider-count",
        )
        self.assertEqual(
            responses[4].memory_debug.selected_tables,
            [
                "vertex-poc-465616.medicarePhysicianFT.npidata",
                "vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
            ],
        )
        self.assertEqual(responses[0].memory_debug.sql_duration_ms, 7)
        self.assertIsNotNone(responses[0].memory_debug.chat_duration_ms)

    def test_api_regression_same_session_follow_up_uses_continuity(self) -> None:
        store = InMemorySessionStore()
        reasoner = FakeMemoryReasoner(
            decisions=[
                {
                    "turn_type": "fresh",
                    "operation_type": "switch_topic",
                    "resolved_question": "How many providers are from Texas?",
                    "use_active_context": False,
                    "semantic_change_request": {
                        "filters_to_add": [
                            {
                                "field_key": "provider_state",
                                "operator": "=",
                                "value": "Texas",
                                "source_field": None,
                                "rationale": "The user is asking for the Texas provider cohort.",
                            }
                        ],
                        "measure_change": {
                            "name": "provider_count",
                            "aggregation": "count_distinct",
                            "target": "provider",
                            "source_field": "npi",
                            "description": None,
                        },
                        "notes": "Count Texas providers.",
                    },
                    "state_patch": {
                        "topic_id": "topic-provider-count",
                        "topic_label": "Texas providers",
                        "tables": [
                            "vertex-poc-465616.medicarePhysicianFT.npidata"
                        ],
                    },
                },
                {
                    "turn_type": "follow_up",
                    "operation_type": "add_filter",
                    "resolved_question": "How many Texas providers are oncologists?",
                    "use_active_context": True,
                    "semantic_change_request": {
                        "filters_to_add": [
                            {
                                "field_key": "provider_specialty",
                                "operator": "=",
                                "value": "oncologist",
                                "source_field": None,
                                "rationale": "The user is narrowing the provider cohort.",
                            }
                        ],
                        "notes": "Refine the current provider cohort to oncologists.",
                    },
                    "state_patch": {},
                },
            ]
        )
        sql_service = FakeSqlGenerationService()
        service = ChatSessionService(
            sql_generation_service=sql_service,
            store=store,
            reasoner=reasoner,
        )

        app = create_app()
        app.dependency_overrides[get_chat_session_service] = lambda: service
        client = TestClient(app)

        try:
            first = client.post(
                "/api/v1/chat/turn",
                json={
                    "session_id": "session-api-regression",
                    "message": "How many providers are from Texas?",
                    "semantic_model": self.semantic_model,
                    "semantic_model_key": "default-model",
                    "debug": True,
                },
            )
            second = client.post(
                "/api/v1/chat/turn",
                json={
                    "session_id": "session-api-regression",
                    "message": "How many of them are oncologists?",
                    "semantic_model": self.semantic_model,
                    "semantic_model_key": "default-model",
                    "debug": True,
                },
            )
        finally:
            app.dependency_overrides.clear()

        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 200)

        first_body = first.json()
        second_body = second.json()

        self.assertEqual(first_body["turn_type"], "fresh")
        self.assertEqual(second_body["turn_type"], "follow_up")
        self.assertEqual(
            second_body["resolved_question"],
            "How many Texas providers are oncologists?",
        )
        self.assertTrue(second_body["memory_debug"]["used_active_context"])
        self.assertIn("chat_duration_ms", second_body["memory_debug"])
        self.assertIn("sql_duration_ms", second_body["memory_debug"])
        self.assertEqual(
            second_body["sql_result"]["sql"],
            "SELECT 'How many Texas providers are oncologists?' AS resolved_question",
        )


if __name__ == "__main__":
    unittest.main()
