from __future__ import annotations

import time
import unittest
from unittest.mock import patch

from backend.app.memory.state import ContextSnapshot, ConversationMessage, SessionMemory
from backend.app.memory.store import InMemorySessionStore


class InMemorySessionStoreTests(unittest.TestCase):
    def test_save_and_get_round_trip_returns_copy(self) -> None:
        store = InMemorySessionStore()
        session = SessionMemory(
            session_id="session-1",
            turn_index=1,
            messages=[
                ConversationMessage(
                    role="user",
                    content="How many specialties are there?",
                    turn_index=1,
                )
            ],
        )

        store.save(session)
        loaded_session = store.get("session-1")

        self.assertIsNotNone(loaded_session)
        self.assertEqual(loaded_session.session_id, "session-1")
        self.assertEqual(len(loaded_session.messages), 1)

        loaded_session.messages.append(
            ConversationMessage(
                role="assistant",
                content="Injected locally without saving.",
                turn_index=1,
            )
        )
        reloaded_session = store.get("session-1")
        self.assertEqual(len(reloaded_session.messages), 1)

    def test_save_caps_messages_and_snapshots(self) -> None:
        store = InMemorySessionStore(max_recent_messages=2, max_snapshots=2)
        session = SessionMemory(
            session_id="session-2",
            turn_index=4,
            messages=[
                ConversationMessage(role="user", content="Turn 1", turn_index=1),
                ConversationMessage(role="assistant", content="Turn 2", turn_index=1),
                ConversationMessage(role="user", content="Turn 3", turn_index=2),
            ],
            snapshots=[
                ContextSnapshot(snapshot_id="snap-1", topic_label="Topic 1"),
                ContextSnapshot(snapshot_id="snap-2", topic_label="Topic 2"),
                ContextSnapshot(snapshot_id="snap-3", topic_label="Topic 3"),
            ],
        )

        saved_session = store.save(session)

        self.assertEqual([message.content for message in saved_session.messages], ["Turn 2", "Turn 3"])
        self.assertEqual([snapshot.snapshot_id for snapshot in saved_session.snapshots], ["snap-2", "snap-3"])

        loaded_session = store.get("session-2")
        self.assertEqual([message.content for message in loaded_session.messages], ["Turn 2", "Turn 3"])
        self.assertEqual([snapshot.snapshot_id for snapshot in loaded_session.snapshots], ["snap-2", "snap-3"])

    def test_clear_removes_existing_session(self) -> None:
        store = InMemorySessionStore()
        store.save(SessionMemory(session_id="session-3"))

        self.assertTrue(store.clear("session-3"))
        self.assertIsNone(store.get("session-3"))
        self.assertFalse(store.clear("session-3"))

    def test_store_rejects_invalid_configuration_and_blank_ids(self) -> None:
        with self.assertRaises(ValueError):
            InMemorySessionStore(max_recent_messages=0)

        with self.assertRaises(ValueError):
            InMemorySessionStore(max_snapshots=0)

        with self.assertRaises(ValueError):
            InMemorySessionStore(session_ttl_seconds=0)

        with self.assertRaises(ValueError):
            InMemorySessionStore(session_ttl_seconds=-1)

        store = InMemorySessionStore()
        with self.assertRaises(ValueError):
            store.get("   ")

        with self.assertRaises(ValueError):
            store.clear("   ")

    # ------------------------------------------------------------------ Gap #14

    def test_expired_session_returns_none_on_get(self) -> None:
        store = InMemorySessionStore(session_ttl_seconds=60)
        store.save(SessionMemory(session_id="s1"))

        # Simulate 61 seconds passing since last access.
        with patch("backend.app.memory.store.time") as mock_time:
            mock_time.monotonic.return_value = time.monotonic() + 61
            result = store.get("s1")

        self.assertIsNone(result)

    def test_expired_session_is_evicted_from_storage(self) -> None:
        store = InMemorySessionStore(session_ttl_seconds=60)
        store.save(SessionMemory(session_id="s2"))
        self.assertEqual(store.active_session_count, 1)

        with patch("backend.app.memory.store.time") as mock_time:
            mock_time.monotonic.return_value = time.monotonic() + 61
            store.get("s2")  # triggers eviction on the expired entry

        self.assertEqual(store.active_session_count, 0)

    def test_session_ttl_refreshes_on_get_and_save(self) -> None:
        """A session accessed just before TTL expiry must not be evicted."""
        t0 = time.monotonic()
        store = InMemorySessionStore(session_ttl_seconds=60)

        with patch("backend.app.memory.store.time") as mock_time:
            mock_time.monotonic.return_value = t0
            store.save(SessionMemory(session_id="s3"))

            # Access at t=55 (within TTL) — should refresh the clock
            mock_time.monotonic.return_value = t0 + 55
            result = store.get("s3")
            self.assertIsNotNone(result)

            # Now at t=110 — 55s since last access, still within TTL
            mock_time.monotonic.return_value = t0 + 110
            result = store.get("s3")
            self.assertIsNotNone(result)

            # At t=171 — 61s since last access, now expired
            mock_time.monotonic.return_value = t0 + 171
            result = store.get("s3")
            self.assertIsNone(result)

    def test_clear_expired_evicts_only_stale_sessions(self) -> None:
        t0 = time.monotonic()
        store = InMemorySessionStore(session_ttl_seconds=60)

        with patch("backend.app.memory.store.time") as mock_time:
            mock_time.monotonic.return_value = t0
            store.save(SessionMemory(session_id="fresh"))
            store.save(SessionMemory(session_id="stale"))

            # Refresh "fresh" at t=50 (still within 60s TTL from initial save).
            # "stale" is not accessed again, so its last_accessed stays at t0.
            mock_time.monotonic.return_value = t0 + 50
            store.get("fresh")  # _last_accessed["fresh"] = t0+50

            # At t=61: stale (last at t0) → 61s ago → expired.
            #           fresh (last at t0+50) → 11s ago → NOT expired.
            mock_time.monotonic.return_value = t0 + 61
            evicted = store.clear_expired()

        self.assertEqual(evicted, 1)
        self.assertIsNone(store.get("stale"))
        self.assertIsNotNone(store.get("fresh"))

    def test_clear_expired_returns_zero_when_nothing_to_evict(self) -> None:
        store = InMemorySessionStore(session_ttl_seconds=3600)
        store.save(SessionMemory(session_id="s4"))
        self.assertEqual(store.clear_expired(), 0)

    def test_active_session_count_reflects_live_sessions(self) -> None:
        store = InMemorySessionStore()
        self.assertEqual(store.active_session_count, 0)
        store.save(SessionMemory(session_id="a"))
        store.save(SessionMemory(session_id="b"))
        self.assertEqual(store.active_session_count, 2)
        store.clear("a")
        self.assertEqual(store.active_session_count, 1)

    def test_non_expired_session_not_affected(self) -> None:
        """Sessions well within TTL must be returned normally."""
        store = InMemorySessionStore(session_ttl_seconds=3600)
        store.save(SessionMemory(session_id="live"))
        self.assertIsNotNone(store.get("live"))
        self.assertIsNotNone(store.get("live"))

    # ------------------------------------------------------------------ Gap #4

    def test_snapshot_eviction_emits_warning(self) -> None:
        """Saving a session that exceeds max_snapshots must log a warning
        naming the evicted snapshot IDs."""
        store = InMemorySessionStore(max_snapshots=2)
        session = SessionMemory(
            session_id="eviction-warn",
            snapshots=[
                ContextSnapshot(snapshot_id="snap-1", topic_label="Topic 1"),
                ContextSnapshot(snapshot_id="snap-2", topic_label="Topic 2"),
                ContextSnapshot(snapshot_id="snap-3", topic_label="Topic 3"),
            ],
        )
        with self.assertLogs("backend.app.memory.store", level="WARNING") as log_ctx:
            store.save(session)

        self.assertEqual(len(log_ctx.records), 1)
        msg = log_ctx.records[0].getMessage()
        self.assertIn("snap-1", msg)
        self.assertNotIn("snap-2", msg)
        self.assertNotIn("snap-3", msg)

    def test_no_warning_when_snapshot_cap_not_exceeded(self) -> None:
        """Saving within the snapshot cap must not produce any warning."""
        import logging
        store = InMemorySessionStore(max_snapshots=3)
        session = SessionMemory(
            session_id="no-eviction",
            snapshots=[
                ContextSnapshot(snapshot_id="snap-1"),
                ContextSnapshot(snapshot_id="snap-2"),
                ContextSnapshot(snapshot_id="snap-3"),
            ],
        )
        with self.assertNoLogs("backend.app.memory.store", level="WARNING"):
            store.save(session)

    def test_warning_names_all_evicted_snapshots(self) -> None:
        """When multiple snapshots are evicted the warning must name all of them."""
        store = InMemorySessionStore(max_snapshots=2)
        session = SessionMemory(
            session_id="multi-evict",
            snapshots=[
                ContextSnapshot(snapshot_id="old-1"),
                ContextSnapshot(snapshot_id="old-2"),
                ContextSnapshot(snapshot_id="old-3"),
                ContextSnapshot(snapshot_id="keep-1"),
                ContextSnapshot(snapshot_id="keep-2"),
            ],
        )
        with self.assertLogs("backend.app.memory.store", level="WARNING") as log_ctx:
            store.save(session)

        msg = log_ctx.records[0].getMessage()
        self.assertIn("old-1", msg)
        self.assertIn("old-2", msg)
        self.assertIn("old-3", msg)
        self.assertNotIn("keep-1", msg)
        self.assertNotIn("keep-2", msg)
        # Only 2 snapshots retained.
        saved = store.get("multi-evict")
        self.assertEqual([s.snapshot_id for s in saved.snapshots], ["keep-1", "keep-2"])


if __name__ == "__main__":
    unittest.main()
