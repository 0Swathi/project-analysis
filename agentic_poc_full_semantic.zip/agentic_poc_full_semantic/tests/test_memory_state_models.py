from __future__ import annotations

import unittest

from backend.app.memory.memory_contracts import (
    ContextPacket,
    GroundedContextResult,
    SemanticChangeRequest,
)
from backend.app.memory.state import (
    ActiveContext,
    AnalyticalContext,
    AnalyticalCohort,
    AnalyticalFilter,
    AnalyticalGrouping,
    AnalyticalMeasure,
    AnalyticalRanking,
    AnalyticalTimeScope,
    ContextSnapshot,
    ReasonerDecision,
    ResolvedAssets,
    StatePatch,
)
from backend.app.schemas.asset_selection import (
    AssetSelectionPlan,
    SelectedJoin,
    SelectedTable,
)


class MemoryStateModelTests(unittest.TestCase):
    def test_active_context_can_represent_texas_provider_cohort(self) -> None:
        context = ActiveContext(
            topic_id="provider-count-tx",
            topic_label="Texas providers",
            dataset_name="medicarePhysicianFT",
            analytical_context=AnalyticalContext(
                topic_summary="Count providers from Texas.",
                entity="provider",
                entity_key="npi",
                cohort=AnalyticalCohort(
                    entity_scope="provider",
                    description="Providers from Texas.",
                    filters=[
                        AnalyticalFilter(
                            field_key="provider_state",
                            operator="=",
                            value="Texas",
                            source_field="provider_business_practice_location_address_state_name",
                        )
                    ],
                ),
                measure=AnalyticalMeasure(
                    name="provider_count",
                    aggregation="count_distinct",
                    target="provider",
                    source_field="npi",
                ),
                resolved_assets=ResolvedAssets(
                    base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
                    tables_used=["vertex-poc-465616.medicarePhysicianFT.npidata"],
                    entity_key_field="npi",
                ),
                last_question="How many providers are from Texas?",
            ),
        )

        self.assertEqual(context.analytical_context.entity, "provider")
        self.assertEqual(context.analytical_context.entity_key, "npi")
        self.assertEqual(
            context.analytical_context.cohort.filters[0].value,
            "Texas",
        )
        self.assertEqual(
            context.analytical_context.resolved_assets.base_table,
            "vertex-poc-465616.medicarePhysicianFT.npidata",
        )

    def test_analytical_context_can_patch_year_without_losing_measure(self) -> None:
        reimbursement_context = AnalyticalContext(
            topic_summary="Highest reimbursement from Texas in 2020.",
            entity="provider",
            entity_key="Rndrng_NPI",
            cohort=AnalyticalCohort(
                entity_scope="provider",
                description="Texas providers.",
                filters=[
                    AnalyticalFilter(
                        field_key="provider_state",
                        operator="=",
                        value="Texas",
                        source_field="Rndrng_Prvdr_State_Abrvtn",
                    )
                ],
            ),
            measure=AnalyticalMeasure(
                name="estimated_total_reimbursement",
                aggregation="sum",
                target="provider_reimbursement",
                source_field="Avg_Mdcr_Pymt_Amt",
            ),
            time_scope=AnalyticalTimeScope(
                field_key="service_year",
                source_field="year",
                year=2020,
            ),
            ranking=AnalyticalRanking(sort_by="estimated_total_reimbursement", direction="desc", limit=1),
            resolved_assets=ResolvedAssets(
                base_table="vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                tables_used=["vertex-poc-465616.medicarePhysicianFT.MedicareBillingData"],
                entity_key_field="Rndrng_NPI",
            ),
            last_question="Highest reimbursement from Texas in 2020?",
        )

        patched_context = reimbursement_context.model_copy(
            update={
                "time_scope": AnalyticalTimeScope(
                    field_key="service_year",
                    source_field="year",
                    year=2021,
                )
            }
        )

        self.assertEqual(reimbursement_context.measure.name, "estimated_total_reimbursement")
        self.assertEqual(reimbursement_context.time_scope.year, 2020)
        self.assertEqual(patched_context.time_scope.year, 2021)
        self.assertEqual(patched_context.measure.name, "estimated_total_reimbursement")
        self.assertEqual(patched_context.cohort.filters[0].value, "Texas")

    def test_snapshot_preserves_analytical_context_completely(self) -> None:
        snapshot = ContextSnapshot(
            snapshot_id="snap-provider-count",
            topic_label="Texas provider count",
            analytical_context=AnalyticalContext(
                entity="provider",
                entity_key="npi",
                cohort=AnalyticalCohort(
                    description="Texas providers.",
                    filters=[
                        AnalyticalFilter(
                            field_key="provider_state",
                            operator="=",
                            value="Texas",
                        )
                    ],
                ),
                measure=AnalyticalMeasure(
                    name="provider_count",
                    aggregation="count_distinct",
                    target="provider",
                ),
                groupings=[AnalyticalGrouping(key="provider_type")],
                resolved_assets=ResolvedAssets(
                    base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
                    tables_used=["vertex-poc-465616.medicarePhysicianFT.npidata"],
                ),
            ),
        )

        self.assertEqual(snapshot.analytical_context.entity, "provider")
        self.assertEqual(snapshot.analytical_context.measure.name, "provider_count")
        self.assertEqual(snapshot.analytical_context.groupings[0].key, "provider_type")

    def test_active_context_can_capture_asset_selection_plan_and_thin_grounding_fields(self) -> None:
        plan = AssetSelectionPlan(
            base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
            selected_tables=[
                SelectedTable(
                    table_name="npidata",
                    role="base",
                    required_fields=["npi"],
                )
            ],
            selected_joins=[
                SelectedJoin(
                    left_table_name="npidata",
                    left_field_name="npi",
                    right_table_name="MedicareBillingData",
                    right_field_name="Rndrng_NPI",
                    relationship_type="one_to_many",
                )
            ],
            entity="provider",
            entity_key_field="npi",
            grain_description="One row per provider.",
            rationale="Provider identity and inventory come from npidata.",
        )
        context = ActiveContext(
            topic_label="Texas providers",
            base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
            tables_used=[
                "vertex-poc-465616.medicarePhysicianFT.npidata",
                "vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
            ],
            join_path=[
                "vertex-poc-465616.medicarePhysicianFT.npidata.npi = vertex-poc-465616.medicarePhysicianFT.MedicareBillingData.Rndrng_NPI"
            ],
            entity_key_field="npi",
            grain_description="One row per provider.",
            selection_rationale="Use provider master for entity counting.",
            asset_selection_plan=plan,
        )

        self.assertEqual(context.base_table, "vertex-poc-465616.medicarePhysicianFT.npidata")
        self.assertEqual(context.entity_key_field, "npi")
        self.assertEqual(context.asset_selection_plan.selected_tables[0].table_name, "npidata")

    def test_snapshot_can_preserve_asset_selection_plan_for_historical_callback(self) -> None:
        snapshot = ContextSnapshot(
            snapshot_id="snap-asset-plan",
            base_table="vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
            tables_used=[
                "vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk"
            ],
            entity_key_field="CMS_SPECIALTY_CODE",
            grain_description="One row per CMS specialty code.",
            selection_rationale="This table is the source of truth for CMS specialty definitions.",
            asset_selection_plan=AssetSelectionPlan(
                base_table="vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                selected_tables=[
                    SelectedTable(
                        table_name="CMS_Specialty_Taxonomy_Crosswalk",
                        role="base",
                        required_fields=["CMS_SPECIALTY_CODE"],
                    )
                ],
                entity="specialty",
                entity_key_field="CMS_SPECIALTY_CODE",
                grain_description="One row per CMS specialty code.",
                business_intent="Count specialties.",
                measure_intent="count distinct specialties",
            ),
        )

        self.assertEqual(snapshot.asset_selection_plan.entity, "specialty")
        self.assertEqual(snapshot.selection_rationale, "This table is the source of truth for CMS specialty definitions.")

    def test_context_packet_validates_locked_constraints_and_requested_operation(self) -> None:
        active_context = AnalyticalContext(
            entity="provider",
            entity_key="npi",
            cohort=AnalyticalCohort(
                description="Texas providers.",
                filters=[AnalyticalFilter(field_key="provider_state", operator="=", value="Texas")],
            ),
            measure=AnalyticalMeasure(name="provider_count", aggregation="count_distinct", target="provider"),
        )
        packet = ContextPacket(
            session_id="session-1",
            user_message="How many of them are oncologists?",
            requested_operation="refine_current_context",
            turn_type="follow_up",
            semantic_model_key="default-model",
            active_context=active_context,
            locked_constraints=active_context,
            change_request=SemanticChangeRequest(
                filters_to_add=[
                    AnalyticalFilter(
                        field_key="provider_specialty",
                        operator="=",
                        value="oncologist",
                    )
                ],
                notes="Keep the current Texas provider cohort and refine it to oncologists.",
            ),
        )

        self.assertEqual(packet.requested_operation, "refine_current_context")
        self.assertEqual(packet.locked_constraints.entity, "provider")
        self.assertEqual(packet.change_request.filters_to_add[0].value, "oncologist")

    def test_grounded_context_result_validates_multi_table_context(self) -> None:
        grounded = GroundedContextResult(
            grounded_context=AnalyticalContext(
                topic_summary="Texas oncologist providers.",
                entity="provider",
                entity_key="npi",
                cohort=AnalyticalCohort(
                    description="Texas providers refined to oncologists.",
                    filters=[
                        AnalyticalFilter(field_key="provider_state", operator="=", value="Texas"),
                        AnalyticalFilter(field_key="provider_specialty", operator="=", value="oncologist"),
                    ],
                ),
                measure=AnalyticalMeasure(
                    name="provider_count",
                    aggregation="count_distinct",
                    target="provider",
                ),
                resolved_assets=ResolvedAssets(
                    base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
                    tables_used=[
                        "vertex-poc-465616.medicarePhysicianFT.npidata",
                        "vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
                    ],
                    join_path=[
                        "vertex-poc-465616.medicarePhysicianFT.npidata.npi = vertex-poc-465616.medicarePhysicianFT.MedicareBillingData.Rndrng_NPI"
                    ],
                    entity_key_field="npi",
                ),
            ),
            resolved_question="How many Texas providers are oncologists?",
            sql="SELECT COUNT(DISTINCT npi.npi) AS oncologist_provider_count FROM ...",
            explanation="Counts the Texas provider cohort after refining to oncologists.",
            tables_used=[
                "vertex-poc-465616.medicarePhysicianFT.npidata",
                "vertex-poc-465616.medicarePhysicianFT.MedicareBillingData",
            ],
            preserved_active_context=True,
        )

        self.assertTrue(grounded.preserved_active_context)
        self.assertEqual(len(grounded.grounded_context.resolved_assets.tables_used), 2)
        self.assertIn("Rndrng_NPI", grounded.grounded_context.resolved_assets.join_path[0])


class ActiveContextAutoSyncTests(unittest.TestCase):
    """Gap #8: thin fields on ActiveContext must auto-sync from analytical_context."""

    _BASE_TABLE = "schema.providers"
    _TABLES = ["schema.providers", "schema.claims"]

    def _make_analytical_context(self) -> AnalyticalContext:
        return AnalyticalContext(
            measure=AnalyticalMeasure(name="provider_count", aggregation="count_distinct"),
            groupings=[AnalyticalGrouping(key="specialty"), AnalyticalGrouping(key="state")],
            cohort=AnalyticalCohort(
                filters=[AnalyticalFilter(field_key="provider_state", operator="=", value="TX")]
            ),
            time_scope=AnalyticalTimeScope(field_key="year", year=2022),
            resolved_assets=ResolvedAssets(
                base_table=self._BASE_TABLE,
                tables_used=self._TABLES,
                join_path=["schema.providers.npi = schema.claims.Rndrng_NPI"],
                entity_key_field="npi",
                grain_description="One row per provider.",
                selection_rationale="Primary entity table.",
            ),
        )

    def test_construction_with_analytical_context_auto_populates_thin_fields(self) -> None:
        ctx = self._make_analytical_context()
        active = ActiveContext(topic_label="providers", analytical_context=ctx)

        self.assertEqual(active.base_table, self._BASE_TABLE)
        self.assertEqual(active.tables_used, self._TABLES)
        self.assertEqual(active.tables, self._TABLES)
        self.assertEqual(active.metric, "provider_count")
        self.assertEqual(active.dimensions, ["specialty", "state"])
        self.assertEqual(active.filters["provider_state"], "TX")
        self.assertEqual(active.filters["year"], 2022)
        self.assertEqual(active.join_path, ["schema.providers.npi = schema.claims.Rndrng_NPI"])
        self.assertEqual(active.entity_key_field, "npi")
        self.assertEqual(active.grain_description, "One row per provider.")
        self.assertEqual(active.selection_rationale, "Primary entity table.")

    def test_post_construction_assignment_auto_syncs_thin_fields(self) -> None:
        """Assigning analytical_context after construction must sync thin fields."""
        active = ActiveContext(topic_label="providers")
        self.assertIsNone(active.base_table)

        active.analytical_context = self._make_analytical_context()

        self.assertEqual(active.base_table, self._BASE_TABLE)
        self.assertEqual(active.metric, "provider_count")
        self.assertEqual(active.filters["provider_state"], "TX")

    def test_model_copy_preserves_synced_thin_fields(self) -> None:
        """model_copy must carry over the synced thin fields."""
        active = ActiveContext(topic_label="providers", analytical_context=self._make_analytical_context())
        copy = active.model_copy(deep=True)

        self.assertEqual(copy.base_table, self._BASE_TABLE)
        self.assertEqual(copy.metric, "provider_count")
        self.assertEqual(copy.dimensions, ["specialty", "state"])

    def test_no_analytical_context_leaves_thin_fields_as_manually_set(self) -> None:
        """When analytical_context is absent, thin fields set in the constructor must be preserved."""
        active = ActiveContext(
            topic_label="manual",
            base_table="manual.table",
            tables_used=["manual.table"],
            metric="my_metric",
            dimensions=["dim1"],
        )
        self.assertEqual(active.base_table, "manual.table")
        self.assertEqual(active.metric, "my_metric")
        self.assertEqual(active.dimensions, ["dim1"])

    def test_updating_analytical_context_overwrites_stale_thin_fields(self) -> None:
        """Replacing analytical_context must immediately update thin fields."""
        ctx_a = AnalyticalContext(
            measure=AnalyticalMeasure(name="metric_a"),
            resolved_assets=ResolvedAssets(base_table="schema.a", tables_used=["schema.a"]),
        )
        ctx_b = AnalyticalContext(
            measure=AnalyticalMeasure(name="metric_b"),
            resolved_assets=ResolvedAssets(base_table="schema.b", tables_used=["schema.b"]),
        )
        active = ActiveContext(analytical_context=ctx_a)
        self.assertEqual(active.base_table, "schema.a")
        self.assertEqual(active.metric, "metric_a")

        active.analytical_context = ctx_b
        self.assertEqual(active.base_table, "schema.b")
        self.assertEqual(active.metric, "metric_b")

    def test_null_resolved_assets_clears_asset_thin_fields(self) -> None:
        """If analytical_context has no resolved_assets the asset thin fields are cleared."""
        ctx_with_assets = AnalyticalContext(
            resolved_assets=ResolvedAssets(base_table="schema.x", tables_used=["schema.x"]),
        )
        active = ActiveContext(analytical_context=ctx_with_assets)
        self.assertEqual(active.base_table, "schema.x")

        ctx_no_assets = AnalyticalContext(measure=AnalyticalMeasure(name="count"))
        active.analytical_context = ctx_no_assets
        self.assertIsNone(active.base_table)
        self.assertEqual(active.tables_used, [])
        self.assertEqual(active.metric, "count")

    def test_filter_sync_handles_time_scope_year_range(self) -> None:
        """Year-range time scopes must produce a dict with start/end in filters."""
        ctx = AnalyticalContext(
            time_scope=AnalyticalTimeScope(field_key="service_year", start_year=2020, end_year=2023),
        )
        active = ActiveContext(analytical_context=ctx)
        self.assertIn("service_year", active.filters)
        self.assertEqual(active.filters["service_year"]["start_year"], 2020)
        self.assertEqual(active.filters["service_year"]["end_year"], 2023)


class StatePatchTypedSchemaTests(unittest.TestCase):
    """Gap #9: state_patch must be a typed StatePatch, not an untyped dict."""

    def test_empty_state_patch_has_correct_defaults(self) -> None:
        patch = StatePatch()
        self.assertIsNone(patch.metric)
        self.assertIsNone(patch.topic_id)
        self.assertEqual(patch.tables, [])
        self.assertEqual(patch.dimensions, [])
        self.assertEqual(patch.filters, {})

    def test_state_patch_validates_all_typed_fields(self) -> None:
        patch = StatePatch(
            topic_id="t-1",
            topic_label="providers",
            metric="count",
            tables=["schema.providers"],
            dimensions=["specialty"],
            filters={"state": "TX"},
        )
        self.assertEqual(patch.topic_id, "t-1")
        self.assertEqual(patch.metric, "count")
        self.assertEqual(patch.tables, ["schema.providers"])
        self.assertEqual(patch.dimensions, ["specialty"])
        self.assertEqual(patch.filters, {"state": "TX"})

    def test_null_list_fields_coerced_to_empty_list(self) -> None:
        """LLM may return null for list fields — must coerce to empty list."""
        patch = StatePatch(tables=None, dimensions=None)
        self.assertEqual(patch.tables, [])
        self.assertEqual(patch.dimensions, [])

    def test_filters_list_of_dicts_normalized_to_dict(self) -> None:
        """LLM may return filters as [{key, value}] — must normalize to {key: value}."""
        patch = StatePatch(filters=[{"key": "state", "value": "TX"}, {"key": "year", "value": 2022}])
        self.assertEqual(patch.filters, {"state": "TX", "year": 2022})

    def test_filters_null_coerced_to_empty_dict(self) -> None:
        patch = StatePatch(filters=None)
        self.assertEqual(patch.filters, {})

    def test_filters_list_skips_malformed_items(self) -> None:
        """Malformed filter items (missing key or non-string key) must be ignored."""
        patch = StatePatch(filters=[
            {"key": "state", "value": "TX"},
            {"value": "orphan"},          # missing "key"
            {"key": "", "value": "blank"},  # blank key
            {"key": "year", "value": 2022},
        ])
        self.assertEqual(patch.filters, {"state": "TX", "year": 2022})

    def test_reasoner_decision_state_patch_is_statepatch_object(self) -> None:
        """ReasonerDecision.state_patch must be a StatePatch instance, not a dict."""
        decision = ReasonerDecision(
            turn_type="fresh",
            state_patch={"metric": "count", "tables": ["schema.claims"]},
        )
        self.assertIsInstance(decision.state_patch, StatePatch)
        self.assertEqual(decision.state_patch.metric, "count")
        self.assertEqual(decision.state_patch.tables, ["schema.claims"])

    def test_reasoner_decision_default_state_patch_is_empty_statepatch(self) -> None:
        """Default state_patch must be an empty StatePatch, not an empty dict."""
        decision = ReasonerDecision(turn_type="fresh")
        self.assertIsInstance(decision.state_patch, StatePatch)
        self.assertIsNone(decision.state_patch.metric)
        self.assertEqual(decision.state_patch.tables, [])

    def test_state_patch_ignores_unknown_llm_keys(self) -> None:
        """extra='ignore' means unknown fields from the LLM are silently dropped."""
        patch = StatePatch(metric="count", unknown_future_field="ignored")
        self.assertEqual(patch.metric, "count")
        self.assertFalse(hasattr(patch, "unknown_future_field"))


if __name__ == "__main__":
    unittest.main()
