from __future__ import annotations

import unittest

from backend.app.core.errors import AssetSelectionError
from backend.app.memory.state import (
    ActiveContext,
    AnalyticalContext,
    AnalyticalCohort,
    AnalyticalFilter,
    ContextSnapshot,
    ConversationMessage,
    SessionMemory,
)
from backend.app.prompts.asset_selector_prompt import AssetSelectorPromptBuilder
from backend.app.services.asset_selector_service import (
    FakeAssetSelectorService,
    OpenAIAssetSelectorService,
)


class StubResponsesClient:
    def __init__(self, payload):
        self.payload = payload
        self.calls: list[dict] = []

    def generate_json(self, **kwargs):
        self.calls.append(kwargs)
        return self.payload


class AssetSelectorServiceTests(unittest.TestCase):
    def test_prompt_builder_includes_resolved_question_context_and_semantic_hints(self) -> None:
        builder = AssetSelectorPromptBuilder()
        session = SessionMemory(
            session_id="session-1",
            turn_index=2,
            rolling_summary="User is counting providers and refining specialty cohorts.",
            messages=[
                ConversationMessage(
                    role="user",
                    content="How many providers are from Texas?",
                    turn_index=1,
                ),
                ConversationMessage(
                    role="assistant",
                    content="There are 100 providers from Texas.",
                    turn_index=1,
                ),
            ],
            active_context=ActiveContext(
                topic_label="Texas providers",
                analytical_context=AnalyticalContext(
                    entity="provider",
                    cohort=AnalyticalCohort(
                        filters=[
                            AnalyticalFilter(
                                field_key="provider_state",
                                operator="=",
                                value="Texas",
                            )
                        ]
                    ),
                ),
            ),
        )
        snapshot = ContextSnapshot(
            snapshot_id="snap-1",
            topic_label="specialty mapping",
        )

        prompt = builder.build_user_prompt(
            message="how many of them are oncologists",
            resolved_question="How many Texas providers are oncologists?",
            session=session,
            semantic_model={
                "dataset_name": "medicarePhysicianFT",
                "dataset_description": "Healthcare analytics dataset",
                "domain": "healthcare_analytics",
                "selection_hints": ["Prefer provider master for provider counts."],
                "tables": [
                    {
                        "table_name": "npidata",
                        "qualified_name": "vertex-poc-465616.medicarePhysicianFT.npidata",
                        "table_description": "Provider master",
                        "canonical_entity": "provider",
                        "preferred_entity_key": "npi",
                        "grain_description": "One row per provider.",
                        "source_of_truth_for": ["provider inventory", "provider location"],
                        "selection_hints": ["Use first for provider counts."],
                        "fields": [
                            {
                                "name": "npi",
                                "description": "Provider key",
                                "data_type": "STRING",
                                "kind": "identifier",
                                "selection_hints": ["Use for counting providers."],
                            }
                        ],
                    }
                ],
                "relationships": [
                    {
                        "left": {"table_name": "npidata", "field_name": "npi"},
                        "right": {
                            "table_name": "MedicareBillingData",
                            "field_name": "Rndrng_NPI",
                        },
                        "relationship_type": "one_to_many",
                        "join_hint": "Use only when billing activity is needed.",
                    }
                ],
            },
            semantic_model_key="default-model",
            turn_type="follow_up",
            operation_type="refine_current_context",
            target_snapshot=snapshot,
        )

        self.assertIn("How many Texas providers are oncologists?", prompt)
        self.assertIn("Prefer provider master for provider counts.", prompt)
        self.assertIn("provider inventory", prompt)
        self.assertIn("Use only when billing activity is needed.", prompt)
        self.assertIn("snap-1", prompt)

    def test_response_schema_is_closed_and_requires_clarification_object(self) -> None:
        builder = AssetSelectorPromptBuilder()
        schema = builder.build_response_schema()["schema"]
        selected_tables = schema["properties"]["selected_tables"]["items"]
        selected_joins = schema["properties"]["selected_joins"]["items"]
        clarification = schema["properties"]["clarification"]

        self.assertFalse(schema["additionalProperties"])
        self.assertFalse(selected_tables["additionalProperties"])
        self.assertFalse(selected_joins["additionalProperties"])
        self.assertFalse(clarification["anyOf"][0]["additionalProperties"])
        self.assertIn("clarification", schema["required"])
        self.assertIn("required_fields", selected_tables["required"])
        self.assertIn("join_type", selected_joins["required"])

    def test_fake_asset_selector_returns_plan_and_records_call(self) -> None:
        selector = FakeAssetSelectorService(
            default_plan={
                "base_table": "vertex-poc-465616.medicarePhysicianFT.npidata",
                "selected_tables": [
                    {
                        "table_name": "npidata",
                        "qualified_name": "vertex-poc-465616.medicarePhysicianFT.npidata",
                        "role": "base",
                        "required_fields": ["npi"],
                        "rationale": "Provider counts come from the provider master.",
                    }
                ],
                "selected_joins": [],
                "entity": "provider",
                "entity_key_field": "npi",
                "grain_description": "One row per provider.",
                "business_intent": "Count Texas providers.",
                "measure_intent": "count distinct providers",
                "filters_summary": ["provider state is Texas"],
                "ranking_intent": None,
                "clarification": {
                    "required": False,
                    "question": None,
                    "reason": None,
                },
                "rationale": "Use provider master for provider inventory questions.",
            }
        )

        plan = selector.select_assets(
            message="How many providers are from Texas?",
            resolved_question="How many providers are from Texas?",
            session=SessionMemory(session_id="session-1"),
            semantic_model={"dataset_name": "demo", "tables": [{"table_name": "providers"}]},
            semantic_model_key="default-model",
            turn_type="fresh",
            operation_type="switch_topic",
            model="gpt-5.4-mini",
        )

        self.assertEqual(plan.entity_key_field, "npi")
        self.assertEqual(plan.selected_tables[0].role, "base")
        self.assertEqual(selector.calls[0].turn_type, "fresh")
        self.assertEqual(selector.calls[0].model, "gpt-5.4-mini")

    def test_openai_asset_selector_uses_client_and_validates_payload(self) -> None:
        client = StubResponsesClient(
            {
                "base_table": "vertex-poc-465616.medicarePhysicianFT.npidata",
                "selected_tables": [
                    {
                        "table_name": "npidata",
                        "qualified_name": "vertex-poc-465616.medicarePhysicianFT.npidata",
                        "role": "base",
                        "required_fields": ["npi", "provider_business_practice_location_address_state_name"],
                        "rationale": "Provider identity and location come from the provider master.",
                    },
                    {
                        "table_name": "CMS_Specialty_Taxonomy_Crosswalk",
                        "qualified_name": "vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                        "role": "join",
                        "required_fields": ["PROVIDER_TAXONOMY_CODE", "CMS_SPECIALTY_CODE"],
                        "rationale": "Needed to map taxonomy codes to CMS specialties.",
                    },
                ],
                "selected_joins": [
                    {
                        "left_table_name": "npidata",
                        "left_field_name": "healthcare_provider_taxonomy_code_1",
                        "right_table_name": "CMS_Specialty_Taxonomy_Crosswalk",
                        "right_field_name": "PROVIDER_TAXONOMY_CODE",
                        "join_type": "inner",
                        "relationship_type": "many_to_one",
                        "rationale": "Map provider taxonomy to specialty.",
                    }
                ],
                "entity": "provider",
                "entity_key_field": "npi",
                "grain_description": "One row per provider after specialty filtering.",
                "business_intent": "Count Texas providers who are oncologists.",
                "measure_intent": "count distinct providers",
                "filters_summary": ["provider state is Texas", "specialty is oncology"],
                "ranking_intent": None,
                "clarification": {
                    "required": False,
                    "question": None,
                    "reason": None,
                },
                "rationale": "Use provider master plus specialty crosswalk for provider-count-by-specialty intent.",
            }
        )
        selector = OpenAIAssetSelectorService(client=client)

        plan = selector.select_assets(
            message="how many of them are oncologists",
            resolved_question="How many Texas providers are oncologists?",
            session=SessionMemory(
                session_id="session-1",
                active_context=ActiveContext(topic_label="Texas providers"),
            ),
            semantic_model={"dataset_name": "demo", "tables": [{"table_name": "providers"}]},
            semantic_model_key="default-model",
            turn_type="follow_up",
            operation_type="refine_current_context",
            target_snapshot=ContextSnapshot(snapshot_id="snap-1"),
            model="gpt-5.4-mini",
        )

        self.assertEqual(plan.base_table, "vertex-poc-465616.medicarePhysicianFT.npidata")
        self.assertEqual(plan.selected_joins[0].join_type, "inner")
        self.assertEqual(plan.entity, "provider")
        self.assertEqual(client.calls[0]["model"], "gpt-5.4-mini")
        self.assertIn("system_prompt", client.calls[0])
        self.assertIn("user_prompt", client.calls[0])
        self.assertIn("schema", client.calls[0])

    def test_openai_asset_selector_backfills_defaults_for_legacy_payloads(self) -> None:
        client = StubResponsesClient(
            {
                "selected_tables": [
                    {
                        "table_name": "npidata",
                        "role": "base",
                    }
                ],
                "entity": "provider",
                "entity_key_field": "npi",
            }
        )
        selector = OpenAIAssetSelectorService(client=client)

        plan = selector.select_assets(
            message="How many providers are from Texas?",
            resolved_question="How many providers are from Texas?",
            session=SessionMemory(session_id="session-1"),
            semantic_model={"dataset_name": "demo", "tables": [{"table_name": "providers"}]},
        )

        self.assertEqual(plan.base_table, "npidata")
        self.assertEqual(plan.selected_tables[0].required_fields, [])
        self.assertFalse(plan.clarification.required)
        self.assertEqual(plan.filters_summary, [])

    def test_openai_asset_selector_rejects_invalid_structured_output(self) -> None:
        client = StubResponsesClient(
            {
                "selected_tables": [
                    {
                        "qualified_name": "vertex-poc-465616.medicarePhysicianFT.npidata",
                    }
                ]
            }
        )
        selector = OpenAIAssetSelectorService(client=client)

        with self.assertRaises(AssetSelectionError):
            selector.select_assets(
                message="How many providers are from Texas?",
                resolved_question="How many providers are from Texas?",
                session=SessionMemory(session_id="session-1"),
                semantic_model={"dataset_name": "demo", "tables": [{"table_name": "providers"}]},
            )


if __name__ == "__main__":
    unittest.main()
