from __future__ import annotations

import unittest

from pydantic import ValidationError

from backend.app.schemas.asset_selection import (
    AssetSelectionPlan,
    SelectedJoin,
    SelectedTable,
    SelectionClarification,
)


class AssetSelectionSchemaTests(unittest.TestCase):
    def test_asset_selection_plan_supports_grounded_multi_table_plan(self) -> None:
        plan = AssetSelectionPlan(
            base_table="vertex-poc-465616.medicarePhysicianFT.npidata",
            selected_tables=[
                SelectedTable(
                    table_name="npidata",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.npidata",
                    role="base",
                    required_fields=[
                        "npi",
                        "provider_business_practice_location_address_state_name",
                    ],
                    rationale="Provider inventory and location come from the provider master.",
                ),
                SelectedTable(
                    table_name="CMS_Specialty_Taxonomy_Crosswalk",
                    qualified_name="vertex-poc-465616.medicarePhysicianFT.CMS_Specialty_Taxonomy_Crosswalk",
                    role="join",
                    required_fields=[
                        "PROVIDER_TAXONOMY_CODE",
                        "CMS_SPECIALTY_CODE",
                    ],
                    rationale="Maps provider taxonomy codes to CMS specialties.",
                ),
            ],
            selected_joins=[
                SelectedJoin(
                    left_table_name="npidata",
                    left_field_name="healthcare_provider_taxonomy_code_1",
                    right_table_name="CMS_Specialty_Taxonomy_Crosswalk",
                    right_field_name="PROVIDER_TAXONOMY_CODE",
                    join_type="inner",
                    relationship_type="many_to_one",
                    rationale="Map provider taxonomy to CMS specialty.",
                )
            ],
            entity="provider",
            entity_key_field="npi",
            grain_description="One row per provider after taxonomy-based specialty filtering.",
            business_intent="Count Texas providers who are oncologists.",
            measure_intent="count distinct providers",
            filters_summary=["provider state is Texas", "specialty is oncology"],
            rationale="Use provider master for provider counts and crosswalk for specialty mapping.",
        )

        self.assertEqual(plan.selected_tables[0].role, "base")
        self.assertEqual(plan.selected_joins[0].join_type, "inner")
        self.assertEqual(plan.entity_key_field, "npi")

    def test_selection_clarification_requires_question_when_marked_required(self) -> None:
        with self.assertRaises(ValidationError):
            SelectionClarification(required=True)

        clarification = SelectionClarification(
            required=True,
            question="Do you mean highest total submitted charges or highest average submitted charge?",
            reason="The ranking metric is ambiguous.",
        )

        self.assertTrue(clarification.required)
        self.assertIn("highest", clarification.question)


if __name__ == "__main__":
    unittest.main()
