# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Project Does

Generates SQL from a natural-language question + a semantic model JSON. It does **not** execute queries. The system supports both stateless single-shot generation and stateful multi-turn chat sessions with memory.

## Commands

### Local development (run from repo root)

```bash
# Install backend deps
pip install -r backend/requirements.txt

# Run backend API (with hot reload)
uvicorn backend.app.api.main:app --host 0.0.0.0 --port 8000 --reload

# Install frontend deps
pip install -r frontend/requirements.txt

# Run Streamlit UI
set BACKEND_API_BASE_URL=http://localhost:8000
streamlit run frontend/app.py
```

### Docker (preferred for full-stack testing)

```bash
# Copy .env.example to .env and set OPENAI_API_KEY first
docker compose up --build

# Rebuild backend only (after code changes — code is baked into the image, not volume-mounted)
docker compose build backend && docker compose up -d --force-recreate backend
```

**Important:** When running `docker compose up`, the shell's `OPENAI_API_KEY` overrides `.env`. If you've rotated the key in `.env`, force it:
```bash
OPENAI_API_KEY=$(grep OPENAI_API_KEY .env | cut -d= -f2) docker compose up -d --force-recreate backend
```

### Tests

```bash
# Run all tests
python -m unittest discover -s tests -v

# Run a single test file
python -m unittest tests.test_sql_plan_validator -v

# Run a single test case
python -m unittest tests.test_sql_plan_validator.SqlPlanValidatorTests.test_validate_passes_for_single_allowed_base_table -v
```

Tests must be run from the repo root (not from inside `tests/`) so that `backend.*` imports resolve correctly.

## Architecture

### Two generation paths

**Stateless** (`POST /api/v1/sql/generate`): question + semantic model → SQL. No memory involved. Handled by `SqlGenerationService` directly.

**Stateful chat** (`POST /api/v1/chat/turn`): question + session_id + semantic model → SQL with conversation memory. Goes through `ChatSessionService` → `MemoryWrapperGraph` (LangGraph state machine) → `SqlGenerationService`.

### LangGraph state machine (`backend/app/memory/graph.py`)

The chat path executes these nodes in order:
1. `load_session` — fetch or create `SessionMemory` from `InMemorySessionStore`
2. `select_snapshot_candidates` — pick up to 3 prior `ContextSnapshot` objects
3. `reason_turn` — `OpenAIMemoryReasoner` decides: reuse context, rewind snapshot, or start fresh
4. **conditional**: if clarification needed → `respond_with_clarification` → skip SQL generation
5. `select_assets` — `OpenAIAssetSelectorService` picks which tables/joins are needed (produces `AssetSelectionPlan`)
6. **conditional**: if asset selector needs clarification → `respond_with_clarification`
7. `project_semantic_model` — filter the full semantic model down to only selected assets
8. `invoke_sql_generation` — call `SqlGenerationService` with the projected model
9. `update_session_memory` — persist messages and a new `ContextSnapshot`
10. `build_response` — format `GraphTurnState` into the API response

Session memory is **in-process only** (no database). It resets on backend restart. Bounded to 20 recent messages and 10 snapshots per session.

### Prompt modes

`SqlPromptBuilder` produces two distinct system prompts:
- **Full schema** (no asset plan): all tables and relationships included
- **Grounded** (asset plan present): only the projected tables/fields/joins are included — the model must stay within those bounds

The grounded path is enforced by `SqlPlanValidator` after generation. It checks that every table referenced in the generated SQL appears in the `AssetSelectionPlan`. If not, a `SqlValidationError` is raised.

### OpenAI client

`OpenAIResponsesClient` (`backend/app/llm/openai_client.py`) calls the OpenAI **Responses API** (`/v1/responses`), not the Chat Completions API. It uses structured JSON output with a strict schema. Default model is `gpt-5.4`; `reasoning_effort` defaults to `"medium"`.

### Dependency injection

All services are singletons via `@lru_cache` in `backend/app/api/deps.py`. The full wiring is:
```
ChatSessionService
  └── SqlGenerationService (→ GenerationOrchestrator → SqlGeneratorAgent → OpenAIResponsesClient)
  └── InMemorySessionStore
  └── OpenAIMemoryReasoner (→ OpenAIResponsesClient)
  └── OpenAIAssetSelectorService (→ OpenAIResponsesClient)
  └── SemanticProjectionService
```

### Error codes

All errors extend `AppError` (`backend/app/core/errors.py`) and map to HTTP status codes:

| Class | `code` field | HTTP |
|---|---|---|
| `BadRequestError` | `bad_request` | 400 |
| `SemanticModelError` | `invalid_semantic_model` | 422 |
| `SqlGenerationError` | `sql_generation_failed` | 502 |
| `SqlValidationError` | `sql_validation_failed` | 502 |
| `MemoryReasoningError` | `memory_reasoning_failed` | 502 |
| `AssetSelectionError` | `asset_selection_failed` | 502 |
| `ChatSessionError` | `chat_session_failed` | 502 |
| `ConfigurationError` | `configuration_error` | 500 |

### Semantic model formats

The adapter (`backend/app/adapters/semantic_model_adapter.py`) accepts both `entities`-style and `tables`-style semantic model payloads and normalizes them into a canonical `SemanticModel`. Always use the normalized form internally.

### Key known quirk in `SqlPlanValidator`

`UNNEST` and other SQL table-valued functions (e.g., in BigQuery `FROM UNNEST(...)`) are matched by the table-reference regex. They are filtered via `_SQL_FUNCTIONS`. The base-table ordering check is intentionally skipped when CTEs are present — CTE bodies can reference tables in any order, so the first `FROM` in the SQL text is not a reliable indicator of the query's logical starting point.

## Configuration

All settings read from environment variables (`backend/app/core/config.py`):

| Variable | Default | Notes |
|---|---|---|
| `OPENAI_API_KEY` | — | Required |
| `OPENAI_MODEL` | `gpt-5.4` | Also accepts `gpt-5.4-pro` |
| `OPENAI_TIMEOUT_SECONDS` | `120` | |
| `CORS_ORIGINS` | — | Comma-separated |
| `LOG_LEVEL` | `INFO` | |
| `APP_ENV` | `development` | |
| `PROMPT_VERSION` | `v1` | |

## Key directories

- `backend/app/agents/` — LangChain agent wrapper around OpenAI
- `backend/app/memory/` — LangGraph graph, session store, memory reasoner, context grounder, state models
- `backend/app/prompts/` — SQL prompt builder and asset selector prompt builder
- `backend/app/services/` — SQL generation, chat session, asset selection, semantic projection, plan validator
- `backend/app/adapters/` — semantic model normalization
- `backend/app/schemas/` — Pydantic models for API requests, responses, semantic model, asset selection
- `archives/` — legacy standalone agents and the Medicare demo semantic model (`medicare-physician-4t-semantic.payload.json`)
- `data/semantic-models/` — user-uploaded semantic models (persisted via Docker volume)
- `tests/` — 19 unittest modules, one per service/component
