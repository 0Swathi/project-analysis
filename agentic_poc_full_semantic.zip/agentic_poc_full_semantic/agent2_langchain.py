from __future__ import annotations

import argparse
from pathlib import Path

from backend.app.prompts.sql_prompt_builder import SqlPromptBuilder
from backend.app.schemas.requests import GenerateSqlRequest
from backend.app.services.semantic_model_service import SemanticModelService
from backend.app.services.sql_generation_service import SqlGenerationService
from backend.app.utils.cli import (
    DEFAULT_MODEL,
    auto_load_env,
    discover_payload_path,
    load_raw_payload,
    resolve_questions,
)


class WrapperPromptBuilder(SqlPromptBuilder):
    def __init__(self, explicit_context_window: int | None) -> None:
        self.explicit_context_window = explicit_context_window

    def get_context_window(
        self,
        model_name: str,
        explicit_context_window: int | None = None,
    ) -> int | None:
        override = explicit_context_window
        if override is None:
            override = self.explicit_context_window
        return super().get_context_window(model_name, override)


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate BigQuery SQL from natural language using the LangChain-backed backend service.",
    )
    parser.add_argument("--payload", help="Path to the semantic model payload JSON.")
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"OpenAI model to use. Default: {DEFAULT_MODEL}")
    parser.add_argument("--question", help="Single natural-language question to convert to SQL.")
    parser.add_argument(
        "--questions-file",
        help="Optional text file of questions to convert to SQL.",
    )
    parser.add_argument(
        "--context-window",
        type=int,
        help="Optional explicit context window override in tokens.",
    )
    parser.add_argument(
        "--print-prompt",
        action="store_true",
        help="Print the system prompt and effective user input before execution.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Include backend debug information in the CLI output.",
    )
    return parser


def print_prompt_payload(
    *,
    payload_path: Path,
    system_prompt: str,
    user_input: str,
) -> None:
    print("\n" + "=" * 70)
    print("PROMPT PAYLOAD")
    print("=" * 70)
    print(f"Payload file: {payload_path}")
    print("-" * 70)
    print("SYSTEM PROMPT:")
    print(system_prompt)
    print("-" * 70)
    print("USER INPUT:")
    print(user_input)
    print("=" * 70)


def run_question(
    *,
    question: str,
    payload_path: Path,
    raw_payload: dict,
    model_name: str,
    print_prompt: bool,
    debug: bool,
    prompt_builder: SqlPromptBuilder,
    semantic_model_service: SemanticModelService,
    service: SqlGenerationService,
) -> None:
    adapted = semantic_model_service.normalize_or_raise(raw_payload)
    context_report = prompt_builder.build_context_report(
        semantic_model=adapted.semantic_model,
        question=question,
        model_name=model_name,
        context_window=prompt_builder.get_context_window(model_name),
    )

    print(f"\n{'-' * 70}")
    print(f"Q: {question}")
    print("-" * 70)
    print(prompt_builder.format_context_report(context_report))
    if context_report.exceeds_window:
        print("\n-> Skipped: estimated input exceeds the model context window.")
        return

    system_prompt = prompt_builder.build_agent_system_prompt(adapted.semantic_model)
    user_input = prompt_builder.build_agent_input(question, context_report)
    if print_prompt:
        print_prompt_payload(
            payload_path=payload_path,
            system_prompt=system_prompt,
            user_input=user_input,
        )

    result = service.generate(
        GenerateSqlRequest(
            question=question,
            semantic_model=raw_payload,
            model=model_name,
            debug=debug,
        )
    )
    print(result.sql)
    print(f"\n-> {result.explanation}")
    if result.warnings:
        print("\nWarnings:")
        for warning in result.warnings:
            print(f"- {warning}")
    if result.debug and result.debug.trace:
        print("\nDebug Trace:")
        for line in result.debug.trace:
            print(f"- {line}")


def main() -> None:
    args = build_arg_parser().parse_args()
    auto_load_env()

    payload_path = discover_payload_path(args.payload)
    raw_payload = load_raw_payload(payload_path)
    prompt_builder = WrapperPromptBuilder(args.context_window)
    semantic_model_service = SemanticModelService()
    service = SqlGenerationService(
        semantic_model_service=semantic_model_service,
        prompt_builder=prompt_builder,
    )

    if args.question or args.questions_file:
        questions = resolve_questions(
            question=args.question,
            questions_file=Path(args.questions_file) if args.questions_file else None,
        )
        for question in questions:
            run_question(
                question=question,
                payload_path=payload_path,
                raw_payload=raw_payload,
                model_name=args.model,
                print_prompt=args.print_prompt,
                debug=args.debug,
                prompt_builder=prompt_builder,
                semantic_model_service=semantic_model_service,
                service=service,
            )
        return

    print("Interactive mode - type your question and press Enter. Type 'exit' or Ctrl+C to quit.\n")
    while True:
        try:
            question = input("Ask a question: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nBye.")
            break
        if not question:
            continue
        if question.lower() in {"exit", "quit"}:
            break
        try:
            run_question(
                question=question,
                payload_path=payload_path,
                raw_payload=raw_payload,
                model_name=args.model,
                print_prompt=args.print_prompt,
                debug=args.debug,
                prompt_builder=prompt_builder,
                semantic_model_service=semantic_model_service,
                service=service,
            )
        except Exception as exc:
            print(f"Error: {exc}")


if __name__ == "__main__":
    main()
