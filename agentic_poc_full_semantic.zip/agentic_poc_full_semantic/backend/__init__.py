"""Backend package for the semantic SQL application."""
