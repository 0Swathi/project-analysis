from __future__ import annotations

import json
import logging
import time
import urllib.error
import urllib.request
from typing import Any

from backend.app.core.config import Settings, get_settings
from backend.app.core.errors import ConfigurationError, SqlGenerationError

logger = logging.getLogger(__name__)

_RETRYABLE_HTTP_STATUSES = {429, 500, 502, 503, 504}
_MAX_BACKOFF_SECONDS = 30.0

# Opt-in allowlist: only models known to accept the reasoning payload get it.
# Unknown models default to False (safe) rather than True (API 400 on unknown models).
_REASONING_PREFIXES = ("o1", "o3", "gpt-5")


def model_supports_reasoning(model: str) -> bool:
    return any(model.startswith(p) for p in _REASONING_PREFIXES)


class OpenAIResponsesClient:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str | None = None,
        base_url: str = "https://api.openai.com/v1/responses",
        reasoning_effort: str | None = "medium",
        timeout_seconds: int | None = None,
        max_retries: int = 3,
        retry_backoff_seconds: float = 1.0,
        settings: Settings | None = None,
    ) -> None:
        self.settings = settings or get_settings()
        self.api_key = api_key or self.settings.openai_api_key
        self.model = model or self.settings.openai_model
        self.base_url = base_url
        self.reasoning_effort = reasoning_effort
        self.timeout_seconds = timeout_seconds or self.settings.openai_timeout_seconds
        self.max_retries = max_retries
        self.retry_backoff_seconds = retry_backoff_seconds
        if not self.api_key:
            raise ConfigurationError("OPENAI_API_KEY is not set.")

    def generate_json(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        schema: dict[str, Any],
        model: str | None = None,
    ) -> dict[str, Any]:
        effective_model = model or self.model
        payload: dict[str, Any] = {
            "model": effective_model,
            "input": [
                self._message("system", system_prompt),
                self._message("user", user_prompt),
            ],
            "text": {
                "format": {
                    "type": "json_schema",
                    "name": schema["name"],
                    "strict": True,
                    "schema": schema["schema"],
                }
            },
        }
        if self.reasoning_effort and model_supports_reasoning(effective_model):
            payload["reasoning"] = {"effort": self.reasoning_effort}

        request = urllib.request.Request(
            self.base_url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        body = self._fetch_with_retry(request)

        parsed_body = json.loads(body)
        refusal = self._extract_refusal(parsed_body)
        if refusal:
            raise SqlGenerationError(
                "Model refused the request.",
                details={"refusal": refusal},
            )

        output_text = self._extract_output_text(parsed_body)
        try:
            return json.loads(output_text)
        except json.JSONDecodeError as exc:
            raise SqlGenerationError(
                "Model returned invalid JSON.",
                details={"output_text": output_text},
            ) from exc

    def _fetch_with_retry(self, request: urllib.request.Request) -> str:
        last_exc: Exception = RuntimeError("Retry loop exited without result.")
        for attempt in range(self.max_retries + 1):
            try:
                with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                    return response.read().decode("utf-8")
            except urllib.error.HTTPError as exc:
                if exc.code in _RETRYABLE_HTTP_STATUSES and attempt < self.max_retries:
                    wait = min(self.retry_backoff_seconds * (2.0 ** attempt), _MAX_BACKOFF_SECONDS)
                    logger.warning(
                        "Responses API HTTP %s on attempt %d/%d; retrying in %.1fs.",
                        exc.code, attempt + 1, self.max_retries + 1, wait,
                    )
                    time.sleep(wait)
                    last_exc = exc
                    continue
                details = exc.read().decode("utf-8", errors="replace")
                raise SqlGenerationError(
                    f"Responses API request failed with HTTP {exc.code}.",
                    details={"http_status": exc.code, "body": details},
                ) from exc
            except urllib.error.URLError as exc:
                if attempt < self.max_retries:
                    wait = min(self.retry_backoff_seconds * (2.0 ** attempt), _MAX_BACKOFF_SECONDS)
                    logger.warning(
                        "Responses API request failed (%s) on attempt %d/%d; retrying in %.1fs.",
                        exc.reason, attempt + 1, self.max_retries + 1, wait,
                    )
                    time.sleep(wait)
                    last_exc = exc
                    continue
                raise SqlGenerationError(
                    "Responses API request failed.",
                    details={"reason": str(exc.reason)},
                ) from exc
        raise SqlGenerationError(
            "Responses API request failed after all retry attempts.",
            details={"reason": str(last_exc)},
        ) from last_exc

    def _message(self, role: str, text: str) -> dict[str, Any]:
        return {
            "role": role,
            "content": [{"type": "input_text", "text": text}],
        }

    def _extract_refusal(self, response_payload: dict[str, Any]) -> str | None:
        for output_item in response_payload.get("output", []):
            if output_item.get("type") != "message":
                continue
            for content_item in output_item.get("content", []):
                if content_item.get("type") == "refusal":
                    return content_item.get("refusal")
        return None

    def _extract_output_text(self, response_payload: dict[str, Any]) -> str:
        for output_item in response_payload.get("output", []):
            if output_item.get("type") != "message":
                continue
            for content_item in output_item.get("content", []):
                if content_item.get("type") == "output_text":
                    return content_item.get("text", "")
        raise SqlGenerationError(
            "Responses API output did not include output_text.",
            details={"response_payload": response_payload},
        )
