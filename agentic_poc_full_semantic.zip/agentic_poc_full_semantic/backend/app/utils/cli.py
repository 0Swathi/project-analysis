from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any


DEFAULT_MODEL = "gpt-5.4"
AUTO_ENV_FILENAMES = (".env", "openaikeys.txt")
DEFAULT_PAYLOAD_FILENAMES = (
    "medicare-physician-4t-semantic.payload.json",
    "semantic-model.json",
)


def load_env_file(path: Path) -> bool:
    if not path.exists() or not path.is_file():
        return False

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())
    return True


def auto_load_env() -> Path | None:
    search_paths: list[Path] = []
    cwd = Path.cwd()
    for filename in AUTO_ENV_FILENAMES:
        search_paths.append(cwd / filename)
        search_paths.append(cwd / "archives" / filename)

    for candidate in search_paths:
        if load_env_file(candidate):
            return candidate
    return None


def looks_like_semantic_model(path: Path) -> bool:
    if path.suffix.lower() != ".json" or not path.is_file():
        return False
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return isinstance(payload, dict) and (
        isinstance(payload.get("entities"), list) or isinstance(payload.get("tables"), list)
    )


def discover_payload_path(explicit_path: str | None) -> Path:
    if explicit_path:
        path = Path(explicit_path)
        if not path.exists():
            raise FileNotFoundError(f"Semantic model file not found: {path}")
        return path

    env_path = os.environ.get("SEMANTIC_MODEL_PATH")
    if env_path:
        return Path(env_path)

    cwd = Path.cwd()
    defaults = [cwd / name for name in DEFAULT_PAYLOAD_FILENAMES]
    defaults.extend(cwd / "archives" / name for name in DEFAULT_PAYLOAD_FILENAMES)
    for candidate in defaults:
        if looks_like_semantic_model(candidate):
            return candidate

    candidates = [path for path in sorted(cwd.glob("*.json")) if looks_like_semantic_model(path)]
    archive_candidates = [
        path for path in sorted((cwd / "archives").glob("*.json")) if looks_like_semantic_model(path)
    ]
    all_candidates = candidates + archive_candidates
    if len(all_candidates) == 1:
        return all_candidates[0]

    raise FileNotFoundError(
        "Could not determine the semantic model path. Pass --payload or set SEMANTIC_MODEL_PATH."
    )


def load_raw_payload(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError(f"{path} is not a valid semantic model payload.")
    return payload


def parse_questions_file(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    quoted = re.findall(r'"([^"\n]+)"', text)
    if quoted:
        return quoted

    questions: list[str] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        questions.append(line)
    return questions


def resolve_questions(*, question: str | None, questions_file: Path | None) -> list[str]:
    if question and question.strip():
        return [question.strip()]

    if questions_file is not None:
        questions = parse_questions_file(questions_file)
        if not questions:
            raise ValueError(f"No questions found in {questions_file}.")
        return questions

    prompt = input("Ask a question: ").strip()
    if not prompt:
        raise ValueError("A question is required.")
    return [prompt]
