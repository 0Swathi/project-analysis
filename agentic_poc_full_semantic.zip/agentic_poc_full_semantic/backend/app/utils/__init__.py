"""Utility helpers shared across the backend and compatibility CLIs."""
