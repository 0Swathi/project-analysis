"""Application package for the semantic SQL service."""
