from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pydantic import ValidationError

from backend.app.core.config import Settings, get_settings
from backend.app.core.errors import (
    AppError,
    AssetSelectionError,
    ConfigurationError,
)
from backend.app.llm.openai_client import OpenAIResponsesClient
from backend.app.memory.state import ContextSnapshot, SessionMemory
from backend.app.prompts.asset_selector_prompt import AssetSelectorPromptBuilder
from backend.app.schemas.asset_selection import AssetSelectionPlan


class AssetSelectorService:
    def select_assets(
        self,
        *,
        message: str,
        resolved_question: str | None,
        session: SessionMemory,
        semantic_model: dict[str, Any],
        semantic_model_key: str | None = None,
        turn_type: str | None = None,
        operation_type: str | None = None,
        target_snapshot: ContextSnapshot | None = None,
        model: str | None = None,
    ) -> AssetSelectionPlan:
        raise NotImplementedError


class OpenAIAssetSelectorService(AssetSelectorService):
    def __init__(
        self,
        *,
        client: OpenAIResponsesClient | None = None,
        prompt_builder: AssetSelectorPromptBuilder | None = None,
        settings: Settings | None = None,
    ) -> None:
        self.settings = settings or get_settings()
        self.client = client or OpenAIResponsesClient(
            settings=self.settings,
            model=self.settings.openai_memory_model,
            reasoning_effort=None,
        )
        self.prompt_builder = prompt_builder or AssetSelectorPromptBuilder()

    def select_assets(
        self,
        *,
        message: str,
        resolved_question: str | None,
        session: SessionMemory,
        semantic_model: dict[str, Any],
        semantic_model_key: str | None = None,
        turn_type: str | None = None,
        operation_type: str | None = None,
        target_snapshot: ContextSnapshot | None = None,
        model: str | None = None,
    ) -> AssetSelectionPlan:
        system_prompt = self.prompt_builder.build_system_prompt()
        user_prompt = self.prompt_builder.build_user_prompt(
            message=message,
            resolved_question=resolved_question,
            session=session,
            semantic_model=semantic_model,
            semantic_model_key=semantic_model_key,
            turn_type=turn_type,
            operation_type=operation_type,
            target_snapshot=target_snapshot,
        )
        schema = self.prompt_builder.build_response_schema()

        try:
            payload = self.client.generate_json(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                schema=schema,
                model=model,
            )
        except ConfigurationError:
            raise
        except AppError as exc:
            raise AssetSelectionError(
                "Asset selector invocation failed.",
                details={
                    "error_code": exc.code,
                    "reason": exc.message,
                    "error_details": exc.details,
                },
            ) from exc
        except Exception as exc:
            raise AssetSelectionError(
                "Asset selector invocation failed.",
                details={"reason": str(exc)},
            ) from exc

        try:
            return AssetSelectionPlan.model_validate(self._normalize_payload(payload))
        except ValidationError as exc:
            raise AssetSelectionError(
                "Asset selector returned invalid structured output.",
                details={"errors": exc.errors(), "payload": payload},
            ) from exc

    def _normalize_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        normalized_payload = dict(payload)

        normalized_payload.setdefault("base_table", None)
        normalized_payload.setdefault("entity", None)
        normalized_payload.setdefault("entity_key_field", None)
        normalized_payload.setdefault("grain_description", None)
        normalized_payload.setdefault("business_intent", None)
        normalized_payload.setdefault("measure_intent", None)
        normalized_payload.setdefault("ranking_intent", None)
        normalized_payload.setdefault("rationale", None)

        selected_tables = normalized_payload.get("selected_tables")
        if not isinstance(selected_tables, list):
            selected_tables = []
        normalized_payload["selected_tables"] = [
            self._normalize_selected_table(item)
            for item in selected_tables
            if isinstance(item, dict)
        ]

        selected_joins = normalized_payload.get("selected_joins")
        if not isinstance(selected_joins, list):
            selected_joins = []
        normalized_payload["selected_joins"] = [
            self._normalize_selected_join(item)
            for item in selected_joins
            if isinstance(item, dict)
        ]

        filters_summary = normalized_payload.get("filters_summary")
        if not isinstance(filters_summary, list):
            normalized_payload["filters_summary"] = []

        clarification = normalized_payload.get("clarification")
        if not isinstance(clarification, dict):
            normalized_payload["clarification"] = {
                "required": False,
                "question": None,
                "reason": None,
            }
        else:
            normalized_payload["clarification"] = {
                "required": bool(clarification.get("required", False)),
                "question": clarification.get("question"),
                "reason": clarification.get("reason"),
            }

        if normalized_payload["base_table"] is None and normalized_payload["selected_tables"]:
            base_candidates = [
                table["qualified_name"] or table["table_name"]
                for table in normalized_payload["selected_tables"]
                if table.get("role") == "base"
            ]
            if base_candidates:
                normalized_payload["base_table"] = base_candidates[0]
            else:
                first_table = normalized_payload["selected_tables"][0]
                normalized_payload["base_table"] = (
                    first_table["qualified_name"] or first_table["table_name"]
                )

        return normalized_payload

    def _normalize_selected_table(self, payload: dict[str, Any]) -> dict[str, Any]:
        required_fields = payload.get("required_fields")
        if not isinstance(required_fields, list):
            required_fields = []
        else:
            required_fields = [
                str(field_name).strip()
                for field_name in required_fields
                if str(field_name).strip()
            ]

        return {
            "table_name": payload.get("table_name"),
            "qualified_name": payload.get("qualified_name"),
            "role": payload.get("role"),
            "required_fields": required_fields,
            "rationale": payload.get("rationale"),
        }

    def _normalize_selected_join(self, payload: dict[str, Any]) -> dict[str, Any]:
        return {
            "left_table_name": payload.get("left_table_name"),
            "left_field_name": payload.get("left_field_name"),
            "right_table_name": payload.get("right_table_name"),
            "right_field_name": payload.get("right_field_name"),
            "join_type": payload.get("join_type"),
            "relationship_type": payload.get("relationship_type"),
            "rationale": payload.get("rationale"),
        }


@dataclass(slots=True)
class FakeAssetSelectorCall:
    message: str
    resolved_question: str | None
    session_id: str
    semantic_model_key: str | None
    turn_type: str | None
    operation_type: str | None
    target_snapshot_id: str | None
    model: str | None


class FakeAssetSelectorService(AssetSelectorService):
    def __init__(
        self,
        plans: list[AssetSelectionPlan | dict[str, Any]] | None = None,
        *,
        default_plan: AssetSelectionPlan | dict[str, Any] | None = None,
    ) -> None:
        self._plan_queue = list(plans or [])
        self._default_plan = default_plan
        self.calls: list[FakeAssetSelectorCall] = []

    def select_assets(
        self,
        *,
        message: str,
        resolved_question: str | None,
        session: SessionMemory,
        semantic_model: dict[str, Any],
        semantic_model_key: str | None = None,
        turn_type: str | None = None,
        operation_type: str | None = None,
        target_snapshot: ContextSnapshot | None = None,
        model: str | None = None,
    ) -> AssetSelectionPlan:
        self.calls.append(
            FakeAssetSelectorCall(
                message=message,
                resolved_question=resolved_question,
                session_id=session.session_id,
                semantic_model_key=semantic_model_key,
                turn_type=turn_type,
                operation_type=operation_type,
                target_snapshot_id=(
                    target_snapshot.snapshot_id
                    if target_snapshot is not None
                    else None
                ),
                model=model,
            )
        )

        if self._plan_queue:
            payload = self._plan_queue.pop(0)
        elif self._default_plan is not None:
            payload = self._default_plan
        else:
            raise AssertionError("FakeAssetSelectorService has no configured plan.")

        if isinstance(payload, AssetSelectionPlan):
            return payload.model_copy(deep=True)
        return AssetSelectionPlan.model_validate(payload)
