from __future__ import annotations

import json
from collections.abc import Generator
from dataclasses import dataclass
from time import perf_counter
from typing import Any, Protocol

from backend.app.core.errors import AppError, ChatSessionError
from backend.app.memory.graph import MemoryWrapperGraph, fingerprint_semantic_model
from backend.app.memory.reasoner import MemoryReasoner, OpenAIMemoryReasoner
from backend.app.memory.state import GraphTurnState, SemanticChangeRequest
from backend.app.memory.store import InMemorySessionStore
from backend.app.schemas.chat import ChatTurnRequest, ChatTurnResponse, MemoryDebugPayload
from backend.app.schemas.asset_selection import AssetSelectionPlan
from backend.app.schemas.requests import GenerateSqlRequest, SemanticChangeRequestPayload
from backend.app.schemas.responses import GenerateSqlResponse
from backend.app.services.asset_selector_service import AssetSelectorService
from backend.app.services.semantic_model_service import SemanticModelService
from backend.app.services.semantic_projection_service import SemanticProjectionService
from backend.app.services.sql_generation_service import SqlGenerationService


def _coerce_semantic_change_request(
    scr: SemanticChangeRequest | SemanticChangeRequestPayload | dict[str, Any] | None,
) -> SemanticChangeRequestPayload | None:
    """Normalise any shape of semantic-change-request into SemanticChangeRequestPayload.

    Accepted inputs:
    - None → None
    - SemanticChangeRequestPayload → returned unchanged
    - SemanticChangeRequest (typed state model) → converted via model_dump
    - dict → validated directly
    Anything else raises TypeError immediately rather than failing silently later.
    """
    if scr is None:
        return None
    if isinstance(scr, SemanticChangeRequestPayload):
        return scr
    if isinstance(scr, SemanticChangeRequest):
        return SemanticChangeRequestPayload.model_validate(scr.model_dump(mode="python"))
    if isinstance(scr, dict):
        return SemanticChangeRequestPayload.model_validate(scr)
    raise TypeError(
        f"semantic_change_request must be SemanticChangeRequest, "
        f"SemanticChangeRequestPayload, or dict — got {type(scr).__name__}"
    )


class GraphInvoker(Protocol):
    def invoke(self, state: GraphTurnState) -> GraphTurnState:
        """Run a single chat turn through the memory graph."""

    def stream_events(self, state: GraphTurnState) -> Generator[str, None, None]:
        """Stream SSE strings for each pipeline stage of a chat turn."""


@dataclass(slots=True)
class SqlGenerationExecutorAdapter:
    service: SqlGenerationService

    def execute(
        self,
        *,
        question: str,
        semantic_model: dict[str, Any],
        asset_selection_plan: AssetSelectionPlan | None = None,
        prior_sql: str | None = None,
        semantic_change_request: Any | None = None,
        model: str | None = None,
        debug: bool = False,
    ) -> GenerateSqlResponse:
        scr_payload = _coerce_semantic_change_request(semantic_change_request)

        return self.service.generate(
            GenerateSqlRequest(
                question=question,
                semantic_model=semantic_model,
                asset_selection_plan=asset_selection_plan,
                prior_sql=prior_sql,
                semantic_change_request=scr_payload,
                model=model,
                debug=debug,
            )
        )


class ChatSessionService:
    def __init__(
        self,
        *,
        semantic_model_service: SemanticModelService | None = None,
        sql_generation_service: SqlGenerationService | None = None,
        store: InMemorySessionStore | None = None,
        reasoner: MemoryReasoner | None = None,
        asset_selector_service: AssetSelectorService | None = None,
        projection_service: SemanticProjectionService | None = None,
        graph: GraphInvoker | None = None,
    ) -> None:
        self.semantic_model_service = semantic_model_service or SemanticModelService()
        self.sql_generation_service = sql_generation_service or SqlGenerationService()
        self.store = store or getattr(graph, "store", None) or InMemorySessionStore()
        self.reasoner = reasoner if reasoner is not None else (
            None if graph is not None else OpenAIMemoryReasoner()
        )
        self.graph = graph or MemoryWrapperGraph(
            store=self.store,
            reasoner=self.reasoner,
            sql_executor=SqlGenerationExecutorAdapter(self.sql_generation_service),
            asset_selector=asset_selector_service,
            projection_service=projection_service,
        )
        if self.reasoner is None:
            self.reasoner = getattr(self.graph, "reasoner", None)

    def handle_turn(self, request: ChatTurnRequest) -> ChatTurnResponse:
        started_at = perf_counter()
        adapted_model = self.semantic_model_service.normalize_or_raise(request.semantic_model)
        normalized_semantic_model = adapted_model.semantic_model.model_dump(
            mode="python",
            exclude_none=True,
        )
        resolved_semantic_model_key = request.semantic_model_key or adapted_model.semantic_model.name
        semantic_model_fingerprint = fingerprint_semantic_model(normalized_semantic_model)

        try:
            graph_result = self.graph.invoke(
                GraphTurnState(
                    session_id=request.session_id,
                    incoming_message=request.message,
                    semantic_model=normalized_semantic_model,
                    semantic_model_key=resolved_semantic_model_key,
                    semantic_model_fingerprint=semantic_model_fingerprint,
                    model=request.model,
                    memory_model=request.memory_model,
                    debug=request.debug,
                )
            )
        except AppError:
            raise
        except Exception as exc:
            raise ChatSessionError(
                "Unexpected chat session failure.",
                details={"reason": str(exc)},
            ) from exc

        return self._build_response_from_graph_result(
            graph_result=graph_result,
            request=request,
            started_at=started_at,
        )

    def handle_turn_stream(self, request: ChatTurnRequest) -> Generator[str, None, None]:
        def _sse(payload: dict) -> str:
            return f"data: {json.dumps(payload)}\n\n"

        try:
            adapted_model = self.semantic_model_service.normalize_or_raise(request.semantic_model)
            normalized_semantic_model = adapted_model.semantic_model.model_dump(
                mode="python",
                exclude_none=True,
            )
            resolved_semantic_model_key = (
                request.semantic_model_key or adapted_model.semantic_model.name
            )
            semantic_model_fingerprint = fingerprint_semantic_model(normalized_semantic_model)
        except Exception as exc:
            yield _sse({"type": "error", "message": str(exc)})
            return

        graph_state = GraphTurnState(
            session_id=request.session_id,
            incoming_message=request.message,
            semantic_model=normalized_semantic_model,
            semantic_model_key=resolved_semantic_model_key,
            semantic_model_fingerprint=semantic_model_fingerprint,
            model=request.model,
            memory_model=request.memory_model,
            debug=request.debug,
        )

        started_at = perf_counter()
        result_payload: dict | None = None

        for raw in self.graph.stream_events(graph_state):
            try:
                event = json.loads(raw[len("data: "):].strip())
            except (json.JSONDecodeError, ValueError):
                yield raw
                continue

            if event.get("type") == "result":
                result_payload = event.get("payload")
            else:
                yield raw  # forward progress and error events unchanged

        if result_payload is None:
            yield _sse({"type": "error", "message": "No result produced by the pipeline."})
            return

        try:
            graph_result = GraphTurnState.model_validate(result_payload)
            response = self._build_response_from_graph_result(
                graph_result=graph_result,
                request=request,
                started_at=started_at,
            )
            yield _sse({"type": "result", "payload": response.model_dump(mode="json")})
        except Exception as exc:
            yield _sse({"type": "error", "message": f"Response assembly failed: {exc}"})

    def _build_response_from_graph_result(
        self,
        *,
        graph_result: GraphTurnState,
        request: ChatTurnRequest,
        started_at: float | None = None,
    ) -> ChatTurnResponse:
        assistant_message = graph_result.assistant_message
        if not assistant_message:
            raise ChatSessionError(
                "Chat session did not produce an assistant message.",
                details={"session_id": request.session_id},
            )

        decision = graph_result.reasoner_output
        memory_debug = None
        if request.debug:
            active_context = graph_result.session.active_context if graph_result.session else None
            selected_tables = []
            if active_context is not None:
                selected_tables = list(active_context.tables_used or active_context.tables)
            memory_debug = MemoryDebugPayload(
                used_active_context=bool(decision.use_active_context) if decision else False,
                used_snapshot_id=decision.target_snapshot_id if decision else None,
                candidate_snapshot_ids=[
                    snapshot.snapshot_id for snapshot in graph_result.candidate_snapshots
                ],
                semantic_model_changed=graph_result.semantic_model_changed,
                selected_base_table=(
                    active_context.base_table if active_context is not None else None
                ),
                selected_tables=selected_tables,
                chat_duration_ms=(
                    int((perf_counter() - started_at) * 1000) if started_at is not None else None
                ),
                sql_duration_ms=(
                    graph_result.sql_result.metadata.duration_ms
                    if graph_result.sql_result is not None
                    else None
                ),
            )

        return ChatTurnResponse(
            session_id=request.session_id,
            turn_type=graph_result.turn_type,
            assistant_message=assistant_message,
            resolved_question=graph_result.resolved_question,
            clarification_required=graph_result.clarification_required,
            clarification_question=(
                graph_result.clarification_question
                or (decision.clarification_question if decision else None)
            ),
            sql_result=graph_result.sql_result,
            memory_debug=memory_debug,
        )

