from __future__ import annotations

import logging
from dataclasses import dataclass, field

import sqlglot
import sqlglot.expressions as exp
from sqlglot.errors import ErrorLevel

from backend.app.schemas.asset_selection import AssetSelectionPlan

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class SqlPlanValidationResult:
    valid: bool
    violations: list[str] = field(default_factory=list)
    referenced_tables: list[str] = field(default_factory=list)
    join_conditions: list[str] = field(default_factory=list)


class SqlPlanValidator:
    # TVF names that may appear in FROM position in some dialects but are not real tables.
    # sqlglot generally parses TVFs as Unnest/Anonymous nodes rather than Table nodes, but
    # this set acts as a safety net for edge cases.
    _TVF_NAMES = frozenset({
        "unnest", "lateral", "json_each", "json_table", "generate_series",
        "xmltable", "generate_date_array", "json_query_array", "split",
        "openrowset", "openjson", "changetable",
    })

    def validate(
        self,
        *,
        sql: str,
        asset_selection_plan: AssetSelectionPlan | None,
        dialect: str = "bigquery",
    ) -> SqlPlanValidationResult:
        if not _has_grounded_asset_plan(asset_selection_plan):
            return SqlPlanValidationResult(valid=True)

        assert asset_selection_plan is not None

        try:
            tree = sqlglot.parse_one(sql, dialect=dialect, error_level=ErrorLevel.RAISE)
        except sqlglot.errors.ParseError as exc:
            logger.warning("SQL parse failed during plan validation (dialect=%s): %s", dialect, exc)
            return SqlPlanValidationResult(
                valid=False,
                violations=[f"SQL could not be parsed for validation (dialect={dialect}): {exc}"],
            )

        if tree is None:
            return SqlPlanValidationResult(
                valid=False,
                violations=[f"SQL produced no parse tree (dialect={dialect})"],
            )

        cte_names: set[str] = {
            cte.alias.lower() for cte in tree.find_all(exp.CTE) if cte.alias
        }

        table_refs = self._extract_table_refs(tree, cte_names)
        referenced_tables = list(dict.fromkeys(_fqn(t) for t in table_refs))

        violations: list[str] = []
        allowed_table_map = self._build_allowed_table_map(asset_selection_plan)
        allowed_table_values = set(allowed_table_map.values())

        # Base-table ordering — skip when CTEs are present because the first exp.Table
        # in DFS order may be inside a CTE body, not the query's logical entry point.
        if table_refs and not cte_names:
            first_fqn = _canonicalize(_fqn(table_refs[0]), allowed_table_map)
            expected_base = _canonicalize_optional(asset_selection_plan.base_table, allowed_table_map)
            if expected_base and first_fqn != expected_base:
                violations.append(
                    "Generated SQL starts from a different base table than the grounded plan: "
                    f"{_fqn(table_refs[0])}"
                )

        seen_fqns: set[str] = set()
        for t in table_refs:
            fqn = _fqn(t)
            if fqn in seen_fqns:
                continue
            seen_fqns.add(fqn)
            if _canonicalize(fqn, allowed_table_map) not in allowed_table_values:
                violations.append(
                    f"Generated SQL references a table outside the grounded plan: {fqn}"
                )

        alias_map = self._build_alias_map(table_refs, allowed_table_map)
        join_conditions = self._extract_join_conditions(tree, alias_map)

        if asset_selection_plan.selected_joins:
            allowed_conditions = self._build_allowed_conditions(asset_selection_plan, allowed_table_map)
            for cond in join_conditions:
                if cond not in allowed_conditions:
                    violations.append(
                        f"Generated SQL uses a join condition outside the grounded plan: {cond}"
                    )

        return SqlPlanValidationResult(
            valid=not violations,
            violations=violations,
            referenced_tables=referenced_tables,
            join_conditions=join_conditions,
        )

    # ------------------------------------------------------------------
    # Table reference extraction
    # ------------------------------------------------------------------

    def _extract_table_refs(
        self,
        tree: exp.Expression,
        cte_names: set[str],
    ) -> list[exp.Table]:
        refs: list[exp.Table] = []
        for table in tree.find_all(exp.Table):
            name_lower = table.name.lower()
            if name_lower in cte_names or name_lower in self._TVF_NAMES:
                continue
            refs.append(table)
        return refs

    # ------------------------------------------------------------------
    # Allowed-table map
    # ------------------------------------------------------------------

    def _build_allowed_table_map(self, plan: AssetSelectionPlan) -> dict[str, str]:
        table_map: dict[str, str] = {}
        for st in plan.selected_tables:
            canonical = _normalize(st.qualified_name or st.table_name)
            table_map[_normalize(st.table_name)] = canonical
            if st.qualified_name:
                table_map[_normalize(st.qualified_name)] = canonical
        if plan.base_table:
            canonical_base = _normalize(plan.base_table)
            table_map.setdefault(canonical_base, canonical_base)
            table_map.setdefault(canonical_base.split(".")[-1], canonical_base)
        return table_map

    # ------------------------------------------------------------------
    # Alias map (table qualifier / alias → canonical FQN)
    # ------------------------------------------------------------------

    def _build_alias_map(
        self,
        table_refs: list[exp.Table],
        allowed_table_map: dict[str, str],
    ) -> dict[str, str]:
        alias_map: dict[str, str] = {}
        for t in table_refs:
            fqn = _fqn(t)
            canonical = _canonicalize(fqn, allowed_table_map)
            short_name = canonical.split(".")[-1]
            alias_map[fqn] = canonical
            alias_map[short_name] = canonical
            alias_map[canonical] = canonical
            if t.alias:
                alias_map[t.alias.lower()] = canonical
        return alias_map

    # ------------------------------------------------------------------
    # Join condition extraction — handles ON and USING forms
    # ------------------------------------------------------------------

    def _extract_join_conditions(
        self,
        tree: exp.Expression,
        alias_map: dict[str, str],
    ) -> list[str]:
        conditions: list[str] = []

        for select in tree.find_all(exp.Select):
            from_clause = select.args.get("from_")  # sqlglot uses "from_" to avoid Python keyword conflict
            joins: list[exp.Join] = select.args.get("joins") or []

            if not joins:
                continue

            # Track the "left" table as we walk the join chain for USING resolution.
            prev_fqn: str | None = None
            if from_clause and isinstance(from_clause.this, exp.Table):
                prev_fqn = self._resolve_table(from_clause.this, alias_map)

            for join in joins:
                join_table = join.this if isinstance(join.this, exp.Table) else None
                join_fqn = self._resolve_table(join_table, alias_map) if join_table else None

                on_expr = join.args.get("on")
                using_items: list[exp.Expression] = join.args.get("using") or []

                if on_expr:
                    for eq in on_expr.find_all(exp.EQ):
                        left, right = eq.this, eq.expression
                        if isinstance(left, exp.Column) and isinstance(right, exp.Column):
                            lt = alias_map.get((left.table or "").lower())
                            rt = alias_map.get((right.table or "").lower())
                            if lt and rt:
                                cond = _normalize_join_condition(lt, left.name, rt, right.name)
                                if cond not in conditions:
                                    conditions.append(cond)

                elif using_items and prev_fqn and join_fqn:
                    # USING (col) is equivalent to left_table.col = right_table.col
                    for item in using_items:
                        col_name = item.name if hasattr(item, "name") else str(item)
                        cond = _normalize_join_condition(prev_fqn, col_name, join_fqn, col_name)
                        if cond not in conditions:
                            conditions.append(cond)

                if join_fqn:
                    prev_fqn = join_fqn

        return conditions

    def _resolve_table(
        self,
        table: exp.Table | None,
        alias_map: dict[str, str],
    ) -> str | None:
        if table is None:
            return None
        # Prefer alias lookup; fall back to FQN.
        key = (table.alias or table.name).lower()
        return alias_map.get(key) or alias_map.get(_fqn(table))

    # ------------------------------------------------------------------
    # Allowed join conditions
    # ------------------------------------------------------------------

    def _build_allowed_conditions(
        self,
        plan: AssetSelectionPlan,
        allowed_table_map: dict[str, str],
    ) -> set[str]:
        conditions: set[str] = set()
        for sj in plan.selected_joins:
            lt = _canonicalize_optional(sj.left_table_name, allowed_table_map)
            rt = _canonicalize_optional(sj.right_table_name, allowed_table_map)
            if lt and rt:
                conditions.add(
                    _normalize_join_condition(lt, sj.left_field_name, rt, sj.right_field_name)
                )
        return conditions


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------

def _fqn(table: exp.Table) -> str:
    """Return the fully-qualified, lowercased table name from an AST node."""
    parts = [p for p in [table.catalog, table.db, table.name] if p]
    return ".".join(parts).lower()


def _normalize(value: str) -> str:
    """Strip SQL quoting characters and lowercase — used for plan values."""
    return value.strip().strip("`").strip('"').lower()


def _canonicalize(reference: str, table_map: dict[str, str]) -> str:
    normalized = _normalize(reference)
    if normalized in table_map:
        return table_map[normalized]
    # If the full FQN isn't registered, try the short name (last dot-separated component).
    # This handles the case where base_table is "npidata" but the SQL writes
    # the fully-qualified "project.dataset.npidata".
    short = normalized.split(".")[-1]
    return table_map.get(short, normalized)


def _canonicalize_optional(reference: str | None, table_map: dict[str, str]) -> str | None:
    if reference is None:
        return None
    return _canonicalize(reference, table_map)


def _normalize_join_condition(
    left_table: str,
    left_field: str,
    right_table: str,
    right_field: str,
) -> str:
    pair_one = (left_table, left_field.strip().lower())
    pair_two = (right_table, right_field.strip().lower())
    ordered_pairs = sorted([pair_one, pair_two])
    return (
        f"{ordered_pairs[0][0]}.{ordered_pairs[0][1]} = "
        f"{ordered_pairs[1][0]}.{ordered_pairs[1][1]}"
    )


def _has_grounded_asset_plan(asset_selection_plan: AssetSelectionPlan | None) -> bool:
    if asset_selection_plan is None:
        return False
    return any([
        asset_selection_plan.base_table,
        asset_selection_plan.selected_tables,
        asset_selection_plan.selected_joins,
        asset_selection_plan.entity,
        asset_selection_plan.entity_key_field,
        asset_selection_plan.grain_description,
        asset_selection_plan.business_intent,
        asset_selection_plan.measure_intent,
        asset_selection_plan.ranking_intent,
        asset_selection_plan.filters_summary,
        asset_selection_plan.rationale,
    ])
