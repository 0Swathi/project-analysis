from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from backend.app.adapters.semantic_model_adapter import AdaptedSemanticModel, SemanticModelAdapter
from backend.app.core.errors import SemanticModelError
from backend.app.schemas.responses import ValidateSemanticModelResponse
from backend.app.schemas.semantic_model import SemanticModel, SemanticModelSummary


class SemanticModelService:
    def __init__(self, adapter: SemanticModelAdapter | None = None) -> None:
        self.adapter = adapter or SemanticModelAdapter()

    def load_from_path(self, path: str | Path) -> AdaptedSemanticModel:
        model_path = Path(path)
        if not model_path.exists() or not model_path.is_file():
            raise SemanticModelError(
                f"Semantic model file not found: {model_path}",
                details={"path": str(model_path)},
            )

        try:
            raw_model = json.loads(model_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise SemanticModelError(
                f"Semantic model file is not valid JSON: {model_path}",
                details={"path": str(model_path), "line": exc.lineno, "column": exc.colno},
            ) from exc
        except OSError as exc:
            raise SemanticModelError(
                f"Semantic model file could not be read: {model_path}",
                details={"path": str(model_path), "reason": str(exc)},
            ) from exc

        return self.normalize_or_raise(raw_model)

    def normalize_or_raise(self, raw_model: dict[str, Any]) -> AdaptedSemanticModel:
        try:
            return self.adapter.adapt(raw_model)
        except ValidationError as exc:
            raise SemanticModelError(
                "Semantic model failed schema validation.",
                details={"errors": exc.errors()},
            ) from exc

    def validate(self, raw_model: dict[str, Any]) -> ValidateSemanticModelResponse:
        try:
            adapted = self.normalize_or_raise(raw_model)
        except (SemanticModelError, ValidationError, TypeError, ValueError) as exc:
            message = getattr(exc, "message", str(exc))
            return ValidateSemanticModelResponse(
                status="invalid",
                valid=False,
                errors=[message],
                warnings=[],
                summary=None,
            )

        return ValidateSemanticModelResponse(
            status="ok",
            valid=True,
            errors=[],
            warnings=adapted.warnings,
            summary=SemanticModelSummary.from_model(adapted.semantic_model),
        )

    def summarize(self, semantic_model: SemanticModel) -> SemanticModelSummary:
        return SemanticModelSummary.from_model(semantic_model)
