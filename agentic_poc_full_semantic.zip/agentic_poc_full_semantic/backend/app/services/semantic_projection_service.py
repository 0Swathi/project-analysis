from __future__ import annotations

from dataclasses import dataclass

from backend.app.schemas.asset_selection import AssetSelectionPlan, SelectedJoin, SelectedTable
from backend.app.schemas.semantic_model import (
    RelationshipEndpoint,
    SemanticField,
    SemanticModel,
    SemanticRelationship,
    SemanticTable,
)


@dataclass(frozen=True, slots=True)
class ProjectedSemanticModelResult:
    semantic_model: SemanticModel
    original_table_count: int
    original_field_count: int
    original_relationship_count: int
    projected_table_count: int
    projected_field_count: int
    projected_relationship_count: int


class SemanticProjectionService:
    def project(
        self,
        *,
        semantic_model: SemanticModel,
        asset_selection_plan: AssetSelectionPlan | None,
    ) -> ProjectedSemanticModelResult:
        original_table_count = len(semantic_model.tables)
        original_field_count = sum(len(table.fields) for table in semantic_model.tables)
        original_relationship_count = len(semantic_model.relationships)

        if asset_selection_plan is None or not self._has_projection_value(asset_selection_plan):
            return ProjectedSemanticModelResult(
                semantic_model=semantic_model.model_copy(deep=True),
                original_table_count=original_table_count,
                original_field_count=original_field_count,
                original_relationship_count=original_relationship_count,
                projected_table_count=original_table_count,
                projected_field_count=original_field_count,
                projected_relationship_count=original_relationship_count,
            )

        selected_tables = self._select_tables(semantic_model, asset_selection_plan)
        projected_relationships = self._select_relationships(
            semantic_model=semantic_model,
            asset_selection_plan=asset_selection_plan,
            selected_tables=selected_tables,
        )

        projected_model = semantic_model.model_copy(
            update={
                "tables": selected_tables,
                "relationships": projected_relationships,
                "metadata": {
                    **semantic_model.metadata,
                    "projection": {
                        "applied": True,
                        "base_table": asset_selection_plan.base_table,
                        "selected_table_count": len(selected_tables),
                        "selected_relationship_count": len(projected_relationships),
                    },
                },
            },
            deep=True,
        )

        projected_field_count = sum(len(table.fields) for table in selected_tables)
        return ProjectedSemanticModelResult(
            semantic_model=projected_model,
            original_table_count=original_table_count,
            original_field_count=original_field_count,
            original_relationship_count=original_relationship_count,
            projected_table_count=len(selected_tables),
            projected_field_count=projected_field_count,
            projected_relationship_count=len(projected_relationships),
        )

    def _has_projection_value(self, asset_selection_plan: AssetSelectionPlan) -> bool:
        return bool(
            asset_selection_plan.base_table
            or asset_selection_plan.selected_tables
            or asset_selection_plan.selected_joins
        )

    def _select_tables(
        self,
        semantic_model: SemanticModel,
        asset_selection_plan: AssetSelectionPlan,
    ) -> list[SemanticTable]:
        plan_tables = asset_selection_plan.selected_tables
        selected_tables: list[SemanticTable] = []

        if plan_tables:
            for selected_table in plan_tables:
                matched_table = self._find_table(
                    semantic_model,
                    table_name=selected_table.table_name,
                    qualified_name=selected_table.qualified_name,
                )
                if matched_table is None:
                    continue
                selected_tables.append(
                    self._project_table_fields(
                        matched_table,
                        selected_table,
                        asset_selection_plan=asset_selection_plan,
                    )
                )

        if not selected_tables and asset_selection_plan.base_table:
            matched_base_table = self._find_table(
                semantic_model,
                table_name=asset_selection_plan.base_table,
                qualified_name=asset_selection_plan.base_table,
            )
            if matched_base_table is not None:
                selected_tables.append(matched_base_table.model_copy(deep=True))

        if not selected_tables:
            return [table.model_copy(deep=True) for table in semantic_model.tables]

        # Any table referenced in selected_joins but absent from selected_tables must be
        # added so that the projected relationships are internally consistent.
        if asset_selection_plan.selected_joins:
            included_names: set[str] = {t.name for t in selected_tables} | {
                t.qualified_name for t in selected_tables if t.qualified_name
            }
            for join in asset_selection_plan.selected_joins:
                for ref_name in (join.left_table_name, join.right_table_name):
                    if ref_name not in included_names:
                        missing = self._find_table(
                            semantic_model, table_name=ref_name, qualified_name=None
                        )
                        if missing is not None:
                            selected_tables.append(missing.model_copy(deep=True))
                            included_names.add(missing.name)
                            if missing.qualified_name:
                                included_names.add(missing.qualified_name)

        deduped: list[SemanticTable] = []
        seen: set[str] = set()
        for table in selected_tables:
            key = self._table_key(table.name, table.qualified_name)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(table)
        return deduped

    def _project_table_fields(
        self,
        table: SemanticTable,
        selected_table: SelectedTable,
        *,
        asset_selection_plan: AssetSelectionPlan,
    ) -> SemanticTable:
        explicit_required_field_names = {
            field_name.strip().lower()
            for field_name in selected_table.required_fields
            if field_name.strip()
        }

        if not explicit_required_field_names:
            return table.model_copy(deep=True)

        required_field_names = set(explicit_required_field_names)
        if selected_table.role == "base" and asset_selection_plan.entity_key_field:
            required_field_names.add(asset_selection_plan.entity_key_field.strip().lower())

        join_endpoint_names = self._join_endpoint_field_names(
            asset_selection_plan=asset_selection_plan,
            table=table,
        )
        required_field_names.update(join_endpoint_names)

        if not required_field_names:
            return table.model_copy(deep=True)

        projected_fields = [
            field.model_copy(deep=True)
            for field in table.fields
            if field.name.strip().lower() in required_field_names
        ]

        if not projected_fields:
            projected_fields = [field.model_copy(deep=True) for field in table.fields]

        return table.model_copy(update={"fields": projected_fields}, deep=True)

    def _join_endpoint_field_names(
        self,
        *,
        asset_selection_plan: AssetSelectionPlan,
        table: SemanticTable,
    ) -> set[str]:
        endpoint_fields: set[str] = set()
        for selected_join in asset_selection_plan.selected_joins:
            if self._matches_table_reference(
                table,
                selected_join.left_table_name,
            ):
                endpoint_fields.add(selected_join.left_field_name.strip().lower())
            if self._matches_table_reference(
                table,
                selected_join.right_table_name,
            ):
                endpoint_fields.add(selected_join.right_field_name.strip().lower())
        return endpoint_fields

    def _select_relationships(
        self,
        *,
        semantic_model: SemanticModel,
        asset_selection_plan: AssetSelectionPlan,
        selected_tables: list[SemanticTable],
    ) -> list[SemanticRelationship]:
        selected_table_keys = {
            self._table_key(table.name, table.qualified_name) for table in selected_tables
        }

        short_keys = {key.split(".")[-1] for key in selected_table_keys}

        relationships: list[SemanticRelationship] = []
        if asset_selection_plan.selected_joins:
            for selected_join in asset_selection_plan.selected_joins:
                if not self._selected_join_tables_present(
                    selected_join=selected_join,
                    selected_table_keys=selected_table_keys,
                ):
                    continue
                matched_relationship = self._find_relationship(
                    semantic_model=semantic_model,
                    selected_join=selected_join,
                )
                if matched_relationship is not None:
                    relationships.append(matched_relationship.model_copy(deep=True))
                    continue
                relationships.append(self._relationship_from_selected_join(selected_join))

            # Also include any declared relationship where both endpoint tables are
            # in the projected model but the relationship was not covered by selected_joins.
            for relationship in semantic_model.relationships:
                left_name = relationship.left.table_name
                right_name = relationship.right.table_name
                if (
                    (left_name in selected_table_keys or left_name in short_keys)
                    and (right_name in selected_table_keys or right_name in short_keys)
                ):
                    relationships.append(relationship.model_copy(deep=True))
        else:
            for relationship in semantic_model.relationships:
                left_name = relationship.left.table_name
                right_name = relationship.right.table_name
                left_match = left_name in selected_table_keys or left_name in short_keys
                right_match = right_name in selected_table_keys or right_name in short_keys
                if left_match and right_match:
                    relationships.append(relationship.model_copy(deep=True))

        deduped: list[SemanticRelationship] = []
        seen: set[tuple[str, str, str, str]] = set()
        for relationship in relationships:
            key = (
                relationship.left.table_name,
                relationship.left.field_name,
                relationship.right.table_name,
                relationship.right.field_name,
            )
            if key in seen:
                continue
            seen.add(key)
            deduped.append(relationship)
        return deduped

    def _selected_join_tables_present(
        self,
        *,
        selected_join: SelectedJoin,
        selected_table_keys: set[str],
    ) -> bool:
        return (
            selected_join.left_table_name in selected_table_keys
            or selected_join.left_table_name in {
                key.split(".")[-1] for key in selected_table_keys
            }
        ) and (
            selected_join.right_table_name in selected_table_keys
            or selected_join.right_table_name in {
                key.split(".")[-1] for key in selected_table_keys
            }
        )

    def _find_table(
        self,
        semantic_model: SemanticModel,
        *,
        table_name: str | None,
        qualified_name: str | None,
    ) -> SemanticTable | None:
        for table in semantic_model.tables:
            if qualified_name and table.qualified_name == qualified_name:
                return table
            if table_name and (
                table.name == table_name
                or table.qualified_name == table_name
            ):
                return table
        return None

    def _find_relationship(
        self,
        *,
        semantic_model: SemanticModel,
        selected_join: SelectedJoin,
    ) -> SemanticRelationship | None:
        for relationship in semantic_model.relationships:
            if self._relationship_matches_selected_join(relationship, selected_join):
                return relationship
        return None

    def _relationship_matches_selected_join(
        self,
        relationship: SemanticRelationship,
        selected_join: SelectedJoin,
    ) -> bool:
        endpoints = {
            (
                relationship.left.table_name,
                relationship.left.field_name,
                relationship.right.table_name,
                relationship.right.field_name,
            ),
            (
                relationship.right.table_name,
                relationship.right.field_name,
                relationship.left.table_name,
                relationship.left.field_name,
            ),
        }
        return (
            selected_join.left_table_name,
            selected_join.left_field_name,
            selected_join.right_table_name,
            selected_join.right_field_name,
        ) in endpoints

    def _relationship_from_selected_join(
        self,
        selected_join: SelectedJoin,
    ) -> SemanticRelationship:
        return SemanticRelationship(
            left=RelationshipEndpoint(
                table_name=selected_join.left_table_name,
                field_name=selected_join.left_field_name,
            ),
            right=RelationshipEndpoint(
                table_name=selected_join.right_table_name,
                field_name=selected_join.right_field_name,
            ),
            relationship_type=selected_join.relationship_type,
            description=selected_join.rationale,
            join_hint=selected_join.rationale,
            selection_hints=[],
        )

    def _matches_table_reference(
        self,
        table: SemanticTable,
        reference: str,
    ) -> bool:
        return table.name == reference or table.qualified_name == reference

    def _table_key(self, name: str, qualified_name: str | None) -> str:
        return qualified_name or name
