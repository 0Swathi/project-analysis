from __future__ import annotations

from time import perf_counter
from typing import Any

from backend.app.agents.orchestrator import GenerationOrchestrator
from backend.app.core.config import Settings, get_settings
from backend.app.core.errors import (
    AppError,
    BadRequestError,
    SqlGenerationError,
    SqlValidationError,
)
from backend.app.prompts.sql_prompt_builder import SqlPromptBuilder
from backend.app.schemas.asset_selection import AssetSelectionPlan
from backend.app.schemas.requests import GenerateSqlRequest
from backend.app.schemas.responses import (
    GenerateSqlDebug,
    GenerateSqlResponse,
    ResponseMetadata,
    ValidateSemanticModelResponse,
)
from backend.app.services.semantic_model_service import SemanticModelService
from backend.app.services.sql_plan_validator import SqlPlanValidator


class SqlGenerationService:
    def __init__(
        self,
        *,
        semantic_model_service: SemanticModelService | None = None,
        prompt_builder: SqlPromptBuilder | None = None,
        orchestrator: GenerationOrchestrator | None = None,
        sql_plan_validator: SqlPlanValidator | None = None,
        settings: Settings | None = None,
        max_validation_retries: int | None = None,
    ) -> None:
        self.settings = settings or get_settings()
        self.semantic_model_service = semantic_model_service or SemanticModelService()
        self.prompt_builder = prompt_builder or SqlPromptBuilder()
        self.orchestrator = orchestrator or GenerationOrchestrator()
        self.sql_plan_validator = sql_plan_validator or SqlPlanValidator()
        self.max_validation_retries = (
            max_validation_retries
            if max_validation_retries is not None
            else self.settings.validation_max_retries
        )

    def generate(self, request: GenerateSqlRequest) -> GenerateSqlResponse:
        started_at = perf_counter()
        adapted_model = self.semantic_model_service.normalize_or_raise(request.semantic_model)
        resolved_model_name = request.model or self.settings.openai_model
        has_grounded_plan = _has_grounded_asset_plan(request.asset_selection_plan)

        context_report = self.prompt_builder.build_context_report(
            semantic_model=adapted_model.semantic_model,
            asset_selection_plan=request.asset_selection_plan,
            question=request.question,
            model_name=resolved_model_name,
            context_window=self.prompt_builder.get_context_window(resolved_model_name),
        )
        if context_report.exceeds_window:
            raise BadRequestError(
                "Estimated input exceeds the model context window.",
                details={"context_report": context_report.model_dump()},
            )

        system_prompt = self.prompt_builder.build_agent_system_prompt(
            adapted_model.semantic_model,
            request.asset_selection_plan,
            prior_sql=request.prior_sql,
            semantic_change_request=request.semantic_change_request,
        )
        user_input = self.prompt_builder.build_agent_input(
            request.question,
            context_report,
            request.asset_selection_plan,
            prior_sql=request.prior_sql,
        )

        current_user_input = user_input
        all_attempts: list[dict] = []
        agent_result = None
        validation_result = None

        for attempt in range(self.max_validation_retries + 1):
            try:
                agent_result = self.orchestrator.generate_sql(
                    system_prompt=system_prompt,
                    user_input=current_user_input,
                    asset_selection_plan=request.asset_selection_plan,
                    model_name=resolved_model_name,
                    debug=request.debug,
                )
            except AppError:
                raise
            except Exception as exc:
                raise SqlGenerationError(
                    "Unexpected SQL generation failure.",
                    details={"reason": str(exc)},
                ) from exc

            validation_result = self.sql_plan_validator.validate(
                sql=agent_result.sql,
                asset_selection_plan=request.asset_selection_plan,
            )

            if validation_result.valid:
                break

            all_attempts.append({
                "attempt": attempt + 1,
                "violations": validation_result.violations,
                "sql": agent_result.sql,
            })

            if attempt < self.max_validation_retries:
                current_user_input = self.prompt_builder.build_retry_input(
                    original_user_input=user_input,
                    failed_sql=agent_result.sql,
                    violations=validation_result.violations,
                    attempt=attempt + 1,
                    max_attempts=self.max_validation_retries + 1,
                )
            else:
                raise SqlValidationError(
                    "Generated SQL violated the grounded data plan after all retry attempts.",
                    details={
                        "attempts": all_attempts,
                        "referenced_tables": validation_result.referenced_tables,
                        "join_conditions": validation_result.join_conditions,
                    },
                )

        if agent_result is None or validation_result is None:
            raise SqlGenerationError(
                "SQL generation loop completed without producing a result.",
                details={"attempts": all_attempts},
            )

        duration_ms = int((perf_counter() - started_at) * 1000)
        debug_payload = None
        if request.debug:
            if request.prior_sql:
                prompt_mode = "followup_edit"
            elif has_grounded_plan:
                prompt_mode = "grounded"
            else:
                prompt_mode = "full_schema"
            trace = [
                f"sql_prompt_mode={prompt_mode}",
                f"semantic_model_source_format={adapted_model.semantic_model.source_format or 'unknown'}",
                f"table_count={len(adapted_model.semantic_model.tables)}",
                f"relationship_count={len(adapted_model.semantic_model.relationships)}",
                "asset_selection_plan_present="
                f"{str(has_grounded_plan).lower()}",
                "sql_plan_validator_passed="
                f"{str(validation_result.valid).lower()}",
                f"sql_plan_validator_attempts={attempt + 1}",
            ]
            if has_grounded_plan:
                trace.append(
                    f"asset_selection_base_table={request.asset_selection_plan.base_table or '<none>'}"
                )
                trace.append(
                    "asset_selection_selected_table_count="
                    f"{len(request.asset_selection_plan.selected_tables)}"
                )
                trace.append(
                    "asset_selection_selected_join_count="
                    f"{len(request.asset_selection_plan.selected_joins)}"
                )
                trace.append(
                    "validated_referenced_table_count="
                    f"{len(validation_result.referenced_tables)}"
                )
                trace.append(
                    "validated_join_condition_count="
                    f"{len(validation_result.join_conditions)}"
                )
            trace.extend(adapted_model.warnings)
            trace.extend(agent_result.trace)
            debug_payload = GenerateSqlDebug(
                context_report=context_report,
                trace=trace,
            )

        return GenerateSqlResponse(
            sql=agent_result.sql,
            explanation=agent_result.explanation,
            warnings=adapted_model.warnings,
            metadata=ResponseMetadata(
                request_id=request.request_id,
                model=resolved_model_name,
                prompt_version=self.settings.prompt_version,
                duration_ms=duration_ms,
            ),
            debug=debug_payload,
        )

    def validate_semantic_model(self, raw_model: dict[str, Any]) -> ValidateSemanticModelResponse:
        return self.semantic_model_service.validate(raw_model)


def _has_grounded_asset_plan(
    asset_selection_plan: AssetSelectionPlan | None,
) -> bool:
    if asset_selection_plan is None:
        return False
    return any(
        [
            asset_selection_plan.base_table,
            asset_selection_plan.selected_tables,
            asset_selection_plan.selected_joins,
            asset_selection_plan.entity,
            asset_selection_plan.entity_key_field,
            asset_selection_plan.grain_description,
            asset_selection_plan.business_intent,
            asset_selection_plan.measure_intent,
            asset_selection_plan.ranking_intent,
            asset_selection_plan.filters_summary,
            asset_selection_plan.rationale,
        ]
    )
