"""LangChain agents and orchestration boundaries."""
