from __future__ import annotations

from dataclasses import dataclass, field

from pydantic import BaseModel, ConfigDict

from backend.app.core.config import Settings, get_settings
from backend.app.core.errors import ConfigurationError, SqlGenerationError
from backend.app.llm.openai_client import model_supports_reasoning
from backend.app.schemas.asset_selection import AssetSelectionPlan



class SqlAgentStructuredResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    sql: str
    explanation: str


@dataclass(slots=True)
class SqlAgentInvocationResult:
    sql: str
    explanation: str
    trace: list[str] = field(default_factory=list)


class SqlGeneratorAgent:
    def __init__(
        self,
        *,
        settings: Settings | None = None,
        api_key: str | None = None,
        timeout_seconds: int | None = None,
        reasoning_effort: str = "medium",
    ) -> None:
        self.settings = settings or get_settings()
        self.api_key = api_key or self.settings.openai_api_key
        self.timeout_seconds = timeout_seconds or self.settings.openai_timeout_seconds
        self.reasoning_effort = reasoning_effort

    def generate(
        self,
        *,
        system_prompt: str,
        user_input: str,
        asset_selection_plan: AssetSelectionPlan | None = None,
        model_name: str | None = None,
        debug: bool = False,
    ) -> SqlAgentInvocationResult:
        if not self.api_key:
            raise ConfigurationError("OPENAI_API_KEY is not set.")

        try:
            from langchain.agents import create_agent
            from langchain_openai import ChatOpenAI
        except ImportError as exc:
            raise RuntimeError(
                "LangChain dependencies are not installed or are incompatible. "
                "Install langchain and langchain-openai."
            ) from exc

        resolved_model_name = model_name or self.settings.openai_model
        trace: list[str] = [f"langchain_model={resolved_model_name}"]

        llm_kwargs: dict = dict(
            model=resolved_model_name,
            api_key=self.api_key,
            timeout=self.timeout_seconds,
            temperature=0,
            use_responses_api=True,
        )
        if self.reasoning_effort and model_supports_reasoning(resolved_model_name):
            llm_kwargs["reasoning_effort"] = self.reasoning_effort
        llm = ChatOpenAI(**llm_kwargs)
        agent = create_agent(
            model=llm,
            tools=[],
            system_prompt=system_prompt,
            response_format=SqlAgentStructuredResponse,
            debug=debug,
            name="sql_generator",
        )

        try:
            state = agent.invoke(
                {
                    "messages": [
                        {
                            "role": "user",
                            "content": user_input,
                        }
                    ]
                }
            )
        except Exception as exc:
            raise SqlGenerationError(
                "LangChain SQL agent invocation failed.",
                details={"reason": str(exc)},
            ) from exc

        structured = state.get("structured_response")
        if isinstance(structured, SqlAgentStructuredResponse):
            parsed = structured
        elif isinstance(structured, dict):
            parsed = SqlAgentStructuredResponse.model_validate(structured)
        else:
            raise SqlGenerationError(
                "LangChain SQL agent did not return structured output.",
                details={"state_keys": sorted(state.keys()) if isinstance(state, dict) else []},
            )

        if debug:
            message_count = len(state.get("messages", [])) if isinstance(state, dict) else 0
            trace.append(f"langchain_message_count={message_count}")
            trace.append("structured_response_received=true")
            trace.append(
                "asset_selection_plan_present="
                f"{str(asset_selection_plan is not None).lower()}"
            )
            if asset_selection_plan is not None:
                trace.append(f"asset_selection_base_table={asset_selection_plan.base_table or '<none>'}")
                trace.append(
                    "asset_selection_selected_table_count="
                    f"{len(asset_selection_plan.selected_tables)}"
                )
                trace.append(
                    "asset_selection_selected_join_count="
                    f"{len(asset_selection_plan.selected_joins)}"
                )

        return SqlAgentInvocationResult(
            sql=parsed.sql,
            explanation=parsed.explanation,
            trace=trace,
        )
