from __future__ import annotations

from backend.app.schemas.asset_selection import AssetSelectionPlan
from backend.app.agents.sql_generator_agent import SqlAgentInvocationResult, SqlGeneratorAgent


class GenerationOrchestrator:
    def __init__(self, sql_generator_agent: SqlGeneratorAgent | None = None) -> None:
        self.sql_generator_agent = sql_generator_agent or SqlGeneratorAgent()

    def generate_sql(
        self,
        *,
        system_prompt: str,
        user_input: str,
        asset_selection_plan: AssetSelectionPlan | None = None,
        model_name: str | None = None,
        debug: bool = False,
    ) -> SqlAgentInvocationResult:
        return self.sql_generator_agent.generate(
            system_prompt=system_prompt,
            user_input=user_input,
            asset_selection_plan=asset_selection_plan,
            model_name=model_name,
            debug=debug,
        )
