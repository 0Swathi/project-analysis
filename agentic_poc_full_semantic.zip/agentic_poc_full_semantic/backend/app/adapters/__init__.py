"""Adapters that normalize external inputs into internal backend models."""
