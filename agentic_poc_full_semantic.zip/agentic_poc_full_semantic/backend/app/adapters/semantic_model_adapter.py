from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pydantic import ValidationError

from backend.app.core.errors import SemanticModelError
from backend.app.schemas.semantic_model import (
    RelationshipEndpoint,
    SemanticField,
    SemanticModel,
    SemanticRelationship,
    SemanticTable,
)


@dataclass(slots=True)
class AdaptedSemanticModel:
    semantic_model: SemanticModel
    warnings: list[str] = field(default_factory=list)


class SemanticModelAdapter:
    def adapt(self, raw_model: dict[str, Any]) -> AdaptedSemanticModel:
        if not isinstance(raw_model, dict):
            raise SemanticModelError("Semantic model payload must be a JSON object.")

        try:
            if isinstance(raw_model.get("entities"), list):
                return self._adapt_entities_format(raw_model)
            if isinstance(raw_model.get("tables"), list):
                return self._adapt_tables_format(raw_model)
        except ValidationError as exc:
            raise SemanticModelError(
                "Semantic model could not be normalized into the internal schema.",
                details={"errors": exc.errors()},
            ) from exc

        raise SemanticModelError(
            "Semantic model must contain either an 'entities' array or a 'tables' array.",
            details={"top_level_keys": sorted(raw_model.keys())},
        )

    def _adapt_tables_format(self, raw_model: dict[str, Any]) -> AdaptedSemanticModel:
        warnings: list[str] = []
        tables: list[SemanticTable] = []
        dataset_name = _first_non_blank(raw_model.get("dataset_name"), raw_model.get("name"))
        dataset_description = _first_non_blank(
            raw_model.get("dataset_description"),
            raw_model.get("description"),
        )

        for index, table_payload in enumerate(raw_model.get("tables", [])):
            if not isinstance(table_payload, dict):
                raise SemanticModelError(f"Table at index {index} must be an object.")

            table_name = _first_non_blank(
                table_payload.get("name"),
                table_payload.get("table_name"),
                table_payload.get("qualified_name"),
            )
            if table_name is None:
                raise SemanticModelError(f"Table at index {index} is missing a name.")

            fields = self._adapt_fields(
                table_payload.get("fields"),
                table_name=table_name,
                warnings=warnings,
            )

            tables.append(
                SemanticTable(
                    name=table_name,
                    qualified_name=_first_non_blank(table_payload.get("qualified_name"), table_name),
                    description=_first_non_blank(
                        table_payload.get("description"),
                        table_payload.get("table_description"),
                    ),
                    canonical_entity=_first_non_blank(table_payload.get("canonical_entity")),
                    preferred_entity_key=_first_non_blank(
                        table_payload.get("preferred_entity_key")
                    ),
                    grain_description=_first_non_blank(
                        table_payload.get("grain_description")
                    ),
                    source_of_truth_for=_string_list(
                        table_payload.get("source_of_truth_for")
                    ),
                    selection_hints=_string_list(table_payload.get("selection_hints")),
                    fields=fields,
                    metadata=_remaining_items(
                        table_payload,
                        known_keys={
                            "name",
                            "table_name",
                            "qualified_name",
                            "description",
                            "table_description",
                            "canonical_entity",
                            "preferred_entity_key",
                            "grain_description",
                            "source_of_truth_for",
                            "selection_hints",
                            "fields",
                        },
                    ),
                )
            )

        relationships = self._adapt_relationships(raw_model.get("relationships"), warnings)
        self._add_model_level_warnings(tables, relationships, warnings)

        semantic_model = SemanticModel(
            name=dataset_name,
            description=dataset_description,
            domain=_first_non_blank(raw_model.get("domain")),
            selection_hints=_string_list(raw_model.get("selection_hints")),
            tables=tables,
            relationships=relationships,
            source_format="tables",
            metadata=_remaining_items(
                raw_model,
                known_keys={
                    "name",
                    "description",
                    "dataset_name",
                    "dataset_description",
                    "domain",
                    "selection_hints",
                    "tables",
                    "relationships",
                },
            ),
        )
        return AdaptedSemanticModel(semantic_model=semantic_model, warnings=warnings)

    def _adapt_entities_format(self, raw_model: dict[str, Any]) -> AdaptedSemanticModel:
        warnings: list[str] = []
        tables: list[SemanticTable] = []

        for index, entity_payload in enumerate(raw_model.get("entities", [])):
            if not isinstance(entity_payload, dict):
                raise SemanticModelError(f"Entity at index {index} must be an object.")

            entity_name = _first_non_blank(entity_payload.get("name"))
            if entity_name is None:
                raise SemanticModelError(f"Entity at index {index} is missing a name.")

            base_table = entity_payload.get("base_table")
            if base_table is not None and not isinstance(base_table, dict):
                raise SemanticModelError(f"Entity '{entity_name}' has an invalid base_table payload.")

            base_table = base_table or {}
            qualified_name = _first_non_blank(base_table.get("qualified_name"), entity_name)
            fields = self._adapt_fields(
                entity_payload.get("fields"),
                table_name=entity_name,
                warnings=warnings,
            )

            tables.append(
                SemanticTable(
                    name=entity_name,
                    qualified_name=qualified_name,
                    description=_first_non_blank(entity_payload.get("description")),
                    canonical_entity=_first_non_blank(entity_payload.get("canonical_entity")),
                    preferred_entity_key=_first_non_blank(
                        entity_payload.get("preferred_entity_key")
                    ),
                    grain_description=_first_non_blank(
                        entity_payload.get("grain_description")
                    ),
                    source_of_truth_for=_string_list(
                        entity_payload.get("source_of_truth_for")
                    ),
                    selection_hints=_string_list(entity_payload.get("selection_hints")),
                    fields=fields,
                    metadata={
                        **_remaining_items(
                            entity_payload,
                            known_keys={
                                "name",
                                "description",
                                "canonical_entity",
                                "preferred_entity_key",
                                "grain_description",
                                "source_of_truth_for",
                                "selection_hints",
                                "base_table",
                                "fields",
                            },
                        ),
                        "base_table": _remaining_items(
                            base_table,
                            known_keys={"qualified_name", "database", "schema", "table"},
                        ),
                        "database": base_table.get("database"),
                        "schema": base_table.get("schema"),
                        "table": base_table.get("table"),
                    },
                )
            )

        relationships = self._adapt_relationships(raw_model.get("relationships"), warnings)
        self._add_model_level_warnings(tables, relationships, warnings)

        semantic_model = SemanticModel(
            name=_first_non_blank(raw_model.get("name"), raw_model.get("dataset_name")),
            description=_first_non_blank(raw_model.get("description"), raw_model.get("dataset_description")),
            domain=_first_non_blank(raw_model.get("domain")),
            selection_hints=_string_list(raw_model.get("selection_hints")),
            tables=tables,
            relationships=relationships,
            source_format="entities",
            metadata=_remaining_items(
                raw_model,
                known_keys={
                    "name",
                    "description",
                    "dataset_name",
                    "dataset_description",
                    "domain",
                    "selection_hints",
                    "entities",
                    "relationships",
                },
            ),
        )
        return AdaptedSemanticModel(semantic_model=semantic_model, warnings=warnings)

    def _adapt_fields(
        self,
        fields_payload: Any,
        *,
        table_name: str,
        warnings: list[str],
    ) -> list[SemanticField]:
        if fields_payload is None:
            warnings.append(f"Table '{table_name}' does not declare any fields.")
            return []

        if not isinstance(fields_payload, list):
            raise SemanticModelError(f"Fields for table '{table_name}' must be an array.")

        fields: list[SemanticField] = []
        for index, field_payload in enumerate(fields_payload):
            if not isinstance(field_payload, dict):
                raise SemanticModelError(
                    f"Field at index {index} in table '{table_name}' must be an object."
                )

            field_name = _first_non_blank(field_payload.get("name"))
            if field_name is None:
                raise SemanticModelError(
                    f"Field at index {index} in table '{table_name}' is missing a name."
                )

            fields.append(
                SemanticField(
                    name=field_name,
                    description=_first_non_blank(field_payload.get("description")),
                    data_type=_first_non_blank(field_payload.get("data_type")),
                    kind=_first_non_blank(field_payload.get("kind")),
                    expression=_first_non_blank(field_payload.get("expression")),
                    default_aggregation=_first_non_blank(field_payload.get("default_aggregation")),
                    selection_hints=_string_list(field_payload.get("selection_hints")),
                    metadata=_remaining_items(
                        field_payload,
                        known_keys={
                            "name",
                            "description",
                            "data_type",
                            "kind",
                            "expression",
                            "default_aggregation",
                            "selection_hints",
                        },
                    ),
                )
            )

        if not fields:
            warnings.append(f"Table '{table_name}' has an empty fields array.")
        return fields

    def _adapt_relationships(
        self,
        relationships_payload: Any,
        warnings: list[str],
    ) -> list[SemanticRelationship]:
        if relationships_payload is None:
            return []
        if not isinstance(relationships_payload, list):
            raise SemanticModelError("relationships must be an array when provided.")

        relationships: list[SemanticRelationship] = []
        for index, relationship_payload in enumerate(relationships_payload):
            if not isinstance(relationship_payload, dict):
                warnings.append(
                    f"Skipped relationship at index {index} because it is not an object."
                )
                continue

            left = _coerce_endpoint(relationship_payload.get("left") or relationship_payload.get("from"))
            right = _coerce_endpoint(relationship_payload.get("right") or relationship_payload.get("to"))
            if left is None or right is None:
                warnings.append(
                    f"Skipped relationship at index {index} because its endpoints were not recognized."
                )
                continue

            relationships.append(
                SemanticRelationship(
                    left=left,
                    right=right,
                    relationship_type=_first_non_blank(
                        relationship_payload.get("relationship_type"),
                        relationship_payload.get("type"),
                    ),
                    description=_first_non_blank(relationship_payload.get("description")),
                    join_hint=_first_non_blank(relationship_payload.get("join_hint")),
                    selection_hints=_string_list(
                        relationship_payload.get("selection_hints")
                    ),
                    metadata=_remaining_items(
                        relationship_payload,
                        known_keys={
                            "left",
                            "right",
                            "from",
                            "to",
                            "relationship_type",
                            "type",
                            "description",
                            "join_hint",
                            "selection_hints",
                        },
                    ),
                )
            )
        return relationships

    def _add_model_level_warnings(
        self,
        tables: list[SemanticTable],
        relationships: list[SemanticRelationship],
        warnings: list[str],
    ) -> None:
        if not tables:
            warnings.append("Semantic model does not declare any tables.")
        if len(tables) > 1 and not relationships:
            warnings.append(
                "Semantic model has multiple tables but no declared relationships."
            )


def _coerce_endpoint(payload: Any) -> RelationshipEndpoint | None:
    if not isinstance(payload, dict):
        return None

    table_name = _first_non_blank(
        payload.get("table_name"),
        payload.get("entity_name"),
        payload.get("table"),
        payload.get("entity"),
        payload.get("name"),
    )
    field_name = _first_non_blank(
        payload.get("field_name"),
        payload.get("column_name"),
        payload.get("field"),
        payload.get("column"),
    )
    if table_name is None or field_name is None:
        return None
    return RelationshipEndpoint(table_name=table_name, field_name=field_name)


def _remaining_items(payload: dict[str, Any], *, known_keys: set[str]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if key not in known_keys}


def _first_non_blank(*values: Any) -> str | None:
    for value in values:
        if isinstance(value, str):
            cleaned = value.strip()
            if cleaned:
                return cleaned
    return None


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []

    normalized: list[str] = []
    for item in value:
        if not isinstance(item, str):
            continue
        cleaned = item.strip()
        if cleaned:
            normalized.append(cleaned)
    return normalized
