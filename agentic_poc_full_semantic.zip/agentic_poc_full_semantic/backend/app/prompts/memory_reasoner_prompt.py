from __future__ import annotations

import json
from typing import Any

from backend.app.memory.state import ContextSnapshot, SessionMemory


class MemoryReasonerPromptBuilder:
    def build_system_prompt(self) -> str:
        return (
            "You are a conversation-memory resolver for an analytics SQL assistant. "
            "Your job is to classify the current user turn and resolve it into a standalone question "
            "using the current session context.\n\n"
            "You must decide whether the turn is one of:\n"
            "- fresh: a new topic or self-contained new request\n"
            "- follow_up: a continuation/modification of the active context\n"
            "- historical_callback: a return to an earlier topic captured in a snapshot\n\n"
            "Rules:\n"
            "1. Classify as follow_up ONLY when the message contains explicit back-references to the "
            "prior turn: pronouns (it, them, those, that, they), contextual modifiers (also, instead, "
            "additionally, filter that, break that down, now do it by), or phrases that are semantically "
            "incomplete without the prior context.\n"
            "2. Classify as fresh when the message contains none of the above signals AND introduces a "
            "new entity, metric, table, or analytical intent — or when it could stand alone as a first "
            "question in a new session and make complete sense.\n"
            "3. Tie-breaker: when genuinely ambiguous between fresh and follow_up, prefer fresh. The cost "
            "of incorrectly starting fresh is lower than incorrectly inheriting a stale context.\n"
            "4. Classify as historical_callback only when the message explicitly requests a return to an "
            "earlier topic captured in a snapshot (e.g. 'go back to...', 'return to the earlier question "
            "about...').\n"
            "5. If active_context.last_updated_turn_index is present and more than 3 turns behind the "
            "current turn_index, treat the active context as background reference only — do not classify "
            "as follow_up solely because the tables or domain overlap.\n"
            "6. Only set clarification_required=true if the ambiguity changes which table or metric is "
            "used AND no reasonable default can be inferred from the question, session context, or semantic "
            "model. If a sensible default covers most interpretations, resolve with that assumption instead "
            "of asking.\n"
            "7. resolved_question rules by turn type:\n"
            "   - fresh: rephrase the user's message for clarity only. Do NOT inject active context.\n"
            "   - follow_up: expand into a standalone question using the minimal necessary prior context.\n"
            "   - historical_callback: expand using the target snapshot's context.\n"
            "8. You must set operation_type to the best semantic action for this turn.\n"
            "9. semantic_change_request must describe business-intent changes, not SQL syntax. Use "
            "filters_to_add for additive refinements, filters_to_replace when replacing an old filter, "
            "time_scope_change for time changes, grouping_changes for breakdown changes, measure_change "
            "for metric changes, ranking_change for top/bottom/rank intents.\n"
            "10. Keep state_patch as a minimal legacy compatibility patch for the current runtime. For "
            "fields you are not changing in state_patch, return null.\n"
            "11. When updating state_patch.filters, return it as a list of {key, value} objects.\n"
            "12. Do not generate SQL. Do not answer the user's business question.\n"
            "13. Return only structured output matching the provided schema."
        )

    def build_user_prompt(
        self,
        *,
        message: str,
        session: SessionMemory,
        candidate_snapshots: list[ContextSnapshot],
        semantic_model: dict[str, Any],
        semantic_model_key: str | None = None,
    ) -> str:
        payload = {
            "current_message": message,
            "semantic_model": self._semantic_model_summary(
                semantic_model,
                semantic_model_key=semantic_model_key,
            ),
            "active_context": (
                session.active_context.model_dump(mode="json")
                if session.active_context is not None
                else None
            ),
            "recent_messages": [
                message_item.model_dump(mode="json")
                for message_item in session.messages[-6:]
            ],
            "candidate_snapshots": [
                snapshot.model_dump(mode="json")
                for snapshot in candidate_snapshots
            ],
            "rolling_summary": session.rolling_summary,
            "turn_index": session.turn_index,
        }
        return (
            "Resolve the current turn using the session context below.\n\n"
            f"{json.dumps(payload, indent=2, sort_keys=True)}"
        )

    def build_response_schema(self) -> dict[str, Any]:
        return {
            "name": "memory_reasoner_decision",
            "schema": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "turn_type": {
                        "type": "string",
                        "enum": ["fresh", "follow_up", "historical_callback"],
                    },
                    "operation_type": {
                        "type": "string",
                        "enum": [
                            "refine_current_context",
                            "add_filter",
                            "change_time_scope",
                            "change_grouping",
                            "change_measure",
                            "return_to_snapshot",
                            "switch_topic",
                        ],
                    },
                    "resolved_question": self._nullable_string_schema(),
                    "use_active_context": {"type": "boolean"},
                    "target_snapshot_id": self._nullable_string_schema(),
                    "semantic_change_request": self._semantic_change_request_schema(),
                    "state_patch": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "topic_id": self._nullable_string_schema(),
                            "topic_label": self._nullable_string_schema(),
                            "semantic_model_key": self._nullable_string_schema(),
                            "dataset_name": self._nullable_string_schema(),
                            "tables": self._nullable_string_list_schema(),
                            "metric": self._nullable_string_schema(),
                            "dimensions": self._nullable_string_list_schema(),
                            "filters": {
                                "anyOf": [
                                    {
                                        "type": "array",
                                        "items": {
                                            "type": "object",
                                            "additionalProperties": False,
                                            "properties": {
                                                "key": {"type": "string"},
                                                "value": {
                                                    "anyOf": [
                                                        {"type": "string"},
                                                        {"type": "number"},
                                                        {"type": "boolean"},
                                                        {"type": "null"},
                                                    ]
                                                },
                                            },
                                            "required": ["key", "value"],
                                        },
                                    },
                                    {"type": "null"},
                                ]
                            },
                        },
                        "required": [
                            "topic_id",
                            "topic_label",
                            "semantic_model_key",
                            "dataset_name",
                            "tables",
                            "metric",
                            "dimensions",
                            "filters",
                        ],
                    },
                    "clarification_required": {"type": "boolean"},
                    "clarification_question": self._nullable_string_schema(),
                    "topic_label": self._nullable_string_schema(),
                    "reason": self._nullable_string_schema(),
                },
                "required": [
                    "turn_type",
                    "operation_type",
                    "resolved_question",
                    "use_active_context",
                    "target_snapshot_id",
                    "semantic_change_request",
                    "state_patch",
                    "clarification_required",
                    "clarification_question",
                    "topic_label",
                    "reason",
                ],
            },
        }

    def _semantic_model_summary(
        self,
        semantic_model: dict[str, Any],
        *,
        semantic_model_key: str | None,
    ) -> dict[str, Any]:
        tables_payload = semantic_model.get("tables")
        table_names: list[str] = []
        if isinstance(tables_payload, list):
            for table_payload in tables_payload[:20]:
                if not isinstance(table_payload, dict):
                    continue
                for key in ("qualified_name", "table_name", "name"):
                    value = table_payload.get(key)
                    if isinstance(value, str) and value.strip():
                        table_names.append(value.strip())
                        break

        return {
            "semantic_model_key": semantic_model_key,
            "dataset_name": semantic_model.get("dataset_name") or semantic_model.get("name"),
            "table_names": table_names,
            "table_count": len(tables_payload) if isinstance(tables_payload, list) else 0,
        }

    def _nullable_string_schema(self) -> dict[str, Any]:
        return {"type": ["string", "null"]}

    def _nullable_string_list_schema(self) -> dict[str, Any]:
        return {
            "anyOf": [
                {"type": "array", "items": {"type": "string"}},
                {"type": "null"},
            ]
        }

    def _semantic_change_request_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "filters_to_add": {
                    "type": "array",
                    "items": self._analytical_filter_schema(),
                },
                "filters_to_replace": {
                    "type": "array",
                    "items": self._analytical_filter_schema(),
                },
                "grouping_changes": {
                    "type": "array",
                    "items": self._analytical_grouping_schema(),
                },
                "measure_change": self._nullable_analytical_measure_schema(),
                "time_scope_change": self._nullable_analytical_time_scope_schema(),
                "ranking_change": self._nullable_analytical_ranking_schema(),
                "notes": self._nullable_string_schema(),
            },
            "required": [
                "filters_to_add",
                "filters_to_replace",
                "grouping_changes",
                "measure_change",
                "time_scope_change",
                "ranking_change",
                "notes",
            ],
        }

    def _analytical_filter_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "field_key": {"type": "string"},
                "operator": {"type": "string"},
                "value": {
                    "anyOf": [
                        {"type": "string"},
                        {"type": "number"},
                        {"type": "boolean"},
                        {"type": "null"},
                        {
                            "type": "array",
                            "items": {
                                "anyOf": [
                                    {"type": "string"},
                                    {"type": "number"},
                                    {"type": "boolean"},
                                    {"type": "null"},
                                ]
                            },
                        },
                    ]
                },
                "source_field": self._nullable_string_schema(),
                "rationale": self._nullable_string_schema(),
            },
            "required": [
                "field_key",
                "operator",
                "value",
                "source_field",
                "rationale",
            ],
        }

    def _analytical_grouping_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "key": {"type": "string"},
                "label": self._nullable_string_schema(),
                "source_field": self._nullable_string_schema(),
                "granularity": self._nullable_string_schema(),
            },
            "required": ["key", "label", "source_field", "granularity"],
        }

    def _nullable_analytical_measure_schema(self) -> dict[str, Any]:
        return {
            "anyOf": [
                {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "name": {"type": "string"},
                        "aggregation": self._nullable_string_schema(),
                        "target": self._nullable_string_schema(),
                        "source_field": self._nullable_string_schema(),
                        "description": self._nullable_string_schema(),
                    },
                    "required": ["name", "aggregation", "target", "source_field", "description"],
                },
                {"type": "null"},
            ]
        }

    def _nullable_analytical_time_scope_schema(self) -> dict[str, Any]:
        return {
            "anyOf": [
                {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "field_key": self._nullable_string_schema(),
                        "source_field": self._nullable_string_schema(),
                        "year": {"type": ["integer", "null"]},
                        "start_year": {"type": ["integer", "null"]},
                        "end_year": {"type": ["integer", "null"]},
                        "description": self._nullable_string_schema(),
                    },
                    "required": ["field_key", "source_field", "year", "start_year", "end_year", "description"],
                },
                {"type": "null"},
            ]
        }

    def _nullable_analytical_ranking_schema(self) -> dict[str, Any]:
        return {
            "anyOf": [
                {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "sort_by": {"type": "string"},
                        "sort_columns": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "All sort columns in order, e.g. "
                                "[\"taxonomy_code_count DESC\", \"total_medicare_payment_amount DESC\", \"npi ASC\"]. "
                                "Use this instead of sort_by when the ranking has multiple sort keys."
                            ),
                        },
                        "direction": {
                            "anyOf": [
                                {"type": "string", "enum": ["asc", "desc"]},
                                {"type": "null"},
                            ]
                        },
                        "limit": {"type": ["integer", "null"]},
                        "rank": {"type": ["integer", "null"]},
                    },
                    "required": ["sort_by", "sort_columns", "direction", "limit", "rank"],
                },
                {"type": "null"},
            ]
        }
