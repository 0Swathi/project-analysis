from __future__ import annotations

import logging
from collections import defaultdict

try:
    import tiktoken
except ModuleNotFoundError:
    tiktoken = None

from backend.app.schemas.asset_selection import AssetSelectionPlan
from backend.app.schemas.responses import ContextReport
from backend.app.schemas.semantic_model import SemanticModel, SemanticTable


PROMPT_SUFFIX = (
    "\nReturn the final answer as structured output containing only the sql and explanation fields. "
    "Do not answer in plain text."
)
MODEL_CONTEXT_WINDOWS = {
    "gpt-5.4": 1_050_000,
    "gpt-5.4-2026-03-05": 1_050_000,
    "gpt-5.4-pro": 1_050_000,
}
# Conservative floor used for any model not listed in MODEL_CONTEXT_WINDOWS
# (e.g. gpt-4o, gpt-4o-mini, gpt-4-turbo all advertise at least 128k tokens).
# Without this fallback, get_context_window() returns None for unknown models
# and the "reject prompts that exceed the window" guard is silently skipped.
DEFAULT_CONTEXT_WINDOW = 128_000

logger = logging.getLogger(__name__)
NUMERIC_KEYWORDS = (
    "number",
    "total",
    "amount",
    "avg",
    "average",
    "sum",
    "rate",
    "percent",
    "pct",
    "qty",
    "quantity",
)
# "count" is intentionally excluded — it appears as a verb in field descriptions
# (e.g. "count distinct values from this field") but never indicates the data is numeric.


class SqlPromptBuilder:
    def build_system_prompt(
        self,
        semantic_model: SemanticModel,
        asset_selection_plan: AssetSelectionPlan | None = None,
        prior_sql: str | None = None,
        semantic_change_request: object | None = None,
    ) -> str:
        if prior_sql:
            return self._build_followup_system_prompt(
                semantic_model=semantic_model,
                asset_selection_plan=asset_selection_plan,
                prior_sql=prior_sql,
                semantic_change_request=semantic_change_request,
            )
        if _has_grounded_plan(asset_selection_plan):
            return self._build_grounded_system_prompt(
                semantic_model=semantic_model,
                asset_selection_plan=asset_selection_plan,
            )
        return self._build_unconstrained_system_prompt(semantic_model)

    def _build_unconstrained_system_prompt(self, semantic_model: SemanticModel) -> str:
        table_blocks: list[str] = []
        for table in semantic_model.tables:
            table_name = _display_table_name(table)
            description = table.description or ""
            field_lines: list[str] = []

            for field in table.fields:
                data_type = (field.data_type or "UNKNOWN").strip()
                kind = (field.kind or "UNKNOWN").strip()
                flags: list[str] = []
                if " " in field.name:
                    flags.append("needs-backtick-quoting")
                if (
                    (field.data_type or "").upper() == "STRING"
                    and (field.kind or "").lower() not in ("dimension", "identifier")
                    and _looks_numeric(field.name, field.description)
                ):
                    flags.append("likely-numeric-STRING")
                flag_suffix = f" [{', '.join(flags)}]" if flags else ""
                description_suffix = f": {field.description}" if field.description else ""
                field_lines.append(
                    f"  - {field.name} ({data_type}, {kind}){flag_suffix}{description_suffix}"
                )

            if not field_lines:
                field_lines.append("  - <no fields provided>")

            table_blocks.append(
                f"Table: {table_name}\n"
                f"Description: {description}\n"
                "Fields:\n"
                + "\n".join(field_lines)
            )

        schema_text = "\n\n".join(table_blocks) if table_blocks else "<no tables provided>"

        string_numeric_fields = self._infer_string_numeric_fields(semantic_model)
        spaced_column_tables = self._find_spaced_column_tables(semantic_model)
        join_candidates = self._find_join_candidates(semantic_model)

        data_quality_lines = [
            "- Real-world source data may contain NULLs, empty strings, and dirty values in any field.",
            "- String fields used in comparisons or filters may have inconsistent casing - always normalize with LOWER().",
        ]
        if string_numeric_fields:
            data_quality_lines.append(
                "- The following fields are typed STRING but likely contain numeric values; always use SAFE_CAST before arithmetic or aggregation: "
                + ", ".join(string_numeric_fields)
            )
        if spaced_column_tables:
            data_quality_lines.append(
                "- Column names with spaces exist in: "
                + ", ".join(spaced_column_tables)
                + ". Always wrap those column names in backticks."
            )

        join_section = ""
        if join_candidates:
            join_lines = "\n".join(f"  - {candidate}" for candidate in join_candidates)
            join_section = (
                "\n--- POTENTIAL JOIN KEYS (shared field names across tables) ---\n"
                f"{join_lines}\n"
            )

        data_quality_section = "\n".join(data_quality_lines)
        return f"""You are a careful analytics engineer and BigQuery SQL expert. Given a semantic data model and a natural language question, generate ONE correct, production-quality BigQuery SQL query.

SEMANTIC MODEL:
{schema_text}
{join_section}
--- DATA QUALITY NOTES ---
{data_quality_section}

--- CORE RULES ---
1.  Use only fully qualified table names from the schema.
2.  Use only fields that appear in the schema. Do NOT invent tables or columns.
3.  Do NOT use SELECT *. Return only the columns needed to answer the question.
4.  Use clear and meaningful table aliases throughout the query.

--- JOIN AND GRAIN RULES ---
5.  Join tables using the most reliable shared business keys supported by the schema (see POTENTIAL JOIN KEYS above when present).
6.  Preserve the business grain implied by the user query - avoid join fanout and duplicate counting.
7.  If a related table is only needed to filter the base table, prefer EXISTS or a deduplicated subquery rather than a direct join.
8.  Use COUNT(DISTINCT entity_key) for counting business entities when joins could duplicate rows.
9.  Prefer INNER JOIN unless the query clearly requires unmatched rows to be kept; use LEFT JOIN only then.

--- DATA QUALITY RULES ---
10. Fields flagged [likely-numeric-STRING]: always use SAFE_CAST(field AS FLOAT64) before arithmetic or aggregation. Never use plain CAST - it throws on dirty values.
11. Wrap SAFE_CAST results in COALESCE(..., 0) when summing, to treat NULLs as zero.
12. For ratios and percentages, use SAFE_DIVIDE(numerator, denominator) or protect the denominator with NULLIF(..., 0).
13. Treat blank strings as missing: use NULLIF(TRIM(column), '') when avoiding bad matches.
14. String filters: normalize with LOWER(TRIM(column)) = LOWER(TRIM(literal)). Prefer exact = or IN for codes, flags, and identifiers; use LIKE only for genuine partial-match intent.
15. Fields flagged [needs-backtick-quoting]: always wrap the column name in backticks in the SQL.
16. For DATE/TIMESTAMP fields, use EXTRACT(YEAR FROM field) for year filtering.

--- RESULT SHAPING RULES ---
17. If the user asks "how many", return an aggregated count - not detail rows.
18. Apply WHERE filters, GROUP BY, ORDER BY, and LIMIT only when they help answer the question.
19. Always include ORDER BY for ranked or grouped results; add a secondary sort on a unique key for deterministic output.
20. Add LIMIT 1000 to open-ended exploratory queries where no explicit row limit was requested.
21. Use CTEs (WITH clauses) to break down multi-step logic into readable steps.
22. When the time period is ambiguous, include the time field in SELECT and query all available periods.
23. Keep the query as simple as possible while still being correct and robust.
"""

    def _build_grounded_system_prompt(
        self,
        *,
        semantic_model: SemanticModel,
        asset_selection_plan: AssetSelectionPlan,
    ) -> str:
        table_blocks = self._build_table_blocks(semantic_model)
        schema_text = "\n\n".join(table_blocks) if table_blocks else "<no tables provided>"

        grounded_plan_lines = self._build_grounded_plan_lines(
            asset_selection_plan, tables=semantic_model.tables
        )
        grounded_plan_text = "\n".join(grounded_plan_lines)

        string_numeric_fields = self._infer_string_numeric_fields(semantic_model)
        spaced_column_tables = self._find_spaced_column_tables(semantic_model)
        relationship_lines = self._build_allowed_relationship_lines(
            semantic_model=semantic_model,
            asset_selection_plan=asset_selection_plan,
        )

        data_quality_lines = [
            "- Real-world source data may contain NULLs, empty strings, and dirty values in any field.",
            "- String fields used in comparisons or filters may have inconsistent casing - always normalize with LOWER().",
        ]
        if string_numeric_fields:
            data_quality_lines.append(
                "- The following fields are typed STRING but likely contain numeric values; always use SAFE_CAST before arithmetic or aggregation: "
                + ", ".join(string_numeric_fields)
            )
        if spaced_column_tables:
            data_quality_lines.append(
                "- Column names with spaces exist in: "
                + ", ".join(spaced_column_tables)
                + ". Always wrap those column names in backticks."
            )

        relationship_section = ""
        if relationship_lines:
            relationship_section = (
                "\n--- ALLOWED RELATIONSHIPS ---\n"
                + "\n".join(f"  - {relationship}" for relationship in relationship_lines)
                + "\n"
            )

        data_quality_section = "\n".join(data_quality_lines)
        return f"""You are a careful analytics engineer and BigQuery SQL expert. The data path is already selected for this turn. Generate ONE correct, production-quality BigQuery SQL query using ONLY the grounded data plan and narrowed semantic model below.

--- GROUNDED DATA PLAN ---
{grounded_plan_text}

NARROWED SEMANTIC MODEL:
{schema_text}
{relationship_section}
--- DATA QUALITY NOTES ---
{data_quality_section}

--- GROUNDED EXECUTION RULES ---
1.  Treat the grounded data plan as authoritative. Do NOT search for alternative base tables, joins, or grains.
2.  Use only fully qualified table names that appear in the narrowed semantic model and grounded data plan.
3.  Use only fields that appear in the narrowed semantic model. Do NOT invent tables, columns, or joins.
4.  If the grounded plan selects one table, stay in that table unless an allowed relationship explicitly requires another table.
5.  If the grounded plan lists allowed joins or relationships, use only those joins or a logically equivalent EXISTS / deduplicated-subquery form on the same join keys.
6.  Preserve the expected grain and entity logic from the grounded plan. Avoid join fanout and duplicate counting.
7.  If the question counts business entities and the grounded plan provides an entity key, use COUNT(DISTINCT entity_key) whenever joins could duplicate rows.
8.  Follow the grounded measure, ranking, and filter intent when present. Do not reinterpret the business question into a different metric or table family.

--- DATA QUALITY RULES ---
9.  Fields flagged [likely-numeric-STRING]: always use SAFE_CAST(field AS FLOAT64) before arithmetic or aggregation. Never use plain CAST - it throws on dirty values.
10. Wrap SAFE_CAST results in COALESCE(..., 0) when summing, to treat NULLs as zero.
11. For ratios and percentages, use SAFE_DIVIDE(numerator, denominator) or protect the denominator with NULLIF(..., 0).
12. Treat blank strings as missing: use NULLIF(TRIM(column), '') when avoiding bad matches.
13. String filters: normalize with LOWER(TRIM(column)) = LOWER(TRIM(literal)). Prefer exact = or IN for codes, flags, and identifiers; use LIKE only for genuine partial-match intent.
14. Fields flagged [needs-backtick-quoting]: always wrap the column name in backticks in the SQL.
15. For DATE/TIMESTAMP fields, use EXTRACT(YEAR FROM field) for year filtering.

--- RESULT SHAPING RULES ---
16. If the user asks "how many", return an aggregated count - not detail rows.
17. Apply WHERE filters, GROUP BY, ORDER BY, and LIMIT only when they help answer the question.
18. Always include ORDER BY for ranked or grouped results; add a secondary sort on a unique key for deterministic output.
19. Add LIMIT 1000 to open-ended exploratory queries where no explicit row limit was requested.
20. Use CTEs (WITH clauses) to break down multi-step logic into readable steps.
21. When the time period is ambiguous, include the time field in SELECT and query all available periods.
22. Keep the query as simple as possible while still being correct and robust.
"""

    def _build_followup_system_prompt(
        self,
        *,
        semantic_model: SemanticModel,
        asset_selection_plan: AssetSelectionPlan | None,
        prior_sql: str,
        semantic_change_request: object | None,
    ) -> str:
        table_blocks = self._build_table_blocks(semantic_model)
        schema_text = "\n\n".join(table_blocks) if table_blocks else "<no tables provided>"
        string_numeric_fields = self._infer_string_numeric_fields(semantic_model)
        spaced_column_tables = self._find_spaced_column_tables(semantic_model)

        data_quality_lines = [
            "- Real-world source data may contain NULLs, empty strings, and dirty values in any field.",
            "- String fields used in comparisons or filters may have inconsistent casing - always normalize with LOWER().",
        ]
        if string_numeric_fields:
            data_quality_lines.append(
                "- The following fields are typed STRING but likely contain numeric values; always use SAFE_CAST before arithmetic or aggregation: "
                + ", ".join(string_numeric_fields)
            )
        if spaced_column_tables:
            data_quality_lines.append(
                "- Column names with spaces exist in: "
                + ", ".join(spaced_column_tables)
                + ". Always wrap those column names in backticks."
            )
        data_quality_section = "\n".join(data_quality_lines)

        return f"""You are a careful analytics engineer and BigQuery SQL expert. A prior SQL query exists for this session. Apply ONLY the change described in the user question. Do not rewrite from scratch.

--- PRIOR SQL (anchor — preserve structure, aliases, normalization, and logic) ---
```sql
{prior_sql}
```

--- CHANGE TO APPLY ---
Read the user question below and apply exactly what it asks. Use the schema to determine the correct SQL implementation — do not guess field names or filter values.

NARROWED SEMANTIC MODEL (for field reference):
{schema_text}

--- DATA QUALITY NOTES ---
{data_quality_section}

--- EDITING RULES ---
1.  Start from the prior SQL above. Apply only the described change. Preserve everything else.
2.  Keep all existing CTE names, table aliases, JOIN logic, NPI normalization, and column selection unchanged unless the change explicitly requires modifying them.
3.  Do not add, remove, or restructure CTEs unless the change requires a new data path.
4.  Use only fully qualified table names from the narrowed semantic model.
5.  Do not invent tables, columns, or joins not present in the semantic model.
6.  Preserve all existing data quality patterns: SAFE_CAST, COALESCE, NULLIF, LOWER(TRIM(...)).
7.  Apply WHERE filters, GROUP BY, ORDER BY changes only as required by the described change.
8.  Keep the query as simple as possible — minimal diff from the prior SQL.
9.  If a filter is moved earlier into a CTE or subquery by this change, remove any duplicate application of that same filter at outer query levels. Do not apply the same condition twice.
10. If a ranking or ORDER BY change is described with explicit sort columns (e.g. "ORDER BY a DESC, b DESC"), use exactly those columns in that order. Do not add or drop sort columns beyond what is described.
"""

    def build_agent_system_prompt(
        self,
        semantic_model: SemanticModel,
        asset_selection_plan: AssetSelectionPlan | None = None,
        prior_sql: str | None = None,
        semantic_change_request: object | None = None,
    ) -> str:
        return self.build_system_prompt(
            semantic_model,
            asset_selection_plan,
            prior_sql=prior_sql,
            semantic_change_request=semantic_change_request,
        ) + PROMPT_SUFFIX

    def get_context_window(
        self,
        model_name: str,
        explicit_context_window: int | None = None,
    ) -> int | None:
        if explicit_context_window is not None:
            return explicit_context_window
        known_window = MODEL_CONTEXT_WINDOWS.get(model_name)
        if known_window is not None:
            return known_window
        logger.warning(
            "No known context window for model '%s'; falling back to a "
            "conservative default of %s tokens so the context-window guard "
            "stays active.",
            model_name,
            DEFAULT_CONTEXT_WINDOW,
        )
        return DEFAULT_CONTEXT_WINDOW

    def estimate_tokens(self, text: str, model_name: str) -> int:
        if tiktoken is None:
            return max(1, len(text) // 4)
        try:
            encoding = tiktoken.encoding_for_model(model_name)
        except KeyError:
            encoding = tiktoken.get_encoding("o200k_base")
        return len(encoding.encode(text))

    def build_context_report(
        self,
        *,
        semantic_model: SemanticModel,
        asset_selection_plan: AssetSelectionPlan | None = None,
        question: str,
        model_name: str,
        context_window: int | None,
    ) -> ContextReport:
        system_prompt = self.build_agent_system_prompt(semantic_model, asset_selection_plan)
        semantic_layer_tokens = self.estimate_tokens(
            self.build_system_prompt(semantic_model, asset_selection_plan),
            model_name,
        )
        system_prompt_tokens = self.estimate_tokens(system_prompt, model_name)
        question_tokens = self.estimate_tokens(question, model_name)
        estimated_input_tokens = system_prompt_tokens + question_tokens

        remaining_tokens: int | None = None
        semantic_layer_pct: float | None = None
        remaining_pct: float | None = None
        input_pct: float | None = None
        exceeds_window = False
        near_window = False

        if context_window is not None:
            remaining_tokens = context_window - estimated_input_tokens
            semantic_layer_pct = (semantic_layer_tokens / context_window) * 100
            input_pct = (estimated_input_tokens / context_window) * 100
            remaining_pct = (remaining_tokens / context_window) * 100
            exceeds_window = estimated_input_tokens > context_window
            near_window = estimated_input_tokens >= int(context_window * 0.8)

        return ContextReport(
            context_window=context_window,
            semantic_layer_tokens=semantic_layer_tokens,
            system_prompt_tokens=system_prompt_tokens,
            question_tokens=question_tokens,
            estimated_input_tokens=estimated_input_tokens,
            semantic_layer_pct=semantic_layer_pct,
            input_pct=input_pct,
            remaining_tokens=remaining_tokens,
            remaining_pct=remaining_pct,
            near_window=near_window,
            exceeds_window=exceeds_window,
        )

    def format_context_report(self, report: ContextReport) -> str:
        if report.context_window is None:
            return (
                "CONTEXT WINDOW REPORT:\n"
                f"- semantic layer tokens ingested: {report.semantic_layer_tokens}\n"
                f"- system prompt tokens: {report.system_prompt_tokens}\n"
                f"- user question tokens: {report.question_tokens}\n"
                f"- estimated input tokens: {report.estimated_input_tokens}\n"
                "- context window: unknown\n"
            )

        return (
            "CONTEXT WINDOW REPORT:\n"
            f"- context window: {report.context_window}\n"
            f"- semantic layer tokens ingested: {report.semantic_layer_tokens} ({report.semantic_layer_pct:.2f}% of window)\n"
            f"- system prompt tokens: {report.system_prompt_tokens}\n"
            f"- user question tokens: {report.question_tokens}\n"
            f"- estimated input tokens: {report.estimated_input_tokens} ({report.input_pct:.2f}% of window)\n"
            f"- estimated remaining tokens: {report.remaining_tokens} ({report.remaining_pct:.2f}% remaining)\n"
            f"- near max context window: {'yes' if report.near_window else 'no'}\n"
            f"- exceeds context window: {'yes' if report.exceeds_window else 'no'}"
        )

    def build_retry_input(
        self,
        *,
        original_user_input: str,
        failed_sql: str,
        violations: list[str],
        attempt: int,
        max_attempts: int,
    ) -> str:
        violation_lines = "\n".join(f"- {v}" for v in violations)
        return (
            f"{original_user_input}\n\n"
            f"--- VALIDATION FEEDBACK (attempt {attempt} of {max_attempts}) ---\n"
            "The SQL you generated was rejected by the plan validator. "
            "Fix ONLY the violations listed below. "
            "Preserve all CTEs, aliases, data quality patterns, and logic not cited as a violation.\n\n"
            f"Violations:\n{violation_lines}\n\n"
            f"SQL that was rejected:\n```sql\n{failed_sql}\n```"
        )

    def build_agent_input(
        self,
        question: str,
        report: ContextReport,
        asset_selection_plan: AssetSelectionPlan | None = None,
        prior_sql: str | None = None,
    ) -> str:
        if prior_sql:
            grounded_instruction = (
                "The prior SQL and change description in the system prompt are authoritative. "
                "Apply only the described change to the prior SQL. Do not rewrite from scratch."
            )
        elif _has_grounded_plan(asset_selection_plan):
            grounded_instruction = (
                "The grounded data plan in the system prompt is authoritative. "
                "Write the SQL inside that plan only. Do not search for alternative tables or joins."
            )
        else:
            grounded_instruction = (
                "Use the semantic layer already provided in the system prompt. "
                "The context report is informational and should help you stay concise if the remaining window is low."
            )
        return (
            f"{self.format_context_report(report)}\n\n"
            f"{grounded_instruction}\n\n"
            f"USER QUESTION:\n{question}"
        )

    def _build_table_blocks(self, semantic_model: SemanticModel) -> list[str]:
        table_blocks: list[str] = []
        for table in semantic_model.tables:
            table_name = _display_table_name(table)
            description = table.description or ""
            field_lines: list[str] = []

            for field in table.fields:
                data_type = (field.data_type or "UNKNOWN").strip()
                kind = (field.kind or "UNKNOWN").strip()
                flags: list[str] = []
                if " " in field.name:
                    flags.append("needs-backtick-quoting")
                if (
                    (field.data_type or "").upper() == "STRING"
                    and (field.kind or "").lower() not in ("dimension", "identifier")
                    and _looks_numeric(field.name, field.description)
                ):
                    flags.append("likely-numeric-STRING")
                flag_suffix = f" [{', '.join(flags)}]" if flags else ""
                description_suffix = f": {field.description}" if field.description else ""
                field_lines.append(
                    f"  - {field.name} ({data_type}, {kind}){flag_suffix}{description_suffix}"
                )

            if not field_lines:
                field_lines.append("  - <no fields provided>")

            table_blocks.append(
                f"Table: {table_name}\n"
                f"Description: {description}\n"
                "Fields:\n"
                + "\n".join(field_lines)
            )
        return table_blocks

    def _build_grounded_plan_lines(
        self,
        asset_selection_plan: AssetSelectionPlan,
        tables: list[SemanticTable] | None = None,
    ) -> list[str]:
        lines: list[str] = []
        if asset_selection_plan.base_table:
            base_ref = _resolve_qualified_name(asset_selection_plan.base_table, tables or [])
            lines.append(f"- Base table: {base_ref}")
        if asset_selection_plan.selected_tables:
            table_descriptions = []
            for selected_table in asset_selection_plan.selected_tables:
                reference = selected_table.qualified_name or selected_table.table_name
                role_suffix = f" [{selected_table.role}]" if selected_table.role else ""
                table_descriptions.append(f"{reference}{role_suffix}")
            lines.append(f"- Allowed tables: {', '.join(table_descriptions)}")
        if asset_selection_plan.selected_joins:
            join_descriptions = []
            for selected_join in asset_selection_plan.selected_joins:
                join_type = f" ({selected_join.join_type})" if selected_join.join_type else ""
                join_descriptions.append(
                    f"{selected_join.left_table_name}.{selected_join.left_field_name} = "
                    f"{selected_join.right_table_name}.{selected_join.right_field_name}{join_type}"
                )
            lines.append(f"- Allowed joins: {'; '.join(join_descriptions)}")
        if asset_selection_plan.entity:
            lines.append(f"- Entity: {asset_selection_plan.entity}")
        if asset_selection_plan.entity_key_field:
            lines.append(f"- Entity key field: {asset_selection_plan.entity_key_field}")
        if asset_selection_plan.grain_description:
            lines.append(f"- Expected grain: {asset_selection_plan.grain_description}")
        if asset_selection_plan.business_intent:
            lines.append(f"- Business intent: {asset_selection_plan.business_intent}")
        if asset_selection_plan.measure_intent:
            lines.append(f"- Measure intent: {asset_selection_plan.measure_intent}")
        if asset_selection_plan.ranking_intent:
            lines.append(f"- Ranking intent: {asset_selection_plan.ranking_intent}")
        if asset_selection_plan.filters_summary:
            lines.append(f"- Filters already understood: {'; '.join(asset_selection_plan.filters_summary)}")
        if asset_selection_plan.rationale:
            lines.append(f"- Selection rationale: {asset_selection_plan.rationale}")
        return lines or ["- No grounded data plan details were provided."]

    def _build_allowed_relationship_lines(
        self,
        *,
        semantic_model: SemanticModel,
        asset_selection_plan: AssetSelectionPlan,
    ) -> list[str]:
        if semantic_model.relationships:
            relationship_lines = []
            for relationship in semantic_model.relationships:
                relationship_type = (
                    f" ({relationship.relationship_type})"
                    if relationship.relationship_type
                    else ""
                )
                relationship_lines.append(
                    f"{relationship.left.table_name}.{relationship.left.field_name} = "
                    f"{relationship.right.table_name}.{relationship.right.field_name}{relationship_type}"
                )
            return relationship_lines

        relationship_lines = []
        for selected_join in asset_selection_plan.selected_joins:
            join_type = f" ({selected_join.join_type})" if selected_join.join_type else ""
            relationship_lines.append(
                f"{selected_join.left_table_name}.{selected_join.left_field_name} = "
                f"{selected_join.right_table_name}.{selected_join.right_field_name}{join_type}"
            )
        return relationship_lines

    def _infer_string_numeric_fields(self, semantic_model: SemanticModel) -> list[str]:
        hits: list[str] = []
        for table in semantic_model.tables:
            table_name = _display_table_name(table)
            for field in table.fields:
                if (field.data_type or "").upper() != "STRING":
                    continue
                if _looks_numeric(field.name, field.description):
                    hits.append(f"{table_name}.{field.name}")
        return hits

    def _find_spaced_column_tables(self, semantic_model: SemanticModel) -> list[str]:
        tables: list[str] = []
        for table in semantic_model.tables:
            if any(" " in field.name for field in table.fields):
                tables.append(_display_table_name(table))
        return tables

    def _find_join_candidates(self, semantic_model: SemanticModel) -> list[str]:
        name_to_tables: dict[str, set[str]] = defaultdict(set)
        for table in semantic_model.tables:
            table_name = _display_table_name(table)
            for field in table.fields:
                field_name = field.name.strip().upper()
                if field_name and (field.kind or "").lower() != "measure":
                    name_to_tables[field_name].add(table_name)

        candidates: list[str] = []
        for field_name, table_names in sorted(name_to_tables.items()):
            if len(table_names) >= 2:
                candidates.append(" = ".join(f"{table}.{field_name}" for table in sorted(table_names)))
        return candidates


def _display_table_name(table: SemanticTable) -> str:
    return (table.qualified_name or table.name or "<unknown>").strip()


def _resolve_qualified_name(name: str, tables: list[SemanticTable]) -> str:
    """Return the qualified name for *name* by looking it up in *tables*.

    Matches on exact qualified_name first, then on short name.  Falls back to
    *name* unchanged so callers are always safe to use the result directly.
    """
    for table in tables:
        if table.qualified_name and table.qualified_name == name:
            return table.qualified_name
        if table.name == name:
            return table.qualified_name or table.name
    return name


def _looks_numeric(name: str, description: str | None) -> bool:
    haystacks = [name.lower(), (description or "").lower()]
    return any(keyword in text for text in haystacks for keyword in NUMERIC_KEYWORDS)


def _has_grounded_plan(asset_selection_plan: AssetSelectionPlan | None) -> bool:
    if asset_selection_plan is None:
        return False
    return any(
        [
            asset_selection_plan.base_table,
            asset_selection_plan.selected_tables,
            asset_selection_plan.selected_joins,
            asset_selection_plan.entity,
            asset_selection_plan.entity_key_field,
            asset_selection_plan.grain_description,
            asset_selection_plan.business_intent,
            asset_selection_plan.measure_intent,
            asset_selection_plan.ranking_intent,
            asset_selection_plan.filters_summary,
            asset_selection_plan.rationale,
        ]
    )
