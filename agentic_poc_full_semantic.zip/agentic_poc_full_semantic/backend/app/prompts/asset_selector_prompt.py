from __future__ import annotations

import json
from typing import Any

from backend.app.memory.state import ContextSnapshot, SessionMemory


class AssetSelectorPromptBuilder:
    def build_system_prompt(self) -> str:
        return (
            "You are an analytical asset selector for a SQL generation system. "
            "Your job is to choose the correct data assets for the current analytical turn "
            "before SQL is generated.\n\n"
            "You must decide:\n"
            "- which table is the base table\n"
            "- which additional tables are needed\n"
            "- which joins are required and why\n"
            "- what the business entity is\n"
            "- what the entity key field is\n"
            "- what grain the final analysis should preserve\n"
            "- whether clarification is required before SQL generation\n\n"

            "=== STEP 1: SOURCE-OF-TRUTH CHECK (MANDATORY — execute before anything else) ===\n"
            "Read the source_of_truth_for list on EVERY table in the semantic model.\n"
            "Does the user question ask about a concept that appears in any table's source_of_truth_for?\n"
            "  YES → That table is the base_table. This decision is FINAL and cannot be overridden by general reasoning.\n"
            "        Now check: can the question be answered using only fields that exist in that table?\n"
            "          YES → Select ONLY that table. Zero joins. You are done with table selection.\n"
            "          NO  → Add joins strictly for fields the question explicitly requires from another table.\n"
            "               Do not add tables speculatively or because they are 'related'.\n"
            "  NO  → Proceed to Step 2.\n\n"

            "Concrete examples of Step 1:\n"
            "  Q: 'how many specialties are there?' "
            "→ 'CMS specialty counts' in CMS_Specialty_Taxonomy_Crosswalk.source_of_truth_for "
            "→ base = CMS_Specialty_Taxonomy_Crosswalk, no joins, "
            "COUNT(DISTINCT CMS_SPECIALTY_CODE). NEVER pull in npidata here.\n"
            "  Q: 'how many providers are there?' "
            "→ 'provider counts' in npidata.source_of_truth_for "
            "→ base = npidata, no joins, COUNT(DISTINCT npi).\n"
            "  Q: 'what was total Medicare reimbursement last year?' "
            "→ 'Medicare reimbursement' in MedicareBillingData.source_of_truth_for "
            "→ base = MedicareBillingData, no joins unless provider name is also needed.\n"
            "  Q: 'which specialties have the most Medicare billing?' "
            "→ two concepts: billing (MedicareBillingData) AND specialty label (CMS_Specialty_Taxonomy_Crosswalk) "
            "→ base = MedicareBillingData, join CMS_Specialty_Taxonomy_Crosswalk for the label.\n\n"

            "Also read selection_hints on every table. These are binding directives, not suggestions.\n\n"

            "=== STEP 2: MINIMUM TABLE SELECTION (only if Step 1 found no source_of_truth match) ===\n"
            "1. Start with zero tables. Add each table only when it contributes a field, metric, or dimension "
            "the question explicitly needs that cannot be found in an already-selected table. "
            "Never add a table 'just in case' or because it is related to the topic.\n"
            "2. Only add a join table when: (a) the required field exists only in that table AND "
            "(b) no equivalent field exists in any already-selected table.\n"
            "3. Do not invent tables, fields, joins, or business meaning not present in the semantic model.\n"
            "4. Only require clarification if multiple incompatible data paths exist AND no field description, "
            "grain hint, or session context resolves the ambiguity. Prefer the most common analytical interpretation "
            "(e.g. derived totals via Avg x Count over raw averages) rather than asking.\n"
            "5. Use active session context only when it clearly applies to the current analytical intent.\n"
            "6. If a snapshot context fits better than the active context, prefer the snapshot context.\n"
            "7. Do not generate SQL.\n"
            "8. Return only structured output matching the provided schema."
        )

    def build_user_prompt(
        self,
        *,
        message: str,
        resolved_question: str | None,
        session: SessionMemory,
        semantic_model: dict[str, Any],
        semantic_model_key: str | None = None,
        turn_type: str | None = None,
        operation_type: str | None = None,
        target_snapshot: ContextSnapshot | None = None,
    ) -> str:
        payload = {
            "current_message": message,
            "resolved_question": resolved_question,
            "turn_type": turn_type,
            "operation_type": operation_type,
            "semantic_model": self._semantic_model_payload(
                semantic_model,
                semantic_model_key=semantic_model_key,
            ),
            "active_context": (
                session.active_context.model_dump(mode="json")
                if session.active_context is not None
                else None
            ),
            "target_snapshot": (
                target_snapshot.model_dump(mode="json")
                if target_snapshot is not None
                else None
            ),
            "recent_messages": [
                message_item.model_dump(mode="json")
                for message_item in session.messages[-4:]
            ],
            "rolling_summary": session.rolling_summary,
            "turn_index": session.turn_index,
        }
        return (
            "Select the best analytical assets for the current turn using the context below.\n\n"
            f"{json.dumps(payload, indent=2, sort_keys=True)}"
        )

    def build_response_schema(self) -> dict[str, Any]:
        return {
            "name": "asset_selection_plan",
            "schema": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "base_table": self._nullable_string_schema(),
                    "selected_tables": {
                        "type": "array",
                        "items": self._selected_table_schema(),
                    },
                    "selected_joins": {
                        "type": "array",
                        "items": self._selected_join_schema(),
                    },
                    "entity": self._nullable_string_schema(),
                    "entity_key_field": self._nullable_string_schema(),
                    "grain_description": self._nullable_string_schema(),
                    "business_intent": self._nullable_string_schema(),
                    "measure_intent": self._nullable_string_schema(),
                    "filters_summary": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "ranking_intent": self._nullable_string_schema(),
                    "clarification": {
                        "anyOf": [
                            {
                                "type": "object",
                                "additionalProperties": False,
                                "properties": {
                                    "required": {"type": "boolean"},
                                    "question": self._nullable_string_schema(),
                                    "reason": self._nullable_string_schema(),
                                },
                                "required": ["required", "question", "reason"],
                            },
                            {"type": "null"},
                        ]
                    },
                    "rationale": self._nullable_string_schema(),
                },
                "required": [
                    "base_table",
                    "selected_tables",
                    "selected_joins",
                    "entity",
                    "entity_key_field",
                    "grain_description",
                    "business_intent",
                    "measure_intent",
                    "filters_summary",
                    "ranking_intent",
                    "clarification",
                    "rationale",
                ],
            },
        }

    def _semantic_model_payload(
        self,
        semantic_model: dict[str, Any],
        *,
        semantic_model_key: str | None,
    ) -> dict[str, Any]:
        tables_payload = semantic_model.get("tables")
        relationships_payload = semantic_model.get("relationships")

        tables: list[dict[str, Any]] = []
        if isinstance(tables_payload, list):
            for table_payload in tables_payload:
                if not isinstance(table_payload, dict):
                    continue
                fields_payload = table_payload.get("fields")
                fields: list[dict[str, Any]] = []
                if isinstance(fields_payload, list):
                    for field_payload in fields_payload:
                        if not isinstance(field_payload, dict):
                            continue
                        fields.append(
                            {
                                "name": field_payload.get("name"),
                                "description": field_payload.get("description"),
                                "data_type": field_payload.get("data_type"),
                                "kind": field_payload.get("kind"),
                                "default_aggregation": field_payload.get(
                                    "default_aggregation"
                                ),
                                "selection_hints": field_payload.get(
                                    "selection_hints", []
                                ),
                            }
                        )
                tables.append(
                    {
                        "table_name": table_payload.get("table_name")
                        or table_payload.get("name"),
                        "qualified_name": table_payload.get("qualified_name"),
                        "description": table_payload.get("table_description")
                        or table_payload.get("description"),
                        "canonical_entity": table_payload.get("canonical_entity"),
                        "preferred_entity_key": table_payload.get(
                            "preferred_entity_key"
                        ),
                        "grain_description": table_payload.get("grain_description"),
                        "source_of_truth_for": table_payload.get(
                            "source_of_truth_for", []
                        ),
                        "selection_hints": table_payload.get("selection_hints", []),
                        "fields": fields,
                    }
                )

        relationships: list[dict[str, Any]] = []
        if isinstance(relationships_payload, list):
            for relationship_payload in relationships_payload:
                if not isinstance(relationship_payload, dict):
                    continue
                relationships.append(
                    {
                        "left": relationship_payload.get("left"),
                        "right": relationship_payload.get("right"),
                        "relationship_type": relationship_payload.get(
                            "relationship_type"
                        ),
                        "description": relationship_payload.get("description"),
                        "join_hint": relationship_payload.get("join_hint"),
                        "selection_hints": relationship_payload.get(
                            "selection_hints", []
                        ),
                    }
                )

        return {
            "semantic_model_key": semantic_model_key,
            "dataset_name": semantic_model.get("dataset_name")
            or semantic_model.get("name"),
            "dataset_description": semantic_model.get("dataset_description")
            or semantic_model.get("description"),
            "domain": semantic_model.get("domain"),
            "selection_hints": semantic_model.get("selection_hints", []),
            "tables": tables,
            "relationships": relationships,
        }

    def _nullable_string_schema(self) -> dict[str, Any]:
        return {"type": ["string", "null"]}

    def _selected_table_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "table_name": {"type": "string"},
                "qualified_name": self._nullable_string_schema(),
                "role": {
                    "type": ["string", "null"],
                    "enum": [
                        "base",
                        "join",
                        "filter_only",
                        "dimension",
                        "measure_source",
                        "ranking_source",
                        None,
                    ],
                },
                "required_fields": {
                    "type": "array",
                    "items": {"type": "string"},
                },
                "rationale": self._nullable_string_schema(),
            },
            "required": [
                "table_name",
                "qualified_name",
                "role",
                "required_fields",
                "rationale",
            ],
        }

    def _selected_join_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "left_table_name": {"type": "string"},
                "left_field_name": {"type": "string"},
                "right_table_name": {"type": "string"},
                "right_field_name": {"type": "string"},
                "join_type": {
                    "type": ["string", "null"],
                    "enum": ["inner", "left", "semi", "anti", None],
                },
                "relationship_type": self._nullable_string_schema(),
                "rationale": self._nullable_string_schema(),
            },
            "required": [
                "left_table_name",
                "left_field_name",
                "right_table_name",
                "right_field_name",
                "join_type",
                "relationship_type",
                "rationale",
            ],
        }
