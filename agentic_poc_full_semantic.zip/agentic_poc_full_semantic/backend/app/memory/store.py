from __future__ import annotations

import logging
import time
from threading import RLock

from backend.app.memory.state import SessionMemory

_logger = logging.getLogger(__name__)

# Default TTL: 2 hours of inactivity before a session is evicted.
DEFAULT_SESSION_TTL_SECONDS: float = 7200.0


class InMemorySessionStore:
    def __init__(
        self,
        *,
        max_recent_messages: int = 20,
        max_snapshots: int = 10,
        session_ttl_seconds: float = DEFAULT_SESSION_TTL_SECONDS,
    ) -> None:
        if max_recent_messages < 1:
            raise ValueError("max_recent_messages must be at least 1.")
        if max_snapshots < 1:
            raise ValueError("max_snapshots must be at least 1.")
        if session_ttl_seconds <= 0:
            raise ValueError("session_ttl_seconds must be positive.")

        self.max_recent_messages = max_recent_messages
        self.max_snapshots = max_snapshots
        self.session_ttl_seconds = session_ttl_seconds
        self._sessions: dict[str, SessionMemory] = {}
        self._last_accessed: dict[str, float] = {}
        self._lock = RLock()

    def get(self, session_id: str) -> SessionMemory | None:
        _validate_session_id(session_id)
        with self._lock:
            if self._is_expired(session_id):
                self._evict(session_id)
                return None
            session = self._sessions.get(session_id)
            if session is not None:
                self._last_accessed[session_id] = time.monotonic()
            return session.model_copy(deep=True) if session is not None else None

    def save(self, session: SessionMemory) -> SessionMemory:
        bounded_session = _bounded_session_copy(
            session,
            max_recent_messages=self.max_recent_messages,
            max_snapshots=self.max_snapshots,
        )
        with self._lock:
            self._sessions[bounded_session.session_id] = bounded_session
            self._last_accessed[bounded_session.session_id] = time.monotonic()
            return bounded_session.model_copy(deep=True)

    def clear(self, session_id: str) -> bool:
        _validate_session_id(session_id)
        with self._lock:
            existed = session_id in self._sessions
            self._evict(session_id)
            return existed

    def clear_expired(self) -> int:
        """Evict all sessions whose TTL has elapsed. Returns the count evicted."""
        with self._lock:
            expired = [sid for sid in list(self._sessions) if self._is_expired(sid)]
            for sid in expired:
                self._evict(sid)
            return len(expired)

    @property
    def active_session_count(self) -> int:
        with self._lock:
            return len(self._sessions)

    # ------------------------------------------------------------------ internal

    def _is_expired(self, session_id: str) -> bool:
        last = self._last_accessed.get(session_id)
        if last is None:
            return False
        return (time.monotonic() - last) > self.session_ttl_seconds

    def _evict(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)
        self._last_accessed.pop(session_id, None)


def _bounded_session_copy(
    session: SessionMemory,
    *,
    max_recent_messages: int,
    max_snapshots: int,
) -> SessionMemory:
    bounded_session = session.model_copy(deep=True)
    bounded_session.messages = bounded_session.messages[-max_recent_messages:]

    if len(session.snapshots) > max_snapshots:
        evicted = session.snapshots[: len(session.snapshots) - max_snapshots]
        _logger.warning(
            "Session '%s': snapshot cap (%d) reached — evicting %d oldest snapshot(s): %s. "
            "Evicted topics will no longer be reachable via historical_callback.",
            session.session_id,
            max_snapshots,
            len(evicted),
            [s.snapshot_id for s in evicted],
        )
    bounded_session.snapshots = bounded_session.snapshots[-max_snapshots:]
    return bounded_session


def _validate_session_id(session_id: str) -> None:
    if not session_id.strip():
        raise ValueError("session_id cannot be blank.")
