from __future__ import annotations

import hashlib
import json
import logging
from collections.abc import Generator
from typing import Any, Protocol, TypedDict

_logger = logging.getLogger(__name__)

from langgraph.graph import END, START, StateGraph

from backend.app.memory.grounder import ContextGrounder
from backend.app.memory.memory_contracts import ContextPacket
from backend.app.memory.reasoner import MemoryReasoner
from backend.app.memory.state import (
    ActiveContext,
    AnalyticalContext,
    AnalyticalCohort,
    AnalyticalFilter,
    AnalyticalGrouping,
    AnalyticalMeasure,
    ContextSnapshot,
    ConversationMessage,
    GraphTurnState,
    ReasonerDecision,
    ResolvedAssets,
    SessionMemory,
    StatePatch,
)
from backend.app.memory.store import InMemorySessionStore
from backend.app.schemas.asset_selection import AssetSelectionPlan
from backend.app.schemas.responses import GenerateSqlResponse
from backend.app.schemas.semantic_model import SemanticModel
from backend.app.services.asset_selector_service import AssetSelectorService
from backend.app.services.semantic_projection_service import SemanticProjectionService


class SqlExecutor(Protocol):
    def execute(
        self,
        *,
        question: str,
        semantic_model: dict[str, Any],
        asset_selection_plan: AssetSelectionPlan | None = None,
        prior_sql: str | None = None,
        semantic_change_request: Any | None = None,
        model: str | None = None,
        debug: bool = False,
    ) -> GenerateSqlResponse:
        ...


class _NoopAssetSelector(AssetSelectorService):
    def select_assets(
        self,
        *,
        message: str,
        resolved_question: str | None,
        session: SessionMemory,
        semantic_model: dict[str, Any],
        semantic_model_key: str | None = None,
        turn_type: str | None = None,
        operation_type: str | None = None,
        target_snapshot: ContextSnapshot | None = None,
        model: str | None = None,
    ) -> AssetSelectionPlan:
        return AssetSelectionPlan()


class MemoryGraphState(TypedDict, total=False):
    session_id: str
    incoming_message: str
    semantic_model: dict[str, Any]
    semantic_model_key: str | None
    semantic_model_fingerprint: str | None
    semantic_model_changed: bool
    model: str | None
    memory_model: str | None
    debug: bool
    session: SessionMemory
    candidate_snapshots: list[ContextSnapshot]
    reasoner_output: ReasonerDecision
    resolved_question: str | None
    turn_type: str | None
    clarification_required: bool
    clarification_question: str | None
    asset_selection_plan: AssetSelectionPlan | None
    projected_semantic_model: dict[str, Any] | None
    sql_result: GenerateSqlResponse | None
    assistant_message: str | None


class MemoryWrapperGraph:
    def __init__(
        self,
        *,
        store: InMemorySessionStore,
        reasoner: MemoryReasoner,
        sql_executor: SqlExecutor,
        asset_selector: AssetSelectorService | None = None,
        projection_service: SemanticProjectionService | None = None,
        grounder: ContextGrounder | None = None,
        max_candidate_snapshots: int = 3,
    ) -> None:
        self.store = store
        self.reasoner = reasoner
        self.sql_executor = sql_executor
        self.asset_selector = asset_selector or _NoopAssetSelector()
        self.projection_service = projection_service or SemanticProjectionService()
        self.grounder = grounder or ContextGrounder()
        self.max_candidate_snapshots = max_candidate_snapshots
        self._graph = self._build_graph()

    def invoke(self, state: GraphTurnState) -> GraphTurnState:
        result = self._graph.invoke(state.model_dump(mode="python"))
        allowed_fields = set(GraphTurnState.model_fields)
        filtered_result = {key: value for key, value in result.items() if key in allowed_fields}
        return GraphTurnState.model_validate(filtered_result)

    def stream_events(self, state: GraphTurnState) -> Generator[str, None, None]:
        def _sse(payload: dict) -> str:
            return f"data: {json.dumps(payload)}\n\n"

        yield _sse({
            "type": "progress",
            "stage": "reason_turn",
            "message": "Analyzing your question...",
        })

        try:
            final_state: dict = {}
            for chunk in self._graph.stream(state.model_dump(mode="python")):
                for node_name, node_output in chunk.items():
                    if isinstance(node_output, dict):
                        final_state.update(node_output)
                    if node_name == "reason_turn":
                        yield _sse(self._build_reason_turn_progress(final_state))
                    elif node_name == "select_assets":
                        yield _sse(self._build_select_assets_progress(final_state))

            allowed_fields = set(GraphTurnState.model_fields)
            graph_result = GraphTurnState.model_validate(
                {k: v for k, v in final_state.items() if k in allowed_fields}
            )
            yield _sse({"type": "result", "payload": graph_result.model_dump(mode="json")})
        except Exception as exc:
            _logger.error("stream_events failed: %s", exc, exc_info=True)
            yield _sse({"type": "error", "message": str(exc)})

    def _build_reason_turn_progress(self, state: dict) -> dict:
        decision = state.get("reasoner_output")
        turn_type = state.get("turn_type")
        resolved_question = state.get("resolved_question")

        event: dict = {
            "type": "progress",
            "stage": "select_assets",
            "message": "Selecting data assets...",
        }
        if turn_type:
            event["turn_type"] = turn_type
        if resolved_question:
            event["resolved_question"] = resolved_question
        if decision is not None:
            use_active = getattr(decision, "use_active_context", None)
            target_snapshot = getattr(decision, "target_snapshot_id", None)
            if use_active:
                event["context_mode"] = "active"
            elif target_snapshot:
                event["context_mode"] = f"snapshot:{target_snapshot}"
            else:
                event["context_mode"] = "fresh"
        return event

    def _build_select_assets_progress(self, state: dict) -> dict:
        plan = state.get("asset_selection_plan")
        event: dict = {
            "type": "progress",
            "stage": "invoke_sql_generation",
            "message": "Generating SQL...",
        }
        if plan is not None:
            base_table = getattr(plan, "base_table", None)
            selected_tables = getattr(plan, "selected_tables", [])
            selected_joins = getattr(plan, "selected_joins", [])
            rationale = getattr(plan, "rationale", None)
            if base_table:
                event["base_table"] = base_table
            if selected_tables:
                event["tables"] = [
                    getattr(t, "qualified_name", None) or getattr(t, "table_name", str(t))
                    for t in selected_tables
                ]
            if selected_joins:
                event["joins"] = [
                    f"{getattr(j, 'left_table_name', '')}.{getattr(j, 'left_field_name', '')} "
                    f"= {getattr(j, 'right_table_name', '')}.{getattr(j, 'right_field_name', '')}"
                    for j in selected_joins
                ]
            if rationale:
                event["rationale"] = rationale
        return event

    def _build_graph(self):
        builder = StateGraph(MemoryGraphState)
        builder.add_node("load_session", self._load_session)
        builder.add_node("select_snapshot_candidates", self._select_snapshot_candidates)
        builder.add_node("reason_turn", self._reason_turn)
        builder.add_node("select_assets", self._select_assets)
        builder.add_node("project_semantic_model", self._project_semantic_model)
        builder.add_node("respond_with_clarification", self._respond_with_clarification)
        builder.add_node("invoke_sql_generation", self._invoke_sql_generation)
        builder.add_node("update_session_memory", self._update_session_memory)
        builder.add_node("build_response", self._build_response)

        builder.add_edge(START, "load_session")
        builder.add_edge("load_session", "select_snapshot_candidates")
        builder.add_edge("select_snapshot_candidates", "reason_turn")
        builder.add_conditional_edges(
            "reason_turn",
            self._route_after_reasoner,
            {
                "clarification": "respond_with_clarification",
                "asset_selection": "select_assets",
            },
        )
        builder.add_conditional_edges(
            "select_assets",
            self._route_after_asset_selection,
            {
                "clarification": "respond_with_clarification",
                "project": "project_semantic_model",
            },
        )
        builder.add_edge("project_semantic_model", "invoke_sql_generation")
        builder.add_edge("respond_with_clarification", "update_session_memory")
        builder.add_edge("invoke_sql_generation", "update_session_memory")
        builder.add_edge("update_session_memory", "build_response")
        builder.add_edge("build_response", END)
        return builder.compile()

    def _load_session(self, state: MemoryGraphState) -> MemoryGraphState:
        session_id = state["session_id"]
        semantic_model_key = state.get("semantic_model_key")
        # Reuse the fingerprint pre-computed by the caller if present; compute lazily otherwise.
        semantic_model_fingerprint = (
            state.get("semantic_model_fingerprint")
            or fingerprint_semantic_model(state["semantic_model"])
        )
        session = self.store.get(session_id) or SessionMemory(session_id=session_id)

        semantic_model_changed = (
            session.semantic_model_fingerprint is not None
            and session.semantic_model_fingerprint != semantic_model_fingerprint
        ) or (
            session.semantic_model_key is not None
            and semantic_model_key is not None
            and session.semantic_model_key != semantic_model_key
        )

        if semantic_model_changed and session.active_context is not None:
            snapshot = _snapshot_from_active_context(
                session.active_context,
                created_at_turn=session.turn_index,
                snapshot_index=len(session.snapshots) + 1,
            )
            if snapshot is not None:
                session.snapshots.append(snapshot)
            session.active_context = None

        session.semantic_model_key = semantic_model_key
        session.semantic_model_fingerprint = semantic_model_fingerprint

        return {
            "session": session,
            "semantic_model_fingerprint": semantic_model_fingerprint,
            "semantic_model_changed": semantic_model_changed,
        }

    def _select_snapshot_candidates(self, state: MemoryGraphState) -> MemoryGraphState:
        session = state["session"]
        if self.max_candidate_snapshots <= 0 or not session.snapshots:
            return {"candidate_snapshots": []}

        snapshots = session.snapshots
        message = state.get("incoming_message", "")

        if len(snapshots) <= self.max_candidate_snapshots:
            # All snapshots fit — still deduplicate by snapshot_id.
            seen_ids: set[str] = set()
            deduped = [s for s in snapshots if not (s.snapshot_id in seen_ids or seen_ids.add(s.snapshot_id))]
            return {"candidate_snapshots": deduped}

        # Always include the oldest snapshot (anchor for full rewind).
        anchor = snapshots[0]

        # Score all non-anchor snapshots by keyword overlap with the incoming
        # message, breaking ties by recency (higher index = more recent = higher).
        query_tokens = _tokenize(message)
        scored: list[tuple[float, int, ContextSnapshot]] = []
        for idx, snap in enumerate(snapshots[1:], start=1):
            snap_tokens = _snapshot_tokens(snap)
            overlap = len(query_tokens & snap_tokens) if query_tokens else 0
            scored.append((overlap, idx, snap))

        # Sort by overlap desc, then by index desc (recency) as tiebreaker.
        scored.sort(key=lambda t: (t[0], t[1]), reverse=True)

        seen: set[str] = {anchor.snapshot_id}
        candidates: list[ContextSnapshot] = [anchor]
        for _, _, snap in scored:
            if len(candidates) >= self.max_candidate_snapshots:
                break
            if snap.snapshot_id not in seen:
                seen.add(snap.snapshot_id)
                candidates.append(snap)

        return {"candidate_snapshots": candidates}

    def _reason_turn(self, state: MemoryGraphState) -> MemoryGraphState:
        session = state["session"]
        try:
            decision = self.reasoner.reason(
                message=state["incoming_message"],
                session=session,
                candidate_snapshots=state.get("candidate_snapshots", []),
                semantic_model=state["semantic_model"],
                semantic_model_key=state.get("semantic_model_key"),
                model=state.get("memory_model"),
            )
        except Exception as exc:
            _logger.warning(
                "Memory reasoner failed (%s); falling back to fresh turn with full schema.",
                exc,
                exc_info=True,
            )
            decision = ReasonerDecision(
                turn_type="fresh",
                resolved_question=state["incoming_message"],
                use_active_context=False,
            )
        return {
            "reasoner_output": decision,
            "resolved_question": decision.resolved_question,
            "turn_type": decision.turn_type,
            "clarification_required": decision.clarification_required,
            "clarification_question": decision.clarification_question,
        }

    def _route_after_reasoner(self, state: MemoryGraphState) -> str:
        return "clarification" if state.get("clarification_required") else "asset_selection"

    def _route_after_asset_selection(self, state: MemoryGraphState) -> str:
        return "clarification" if state.get("clarification_required") else "project"

    def _select_assets(self, state: MemoryGraphState) -> MemoryGraphState:
        session = state["session"]
        decision = state["reasoner_output"]
        target_snapshot = _find_snapshot(session, decision.target_snapshot_id)
        try:
            selection_plan = self.asset_selector.select_assets(
                message=state["incoming_message"],
                resolved_question=state.get("resolved_question"),
                session=session,
                semantic_model=state["semantic_model"],
                semantic_model_key=state.get("semantic_model_key"),
                turn_type=decision.turn_type,
                operation_type=decision.operation_type or _default_operation_type(decision.turn_type),
                target_snapshot=target_snapshot,
                model=state.get("memory_model"),
            )
        except Exception as exc:
            _logger.warning(
                "Asset selector failed (%s); falling back to full-schema generation.",
                exc,
                exc_info=True,
            )
            selection_plan = AssetSelectionPlan()
        clarification = selection_plan.clarification
        if clarification is not None and clarification.required:
            clarification_question = (
                clarification.question
                or "I need clarification before I can choose the correct data sources."
            )
            return {
                "asset_selection_plan": selection_plan,
                "clarification_required": True,
                "clarification_question": clarification_question,
                "assistant_message": clarification_question,
                "sql_result": None,
            }
        return {
            "asset_selection_plan": selection_plan,
            "clarification_required": False,
            "clarification_question": None,
        }

    def _project_semantic_model(self, state: MemoryGraphState) -> MemoryGraphState:
        selection_plan = state.get("asset_selection_plan")
        if selection_plan is None or not _asset_selection_plan_has_value(selection_plan):
            return {"projected_semantic_model": state["semantic_model"]}

        projected_result = self.projection_service.project(
            semantic_model=SemanticModel.model_validate(state["semantic_model"]),
            asset_selection_plan=selection_plan,
        )
        return {
            "projected_semantic_model": projected_result.semantic_model.model_dump(
                mode="python",
                exclude_none=True,
            )
        }

    def _respond_with_clarification(self, state: MemoryGraphState) -> MemoryGraphState:
        decision = state["reasoner_output"]
        clarification_question = (
            state.get("clarification_question")
            or decision.clarification_question
            or "I need clarification before I can continue."
        )
        return {
            "clarification_question": clarification_question,
            "assistant_message": state.get("assistant_message") or clarification_question,
            "sql_result": None,
        }

    def _invoke_sql_generation(self, state: MemoryGraphState) -> MemoryGraphState:
        decision = state["reasoner_output"]
        prior_sql = self._resolve_prior_sql(state, decision)
        semantic_change_request = decision.semantic_change_request if prior_sql else None
        sql_result = self.sql_executor.execute(
            question=state["resolved_question"] or state["incoming_message"],
            semantic_model=state.get("projected_semantic_model") or state["semantic_model"],
            asset_selection_plan=state.get("asset_selection_plan"),
            prior_sql=prior_sql,
            semantic_change_request=semantic_change_request,
            model=state.get("model"),
            debug=state.get("debug", False),
        )
        return {
            "sql_result": sql_result,
            "assistant_message": _format_sql_assistant_message(sql_result),
        }

    def _resolve_prior_sql(
        self,
        state: MemoryGraphState,
        decision: ReasonerDecision,
    ) -> str | None:
        turn_type = decision.turn_type
        if turn_type == "fresh":
            return None
        if turn_type == "follow_up":
            active = state["session"].active_context
            return active.last_sql if active else None
        if turn_type == "historical_callback":
            snapshot = _find_snapshot(state["session"], decision.target_snapshot_id)
            return snapshot.last_sql if snapshot else None
        return None

    def _update_session_memory(self, state: MemoryGraphState) -> MemoryGraphState:
        session = state["session"].model_copy(deep=True)
        decision = state["reasoner_output"]
        turn_index = session.turn_index + 1
        previous_active_context = (
            session.active_context.model_copy(deep=True)
            if session.active_context is not None
            else None
        )

        if decision.turn_type == "fresh" and previous_active_context is not None:
            previous_snapshot = _snapshot_from_active_context(
                previous_active_context,
                created_at_turn=session.turn_index,
                snapshot_index=len(session.snapshots) + 1,
            )
            if previous_snapshot is not None:
                session.snapshots.append(previous_snapshot)

        active_context = previous_active_context
        if not state.get("clarification_required"):
            active_context = self._resolve_base_context(session, decision)
            grounded_result = self.grounder.ground(
                self._build_context_packet(
                    session=session,
                    decision=decision,
                    incoming_message=state["incoming_message"],
                    semantic_model_key=state.get("semantic_model_key"),
                )
            )
            active_context = self._sync_active_context_from_grounded(
                active_context=active_context,
                grounded_context=grounded_result.grounded_context,
                decision=decision,
                semantic_model=state["semantic_model"],
                semantic_model_key=state.get("semantic_model_key"),
            )
            selection_plan = state.get("asset_selection_plan")
            if selection_plan is not None and _asset_selection_plan_has_value(selection_plan):
                active_context = _sync_active_context_from_asset_selection_plan(
                    active_context,
                    selection_plan,
                )
            active_context.last_resolved_question = state.get("resolved_question")
            active_context.last_turn_type = decision.turn_type
            active_context.last_updated_turn_index = turn_index

        sql_result = state.get("sql_result")
        if sql_result is not None and active_context is not None:
            active_context.last_sql = sql_result.sql
            active_context.last_explanation = sql_result.explanation
            if active_context.analytical_context is not None:
                active_context.analytical_context.last_sql = sql_result.sql

        session.active_context = active_context
        session.turn_index = turn_index
        session.messages.append(
            ConversationMessage(
                role="user",
                content=state["incoming_message"],
                turn_index=turn_index,
            )
        )
        session.messages.append(
            ConversationMessage(
                role="assistant",
                content=state["assistant_message"] or "",
                turn_index=turn_index,
            )
        )
        session.rolling_summary = _build_rolling_summary(session)

        saved_session = self.store.save(session)
        return {"session": saved_session}

    def _build_response(self, state: MemoryGraphState) -> MemoryGraphState:
        return state

    def _resolve_base_context(
        self,
        session: SessionMemory,
        decision: ReasonerDecision,
    ) -> ActiveContext:
        if decision.use_active_context and session.active_context is not None:
            return session.active_context.model_copy(deep=True)

        if decision.target_snapshot_id:
            for snapshot in reversed(session.snapshots):
                if snapshot.snapshot_id == decision.target_snapshot_id:
                    return _active_context_from_snapshot(snapshot)

        if decision.turn_type == "fresh":
            return ActiveContext()

        if session.active_context is not None:
            return session.active_context.model_copy(deep=True)

        return ActiveContext()

    def _apply_state_patch(
        self,
        *,
        active_context: ActiveContext,
        decision: ReasonerDecision,
        semantic_model: dict[str, Any],
        semantic_model_key: str | None,
    ) -> ActiveContext:
        patch: StatePatch = decision.state_patch
        if decision.topic_label is not None:
            active_context.topic_label = decision.topic_label

        if active_context.semantic_model_key is None:
            active_context.semantic_model_key = semantic_model_key
        if active_context.dataset_name is None:
            dataset_name = semantic_model.get("dataset_name") or semantic_model.get("name")
            if isinstance(dataset_name, str) and dataset_name.strip():
                active_context.dataset_name = dataset_name.strip()

        if patch.topic_id is not None:
            active_context.topic_id = patch.topic_id
        if patch.topic_label is not None:
            active_context.topic_label = patch.topic_label
        if patch.semantic_model_key is not None:
            active_context.semantic_model_key = patch.semantic_model_key
        if patch.dataset_name is not None:
            active_context.dataset_name = patch.dataset_name
        if patch.metric is not None:
            active_context.metric = patch.metric
        if patch.tables:
            active_context.tables = list(patch.tables)
        if patch.dimensions:
            active_context.dimensions = list(patch.dimensions)
        if patch.filters:
            merged_filters = dict(active_context.filters)
            merged_filters.update(patch.filters)
            active_context.filters = merged_filters

        return active_context

    def _build_context_packet(
        self,
        *,
        session: SessionMemory,
        decision: ReasonerDecision,
        incoming_message: str,
        semantic_model_key: str | None,
    ) -> ContextPacket:
        requested_operation = decision.operation_type or _default_operation_type(
            decision.turn_type
        )
        active_context = _analytical_context_from_active_context(session.active_context)
        snapshot = _find_snapshot(session, decision.target_snapshot_id)
        snapshot_context = _analytical_context_from_snapshot(snapshot)

        locked_constraints = None
        if requested_operation == "return_to_snapshot":
            locked_constraints = snapshot_context
        elif requested_operation != "switch_topic":
            locked_constraints = active_context

        return ContextPacket(
            session_id=session.session_id,
            user_message=incoming_message,
            requested_operation=requested_operation or "refine_current_context",
            turn_type=decision.turn_type,
            semantic_model_key=semantic_model_key,
            active_context=active_context,
            snapshot_context=snapshot_context,
            locked_constraints=locked_constraints,
            target_snapshot_id=decision.target_snapshot_id,
            change_request=decision.semantic_change_request,
        )

    def _sync_active_context_from_grounded(
        self,
        *,
        active_context: ActiveContext,
        grounded_context: AnalyticalContext,
        decision: ReasonerDecision,
        semantic_model: dict[str, Any],
        semantic_model_key: str | None,
    ) -> ActiveContext:
        patch: StatePatch = decision.state_patch
        synced_context = active_context.model_copy(deep=True)
        semantic_change_is_meaningful = _semantic_change_is_meaningful(
            decision.semantic_change_request
        )
        merged_grounded_context = grounded_context.model_copy(deep=True)

        if semantic_change_is_meaningful:
            merged_grounded_context = _fill_grounded_context_from_state_patch(
                merged_grounded_context,
                patch,
            )
        else:
            merged_grounded_context = _apply_legacy_patch_semantics_to_grounded_context(
                merged_grounded_context,
                patch,
            )

        if decision.topic_label is not None:
            synced_context.topic_label = decision.topic_label

        if semantic_model_key is not None:
            synced_context.semantic_model_key = semantic_model_key
        elif synced_context.semantic_model_key is None:
            synced_context.semantic_model_key = patch.semantic_model_key

        dataset_name = semantic_model.get("dataset_name") or semantic_model.get("name")
        if isinstance(dataset_name, str) and dataset_name.strip():
            synced_context.dataset_name = dataset_name.strip()

        if patch.topic_id is not None:
            synced_context.topic_id = patch.topic_id
        if patch.topic_label is not None:
            synced_context.topic_label = patch.topic_label
        if patch.semantic_model_key is not None:
            synced_context.semantic_model_key = patch.semantic_model_key
        if patch.dataset_name is not None:
            synced_context.dataset_name = patch.dataset_name

        synced_context.analytical_context = merged_grounded_context.model_copy(deep=True)
        return synced_context


def fingerprint_semantic_model(semantic_model: dict[str, Any]) -> str:
    serialized = json.dumps(semantic_model, sort_keys=True, separators=(",", ":"))
    return f"sha256:{hashlib.sha256(serialized.encode('utf-8')).hexdigest()}"


def _snapshot_from_active_context(
    active_context: ActiveContext,
    *,
    created_at_turn: int,
    snapshot_index: int,
) -> ContextSnapshot | None:
    if not _context_has_memory_value(active_context):
        return None

    snapshot_id = active_context.topic_id or f"snap-{snapshot_index}"
    summary = active_context.last_resolved_question or active_context.topic_label
    return ContextSnapshot(
        snapshot_id=snapshot_id,
        topic_id=active_context.topic_id,
        topic_label=active_context.topic_label,
        summary=summary,
        semantic_model_key=active_context.semantic_model_key,
        dataset_name=active_context.dataset_name,
        base_table=active_context.base_table,
        tables_used=list(active_context.tables_used),
        join_path=list(active_context.join_path),
        entity_key_field=active_context.entity_key_field,
        grain_description=active_context.grain_description,
        selection_rationale=active_context.selection_rationale,
        tables=list(active_context.tables),
        metric=active_context.metric,
        dimensions=list(active_context.dimensions),
        filters=dict(active_context.filters),
        last_resolved_question=active_context.last_resolved_question,
        last_sql=active_context.last_sql,
        last_explanation=active_context.last_explanation,
        created_at_turn=created_at_turn if created_at_turn > 0 else None,
        asset_selection_plan=(
            active_context.asset_selection_plan.model_copy(deep=True)
            if active_context.asset_selection_plan is not None
            else None
        ),
        analytical_context=(
            active_context.analytical_context.model_copy(deep=True)
            if active_context.analytical_context is not None
            else None
        ),
    )


def _active_context_from_snapshot(snapshot: ContextSnapshot) -> ActiveContext:
    return ActiveContext(
        topic_id=snapshot.topic_id,
        topic_label=snapshot.topic_label,
        semantic_model_key=snapshot.semantic_model_key,
        dataset_name=snapshot.dataset_name,
        base_table=snapshot.base_table,
        tables_used=list(snapshot.tables_used),
        join_path=list(snapshot.join_path),
        entity_key_field=snapshot.entity_key_field,
        grain_description=snapshot.grain_description,
        selection_rationale=snapshot.selection_rationale,
        tables=list(snapshot.tables),
        metric=snapshot.metric,
        dimensions=list(snapshot.dimensions),
        filters=dict(snapshot.filters),
        last_resolved_question=snapshot.last_resolved_question,
        last_sql=snapshot.last_sql,
        last_explanation=snapshot.last_explanation,
        asset_selection_plan=(
            snapshot.asset_selection_plan.model_copy(deep=True)
            if snapshot.asset_selection_plan is not None
            else None
        ),
        analytical_context=(
            snapshot.analytical_context.model_copy(deep=True)
            if snapshot.analytical_context is not None
            else None
        ),
    )


def _context_has_memory_value(active_context: ActiveContext) -> bool:
    return any(
        [
            active_context.topic_label,
            active_context.dataset_name,
            active_context.base_table,
            active_context.tables_used,
            active_context.join_path,
            active_context.entity_key_field,
            active_context.grain_description,
            active_context.tables,
            active_context.metric,
            active_context.dimensions,
            active_context.filters,
            active_context.last_resolved_question,
            active_context.last_sql,
            active_context.asset_selection_plan is not None,
            active_context.analytical_context is not None,
        ]
    )


def _build_rolling_summary(session: SessionMemory) -> str | None:
    labels: list[str] = []
    for snapshot in session.snapshots[-3:]:
        if snapshot.topic_label:
            labels.append(snapshot.topic_label)
    if session.active_context and session.active_context.topic_label:
        labels.append(session.active_context.topic_label)
    elif (
        session.active_context
        and session.active_context.analytical_context is not None
        and session.active_context.analytical_context.topic_summary
    ):
        labels.append(session.active_context.analytical_context.topic_summary)
    if not labels:
        return session.rolling_summary
    deduped: list[str] = []
    for label in labels:
        if label not in deduped:
            deduped.append(label)
    return "Recent topics: " + " | ".join(deduped)


def _format_sql_assistant_message(sql_result: GenerateSqlResponse) -> str:
    sections = [f"```sql\n{sql_result.sql}\n```"]
    if sql_result.explanation:
        sections.append(sql_result.explanation)
    if sql_result.warnings:
        sections.append("**Warnings**\n" + "\n".join(f"- {warning}" for warning in sql_result.warnings))
    return "\n\n".join(sections)


def _find_snapshot(
    session: SessionMemory,
    snapshot_id: str | None,
) -> ContextSnapshot | None:
    if not snapshot_id:
        return None
    for snapshot in reversed(session.snapshots):
        if snapshot.snapshot_id == snapshot_id:
            return snapshot
    return None


def _default_operation_type(turn_type: str | None) -> str | None:
    if turn_type == "historical_callback":
        return "return_to_snapshot"
    if turn_type == "fresh":
        return "switch_topic"
    if turn_type == "follow_up":
        return "refine_current_context"
    return None


def _analytical_context_from_active_context(
    active_context: ActiveContext | None,
) -> AnalyticalContext | None:
    if active_context is None:
        return None
    if active_context.analytical_context is not None:
        return active_context.analytical_context.model_copy(deep=True)
    return _legacy_analytical_context(
        topic_summary=active_context.topic_label,
        tables=active_context.tables,
        metric=active_context.metric,
        dimensions=active_context.dimensions,
        filters=active_context.filters,
        last_question=active_context.last_resolved_question,
        last_sql=active_context.last_sql,
    )


def _analytical_context_from_snapshot(
    snapshot: ContextSnapshot | None,
) -> AnalyticalContext | None:
    if snapshot is None:
        return None
    if snapshot.analytical_context is not None:
        return snapshot.analytical_context.model_copy(deep=True)
    return _legacy_analytical_context(
        topic_summary=snapshot.summary or snapshot.topic_label,
        tables=snapshot.tables,
        metric=snapshot.metric,
        dimensions=snapshot.dimensions,
        filters=snapshot.filters,
        last_question=snapshot.last_resolved_question,
        last_sql=snapshot.last_sql,
    )


def _legacy_analytical_context(
    *,
    topic_summary: str | None,
    tables: list[str],
    metric: str | None,
    dimensions: list[str],
    filters: dict[str, Any],
    last_question: str | None,
    last_sql: str | None,
) -> AnalyticalContext | None:
    context = AnalyticalContext()
    has_value = False

    if topic_summary:
        context.topic_summary = topic_summary
        has_value = True
    if metric:
        context.measure = AnalyticalMeasure(name=metric)
        has_value = True
    if dimensions:
        context.groupings = [
            AnalyticalGrouping(key=str(dimension))
            for dimension in dimensions
            if str(dimension).strip()
        ]
        has_value = has_value or bool(context.groupings)
    if filters:
        context.cohort = AnalyticalCohort(
            filters=[
                AnalyticalFilter(
                    field_key=str(filter_key),
                    operator="=",
                    value=filter_value,
                )
                for filter_key, filter_value in filters.items()
                if str(filter_key).strip()
            ]
        )
        has_value = has_value or bool(context.cohort.filters)
    if tables:
        normalized_tables = [
            str(table_name)
            for table_name in tables
            if str(table_name).strip()
        ]
        if normalized_tables:
            context.resolved_assets = ResolvedAssets(
                base_table=normalized_tables[0],
                tables_used=normalized_tables,
            )
            has_value = True
    if last_question:
        context.last_question = last_question
        has_value = True
    if last_sql:
        context.last_sql = last_sql
        has_value = True

    return context if has_value else None


def _semantic_change_is_meaningful(
    change_request: Any,
) -> bool:
    if change_request is None:
        return False
    return any(
        [
            bool(change_request.filters_to_add),
            bool(change_request.filters_to_replace),
            bool(change_request.grouping_changes),
            change_request.measure_change is not None,
            change_request.time_scope_change is not None,
            change_request.ranking_change is not None,
        ]
    )


def _fill_grounded_context_from_state_patch(
    grounded_context: AnalyticalContext,
    patch: StatePatch,
) -> AnalyticalContext:
    merged_context = grounded_context.model_copy(deep=True)

    if merged_context.measure is None and patch.metric:
        merged_context.measure = AnalyticalMeasure(name=patch.metric)

    if not merged_context.groupings and patch.dimensions:
        merged_context.groupings = [
            AnalyticalGrouping(key=dim) for dim in patch.dimensions if dim.strip()
        ]

    if (
        (merged_context.resolved_assets is None or not merged_context.resolved_assets.tables_used)
        and patch.tables
    ):
        normalized_tables = [t for t in patch.tables if t.strip()]
        if normalized_tables:
            merged_context.resolved_assets = ResolvedAssets(
                base_table=normalized_tables[0],
                tables_used=normalized_tables,
            )

    if patch.filters:
        if merged_context.cohort is None:
            merged_context.cohort = AnalyticalCohort()
        existing_keys = {f.field_key for f in merged_context.cohort.filters}
        for filter_key, filter_value in patch.filters.items():
            if not filter_key.strip() or filter_key in existing_keys:
                continue
            merged_context.cohort.filters.append(
                AnalyticalFilter(field_key=filter_key, operator="=", value=filter_value)
            )
    return merged_context


def _apply_legacy_patch_semantics_to_grounded_context(
    grounded_context: AnalyticalContext,
    patch: StatePatch,
) -> AnalyticalContext:
    merged_context = grounded_context.model_copy(deep=True)

    if patch.metric:
        merged_context.measure = AnalyticalMeasure(name=patch.metric)

    if patch.dimensions:
        merged_context.groupings = [
            AnalyticalGrouping(key=dim) for dim in patch.dimensions if dim.strip()
        ]

    if patch.tables:
        normalized_tables = [t for t in patch.tables if t.strip()]
        if normalized_tables:
            merged_context.resolved_assets = ResolvedAssets(
                base_table=normalized_tables[0],
                tables_used=normalized_tables,
            )

    if patch.filters:
        cohort = (
            merged_context.cohort.model_copy(deep=True)
            if merged_context.cohort is not None
            else AnalyticalCohort()
        )
        filter_map = {item.field_key: item.model_copy(deep=True) for item in cohort.filters}
        for filter_key, filter_value in patch.filters.items():
            if not filter_key.strip():
                continue
            filter_map[filter_key] = AnalyticalFilter(
                field_key=filter_key, operator="=", value=filter_value
            )
        cohort.filters = list(filter_map.values())
        merged_context.cohort = cohort

    return merged_context


def _asset_selection_plan_has_value(asset_selection_plan: AssetSelectionPlan) -> bool:
    return any(
        [
            asset_selection_plan.base_table,
            asset_selection_plan.selected_tables,
            asset_selection_plan.selected_joins,
            asset_selection_plan.entity,
            asset_selection_plan.entity_key_field,
            asset_selection_plan.grain_description,
            asset_selection_plan.rationale,
        ]
    )


def _sync_active_context_from_asset_selection_plan(
    active_context: ActiveContext,
    asset_selection_plan: AssetSelectionPlan,
) -> ActiveContext:
    synced_context = active_context.model_copy(deep=True)
    analytical_context = (
        synced_context.analytical_context.model_copy(deep=True)
        if synced_context.analytical_context is not None
        else AnalyticalContext()
    )
    selected_table_map = _selected_table_reference_map(asset_selection_plan)
    tables_used = _tables_used_from_asset_selection_plan(
        asset_selection_plan,
        selected_table_map,
    )
    join_path = _join_path_from_asset_selection_plan(
        asset_selection_plan,
        selected_table_map,
    )
    base_table = _normalize_selected_table_reference(
        asset_selection_plan.base_table,
        selected_table_map,
    )
    if base_table is None and tables_used:
        base_table = tables_used[0]

    if asset_selection_plan.entity and not analytical_context.entity:
        analytical_context.entity = asset_selection_plan.entity
    if asset_selection_plan.entity_key_field:
        analytical_context.entity_key = asset_selection_plan.entity_key_field

    analytical_context.resolved_assets = ResolvedAssets(
        base_table=base_table,
        tables_used=tables_used,
        join_path=join_path,
        entity_key_field=asset_selection_plan.entity_key_field,
        grain_description=asset_selection_plan.grain_description,
        selection_rationale=asset_selection_plan.rationale,
    )

    synced_context.asset_selection_plan = asset_selection_plan.model_copy(deep=True)
    synced_context.analytical_context = analytical_context
    return synced_context


def _selected_table_reference_map(
    asset_selection_plan: AssetSelectionPlan,
) -> dict[str, str]:
    table_reference_map: dict[str, str] = {}
    for selected_table in asset_selection_plan.selected_tables:
        preferred_reference = selected_table.qualified_name or selected_table.table_name
        table_reference_map[selected_table.table_name] = preferred_reference
        if selected_table.qualified_name:
            table_reference_map[selected_table.qualified_name] = selected_table.qualified_name
    return table_reference_map


def _normalize_selected_table_reference(
    table_reference: str | None,
    selected_table_map: dict[str, str],
) -> str | None:
    if table_reference is None:
        return None
    normalized_reference = table_reference.strip()
    if not normalized_reference:
        return None
    return selected_table_map.get(normalized_reference, normalized_reference)


def _tables_used_from_asset_selection_plan(
    asset_selection_plan: AssetSelectionPlan,
    selected_table_map: dict[str, str],
) -> list[str]:
    tables_used = [
        selected_table.qualified_name or selected_table.table_name
        for selected_table in asset_selection_plan.selected_tables
        if (selected_table.qualified_name or selected_table.table_name)
    ]
    if not tables_used and asset_selection_plan.base_table:
        normalized_base_table = _normalize_selected_table_reference(
            asset_selection_plan.base_table,
            selected_table_map,
        )
        if normalized_base_table:
            tables_used = [normalized_base_table]
    deduped_tables: list[str] = []
    for table_name in tables_used:
        if table_name not in deduped_tables:
            deduped_tables.append(table_name)
    return deduped_tables


def _join_path_from_asset_selection_plan(
    asset_selection_plan: AssetSelectionPlan,
    selected_table_map: dict[str, str],
) -> list[str]:
    join_path: list[str] = []
    for selected_join in asset_selection_plan.selected_joins:
        left_table_name = (
            _normalize_selected_table_reference(
                selected_join.left_table_name,
                selected_table_map,
            )
            or selected_join.left_table_name
        )
        right_table_name = (
            _normalize_selected_table_reference(
                selected_join.right_table_name,
                selected_table_map,
            )
            or selected_join.right_table_name
        )
        join_description = (
            f"{left_table_name}.{selected_join.left_field_name} = "
            f"{right_table_name}.{selected_join.right_field_name}"
        )
        if join_description not in join_path:
            join_path.append(join_description)
    return join_path


_STOP_WORDS = frozenset(
    {
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "shall", "can", "and", "or", "but", "in",
        "on", "at", "to", "for", "of", "with", "by", "from", "that", "this",
        "it", "its", "i", "me", "my", "we", "our", "you", "your", "he", "she",
        "they", "their", "what", "which", "who", "how", "when", "where", "why",
        "many", "much", "some", "any", "all", "no", "not", "few", "more",
        "most", "other", "such", "than", "also", "just", "get", "go", "use",
        "there", "here", "now", "then", "about", "into", "up", "out", "so",
    }
)


def _tokenize(text: str) -> frozenset[str]:
    """Lower-case word tokens from *text*, excluding common stop words."""
    if not text:
        return frozenset()
    return frozenset(
        word
        for word in text.lower().split()
        if word.isalpha() and word not in _STOP_WORDS
    )


def _snapshot_tokens(snapshot: ContextSnapshot) -> frozenset[str]:
    """Union of tokens from all descriptive text fields of a snapshot."""
    parts = [
        snapshot.topic_label or "",
        snapshot.summary or "",
        snapshot.last_resolved_question or "",
        snapshot.dataset_name or "",
        snapshot.base_table or "",
        " ".join(snapshot.tables_used),
        " ".join(snapshot.tables),
        snapshot.metric or "",
    ]
    return _tokenize(" ".join(parts))
