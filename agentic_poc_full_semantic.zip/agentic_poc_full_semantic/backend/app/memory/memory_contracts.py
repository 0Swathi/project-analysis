from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator

from backend.app.memory.state import (
    AnalyticalContext,
    SemanticChangeRequest,
)
from backend.app.schemas.chat import OperationType, TurnType


class ContextPacket(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    session_id: str
    user_message: str
    requested_operation: OperationType
    turn_type: TurnType | None = None
    semantic_model_key: str | None = None
    active_context: AnalyticalContext | None = None
    snapshot_context: AnalyticalContext | None = None
    locked_constraints: AnalyticalContext | None = None
    target_snapshot_id: str | None = None
    change_request: SemanticChangeRequest | None = None

    @field_validator("session_id", "user_message")
    @classmethod
    def validate_required_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Context packet text values cannot be blank.")
        return value


class GroundedContextResult(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    grounded_context: AnalyticalContext
    resolved_question: str | None = None
    sql: str | None = None
    explanation: str | None = None
    tables_used: list[str] = Field(default_factory=list)
    preserved_active_context: bool = False
    notes: str | None = None
