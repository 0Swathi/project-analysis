from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from backend.app.schemas.asset_selection import AssetSelectionPlan
from backend.app.schemas.chat import OperationType, TurnType
from backend.app.schemas.responses import GenerateSqlResponse


MessageRole = Literal["user", "assistant"]


class AnalyticalFilter(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    field_key: str = Field(min_length=1)
    operator: str = Field(min_length=1)
    value: Any
    source_field: str | None = None
    rationale: str | None = None


class AnalyticalCohort(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    entity_scope: str | None = None
    description: str | None = None
    filters: list[AnalyticalFilter] = Field(default_factory=list)
    exclusions: list[AnalyticalFilter] = Field(default_factory=list)


class AnalyticalMeasure(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    name: str = Field(min_length=1)
    aggregation: str | None = None
    target: str | None = None
    source_field: str | None = None
    description: str | None = None


class AnalyticalGrouping(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    key: str = Field(min_length=1)
    label: str | None = None
    source_field: str | None = None
    granularity: str | None = None


class AnalyticalTimeScope(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    field_key: str | None = None
    source_field: str | None = None
    year: int | None = Field(default=None, ge=1900, le=2100)
    start_year: int | None = Field(default=None, ge=1900, le=2100)
    end_year: int | None = Field(default=None, ge=1900, le=2100)
    description: str | None = None


class AnalyticalRanking(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    sort_by: str = Field(min_length=1)
    sort_columns: list[str] = Field(default_factory=list)
    direction: Literal["asc", "desc"] = "desc"
    limit: int | None = Field(default=None, ge=1)
    rank: int | None = Field(default=None, ge=1)


class ResolvedAssets(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    base_table: str | None = None
    tables_used: list[str] = Field(default_factory=list)
    join_path: list[str] = Field(default_factory=list)
    entity_key_field: str | None = None
    grain_description: str | None = None
    selection_rationale: str | None = None


class AnalyticalContext(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    topic_summary: str | None = None
    entity: str | None = None
    entity_key: str | None = None
    cohort: AnalyticalCohort | None = None
    measure: AnalyticalMeasure | None = None
    groupings: list[AnalyticalGrouping] = Field(default_factory=list)
    time_scope: AnalyticalTimeScope | None = None
    ranking: AnalyticalRanking | None = None
    resolved_assets: ResolvedAssets | None = None
    last_question: str | None = None
    last_sql: str | None = None


class SemanticChangeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    filters_to_add: list[AnalyticalFilter] = Field(default_factory=list)
    filters_to_replace: list[AnalyticalFilter] = Field(default_factory=list)
    grouping_changes: list[AnalyticalGrouping] = Field(default_factory=list)
    measure_change: AnalyticalMeasure | None = None
    time_scope_change: AnalyticalTimeScope | None = None
    ranking_change: AnalyticalRanking | None = None
    notes: str | None = None


class ConversationMessage(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    role: MessageRole
    content: str = Field(min_length=1)
    turn_index: int = Field(ge=1)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ActiveContext(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    topic_id: str | None = None
    topic_label: str | None = None
    semantic_model_key: str | None = None
    dataset_name: str | None = None
    base_table: str | None = None
    tables_used: list[str] = Field(default_factory=list)
    join_path: list[str] = Field(default_factory=list)
    entity_key_field: str | None = None
    grain_description: str | None = None
    selection_rationale: str | None = None
    tables: list[str] = Field(default_factory=list)
    metric: str | None = None
    dimensions: list[str] = Field(default_factory=list)
    filters: dict[str, Any] = Field(default_factory=dict)
    last_resolved_question: str | None = None
    last_sql: str | None = None
    last_explanation: str | None = None
    last_turn_type: TurnType | None = None
    last_updated_turn_index: int | None = Field(default=None, ge=1)
    asset_selection_plan: AssetSelectionPlan | None = None
    analytical_context: AnalyticalContext | None = None

    def model_post_init(self, __context: Any) -> None:
        # Sync thin convenience fields from analytical_context on construction.
        if self.analytical_context is not None:
            self._sync_thin_fields()

    def __setattr__(self, name: str, value: Any) -> None:
        super().__setattr__(name, value)
        # Auto-sync whenever analytical_context is updated after construction.
        if name == "analytical_context" and value is not None:
            self._sync_thin_fields()

    def _sync_thin_fields(self) -> None:
        """Populate flat convenience fields from analytical_context (the source of truth)."""
        ctx = self.analytical_context
        if ctx is None:
            return
        tables_used: list[str] = []
        if ctx.resolved_assets is not None:
            tables_used = list(ctx.resolved_assets.tables_used)
            if not tables_used and ctx.resolved_assets.base_table:
                tables_used = [ctx.resolved_assets.base_table]
            object.__setattr__(self, "base_table", ctx.resolved_assets.base_table or (tables_used[0] if tables_used else None))
            object.__setattr__(self, "join_path", list(ctx.resolved_assets.join_path))
            object.__setattr__(self, "entity_key_field", ctx.resolved_assets.entity_key_field)
            object.__setattr__(self, "grain_description", ctx.resolved_assets.grain_description)
            object.__setattr__(self, "selection_rationale", ctx.resolved_assets.selection_rationale)
        else:
            object.__setattr__(self, "base_table", None)
            object.__setattr__(self, "join_path", [])
            object.__setattr__(self, "entity_key_field", None)
            object.__setattr__(self, "grain_description", None)
            object.__setattr__(self, "selection_rationale", None)
        object.__setattr__(self, "tables_used", tables_used)
        object.__setattr__(self, "tables", tables_used)
        object.__setattr__(self, "metric", ctx.measure.name if ctx.measure is not None else None)
        object.__setattr__(self, "dimensions", [g.key for g in ctx.groupings if g.key.strip()])
        object.__setattr__(self, "filters", _compute_filters_from_analytical_context(ctx))


class ContextSnapshot(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    snapshot_id: str = Field(min_length=1)
    topic_id: str | None = None
    topic_label: str | None = None
    summary: str | None = None
    semantic_model_key: str | None = None
    dataset_name: str | None = None
    base_table: str | None = None
    tables_used: list[str] = Field(default_factory=list)
    join_path: list[str] = Field(default_factory=list)
    entity_key_field: str | None = None
    grain_description: str | None = None
    selection_rationale: str | None = None
    tables: list[str] = Field(default_factory=list)
    metric: str | None = None
    dimensions: list[str] = Field(default_factory=list)
    filters: dict[str, Any] = Field(default_factory=dict)
    last_resolved_question: str | None = None
    last_sql: str | None = None
    last_explanation: str | None = None
    created_at_turn: int | None = Field(default=None, ge=1)
    asset_selection_plan: AssetSelectionPlan | None = None
    analytical_context: AnalyticalContext | None = None


class StatePatch(BaseModel):
    """Typed replacement for the untyped state_patch dict in ReasonerDecision.

    The LLM may return filters as either a plain dict or a list of {key, value}
    objects. The normalize_filters validator handles both.
    """

    model_config = ConfigDict(extra="ignore", validate_default=True, str_strip_whitespace=True)

    topic_id: str | None = None
    topic_label: str | None = None
    semantic_model_key: str | None = None
    dataset_name: str | None = None
    metric: str | None = None
    tables: list[str] = Field(default_factory=list)
    dimensions: list[str] = Field(default_factory=list)
    filters: dict[str, Any] = Field(default_factory=dict)

    @field_validator("tables", "dimensions", mode="before")
    @classmethod
    def coerce_null_list_to_empty(cls, v: Any) -> list[str]:
        return [] if v is None else v

    @field_validator("filters", mode="before")
    @classmethod
    def normalize_filters(cls, v: Any) -> dict[str, Any]:
        if v is None:
            return {}
        if isinstance(v, list):
            result: dict[str, Any] = {}
            for item in v:
                if isinstance(item, dict) and isinstance(item.get("key"), str) and item["key"].strip():
                    result[item["key"].strip()] = item.get("value")
            return result
        return v if isinstance(v, dict) else {}


class ReasonerDecision(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    turn_type: TurnType
    operation_type: OperationType | None = None
    resolved_question: str | None = None
    use_active_context: bool = False
    target_snapshot_id: str | None = None
    semantic_change_request: SemanticChangeRequest | None = None
    state_patch: StatePatch = Field(default_factory=StatePatch)
    clarification_required: bool = False
    clarification_question: str | None = None
    topic_label: str | None = None
    reason: str | None = None


class SessionMemory(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    session_id: str = Field(min_length=1)
    semantic_model_key: str | None = None
    semantic_model_fingerprint: str | None = None
    turn_index: int = Field(default=0, ge=0)
    messages: list[ConversationMessage] = Field(default_factory=list)
    active_context: ActiveContext | None = None
    snapshots: list[ContextSnapshot] = Field(default_factory=list)
    rolling_summary: str | None = None


class GraphTurnState(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    session_id: str = Field(min_length=1)
    incoming_message: str = Field(min_length=1)
    semantic_model: dict[str, Any]
    semantic_model_key: str | None = None
    model: str | None = None
    memory_model: str | None = None
    debug: bool = False
    semantic_model_fingerprint: str | None = None
    semantic_model_changed: bool = False
    session: SessionMemory | None = None
    candidate_snapshots: list[ContextSnapshot] = Field(default_factory=list)
    reasoner_output: ReasonerDecision | None = None
    resolved_question: str | None = None
    turn_type: TurnType | None = None
    clarification_required: bool = False
    clarification_question: str | None = None
    sql_result: GenerateSqlResponse | None = None
    assistant_message: str | None = None

    @field_validator("semantic_model")
    @classmethod
    def validate_semantic_model(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not value:
            raise ValueError("semantic_model cannot be empty.")
        return value


def _compute_filters_from_analytical_context(ctx: AnalyticalContext) -> dict[str, Any]:
    filter_map: dict[str, Any] = {}
    if ctx.cohort is not None:
        for f in ctx.cohort.filters:
            filter_map[f.field_key] = f.value
    if ctx.time_scope is not None:
        field_key = ctx.time_scope.field_key or "time_scope"
        if ctx.time_scope.year is not None:
            filter_map[field_key] = ctx.time_scope.year
        elif ctx.time_scope.start_year is not None or ctx.time_scope.end_year is not None:
            filter_map[field_key] = {
                "start_year": ctx.time_scope.start_year,
                "end_year": ctx.time_scope.end_year,
            }
    return filter_map
