from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pydantic import ValidationError

from backend.app.core.config import Settings, get_settings
from backend.app.core.errors import (
    AppError,
    ConfigurationError,
    MemoryReasoningError,
)
from backend.app.llm.openai_client import OpenAIResponsesClient
from backend.app.memory.state import ContextSnapshot, ReasonerDecision, SessionMemory
from backend.app.prompts.memory_reasoner_prompt import MemoryReasonerPromptBuilder


class MemoryReasoner:
    def reason(
        self,
        *,
        message: str,
        session: SessionMemory,
        candidate_snapshots: list[ContextSnapshot],
        semantic_model: dict[str, Any],
        semantic_model_key: str | None = None,
        model: str | None = None,
    ) -> ReasonerDecision:
        raise NotImplementedError


class OpenAIMemoryReasoner(MemoryReasoner):
    def __init__(
        self,
        *,
        client: OpenAIResponsesClient | None = None,
        prompt_builder: MemoryReasonerPromptBuilder | None = None,
        settings: Settings | None = None,
    ) -> None:
        self.settings = settings or get_settings()
        self.client = client or OpenAIResponsesClient(
            settings=self.settings,
            model=self.settings.openai_memory_model,
            reasoning_effort=None,
        )
        self.prompt_builder = prompt_builder or MemoryReasonerPromptBuilder()

    def reason(
        self,
        *,
        message: str,
        session: SessionMemory,
        candidate_snapshots: list[ContextSnapshot],
        semantic_model: dict[str, Any],
        semantic_model_key: str | None = None,
        model: str | None = None,
    ) -> ReasonerDecision:
        system_prompt = self.prompt_builder.build_system_prompt()
        user_prompt = self.prompt_builder.build_user_prompt(
            message=message,
            session=session,
            candidate_snapshots=candidate_snapshots,
            semantic_model=semantic_model,
            semantic_model_key=semantic_model_key,
        )
        schema = self.prompt_builder.build_response_schema()

        try:
            payload = self.client.generate_json(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                schema=schema,
                model=model,
            )
        except ConfigurationError:
            raise
        except AppError as exc:
            raise MemoryReasoningError(
                "Memory reasoner invocation failed.",
                details={
                    "error_code": exc.code,
                    "reason": exc.message,
                    "error_details": exc.details,
                },
            ) from exc
        except Exception as exc:
            raise MemoryReasoningError(
                "Memory reasoner invocation failed.",
                details={"reason": str(exc)},
            ) from exc

        try:
            return ReasonerDecision.model_validate(self._normalize_payload(payload))
        except ValidationError as exc:
            raise MemoryReasoningError(
                "Memory reasoner returned invalid structured output.",
                details={"errors": exc.errors(), "payload": payload},
            ) from exc

    def _normalize_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        normalized_payload = dict(payload)
        turn_type = normalized_payload.get("turn_type")

        if normalized_payload.get("operation_type") is None:
            normalized_payload["operation_type"] = self._default_operation_type(turn_type)

        semantic_change_request = normalized_payload.get("semantic_change_request")
        if not isinstance(semantic_change_request, dict):
            normalized_payload["semantic_change_request"] = self._empty_semantic_change_request()

        # state_patch list-of-dicts filter normalization is handled by StatePatch.normalize_filters.
        return normalized_payload

    def _default_operation_type(self, turn_type: Any) -> str | None:
        if turn_type == "historical_callback":
            return "return_to_snapshot"
        if turn_type == "fresh":
            return "switch_topic"
        if turn_type == "follow_up":
            return "refine_current_context"
        return None

    def _empty_semantic_change_request(self) -> dict[str, Any]:
        return {
            "filters_to_add": [],
            "filters_to_replace": [],
            "grouping_changes": [],
            "measure_change": None,
            "time_scope_change": None,
            "ranking_change": None,
            "notes": None,
        }


@dataclass(slots=True)
class FakeMemoryReasonerCall:
    message: str
    session_id: str
    semantic_model_key: str | None
    model: str | None
    candidate_snapshot_ids: list[str] = field(default_factory=list)


class FakeMemoryReasoner(MemoryReasoner):
    def __init__(
        self,
        decisions: list[ReasonerDecision | dict[str, Any]] | None = None,
        *,
        default_decision: ReasonerDecision | dict[str, Any] | None = None,
    ) -> None:
        self._decision_queue = list(decisions or [])
        self._default_decision = default_decision
        self.calls: list[FakeMemoryReasonerCall] = []

    def reason(
        self,
        *,
        message: str,
        session: SessionMemory,
        candidate_snapshots: list[ContextSnapshot],
        semantic_model: dict[str, Any],
        semantic_model_key: str | None = None,
        model: str | None = None,
    ) -> ReasonerDecision:
        self.calls.append(
            FakeMemoryReasonerCall(
                message=message,
                session_id=session.session_id,
                semantic_model_key=semantic_model_key,
                model=model,
                candidate_snapshot_ids=[
                    snapshot.snapshot_id for snapshot in candidate_snapshots
                ],
            )
        )

        if self._decision_queue:
            payload = self._decision_queue.pop(0)
        elif self._default_decision is not None:
            payload = self._default_decision
        else:
            raise AssertionError("FakeMemoryReasoner has no configured decision.")

        if isinstance(payload, ReasonerDecision):
            return payload.model_copy(deep=True)
        return ReasonerDecision.model_validate(payload)
