from __future__ import annotations

from backend.app.memory.memory_contracts import ContextPacket, GroundedContextResult
from backend.app.memory.state import (
    AnalyticalContext,
    AnalyticalCohort,
    AnalyticalFilter,
    AnalyticalGrouping,
    SemanticChangeRequest,
)


class ContextGrounder:
    def ground(self, packet: ContextPacket) -> GroundedContextResult:
        base_context, preserved_active_context, base_label = self._select_base_context(packet)
        grounded_context = self._apply_change_request(
            base_context=base_context,
            requested_operation=packet.requested_operation,
            change_request=packet.change_request,
        )

        if (
            packet.locked_constraints is not None
            and packet.requested_operation != "switch_topic"
        ):
            grounded_context = self._apply_locked_constraints(
                grounded_context=grounded_context,
                locked_constraints=packet.locked_constraints,
                change_request=packet.change_request,
            )

        grounded_context.last_question = packet.user_message
        if grounded_context.topic_summary is None:
            grounded_context.topic_summary = self._default_topic_summary(packet)

        tables_used = (
            list(grounded_context.resolved_assets.tables_used)
            if grounded_context.resolved_assets is not None
            else []
        )

        return GroundedContextResult(
            grounded_context=grounded_context,
            resolved_question=packet.user_message,
            tables_used=tables_used,
            preserved_active_context=preserved_active_context,
            notes=self._build_notes(
                requested_operation=packet.requested_operation,
                base_label=base_label,
                change_request=packet.change_request,
            ),
        )

    def _select_base_context(
        self,
        packet: ContextPacket,
    ) -> tuple[AnalyticalContext, bool, str]:
        if (
            packet.requested_operation == "return_to_snapshot"
            and packet.snapshot_context is not None
        ):
            return packet.snapshot_context.model_copy(deep=True), False, "snapshot_context"

        if (
            packet.requested_operation != "switch_topic"
            and packet.active_context is not None
        ):
            return packet.active_context.model_copy(deep=True), True, "active_context"

        if (
            packet.requested_operation != "switch_topic"
            and packet.snapshot_context is not None
        ):
            return packet.snapshot_context.model_copy(deep=True), False, "snapshot_context"

        return AnalyticalContext(), False, "new_context"

    def _apply_change_request(
        self,
        *,
        base_context: AnalyticalContext,
        requested_operation: str,
        change_request: SemanticChangeRequest | None,
    ) -> AnalyticalContext:
        grounded_context = base_context.model_copy(deep=True)
        if change_request is None:
            return grounded_context

        grounded_context.cohort = self._merge_cohort_filters(
            existing_cohort=grounded_context.cohort,
            change_request=change_request,
        )

        if change_request.measure_change is not None:
            grounded_context.measure = change_request.measure_change.model_copy(deep=True)

        if change_request.time_scope_change is not None:
            grounded_context.time_scope = change_request.time_scope_change.model_copy(
                deep=True
            )

        if change_request.ranking_change is not None:
            grounded_context.ranking = change_request.ranking_change.model_copy(deep=True)

        if change_request.grouping_changes:
            grounded_context.groupings = self._merge_groupings(
                existing_groupings=grounded_context.groupings,
                grouping_changes=change_request.grouping_changes,
                replace_all=requested_operation in {"change_grouping", "switch_topic"},
            )

        return grounded_context

    def _apply_locked_constraints(
        self,
        *,
        grounded_context: AnalyticalContext,
        locked_constraints: AnalyticalContext,
        change_request: SemanticChangeRequest | None,
    ) -> AnalyticalContext:
        merged_context = grounded_context.model_copy(deep=True)
        replacement_keys = {
            filter_item.field_key
            for filter_item in (change_request.filters_to_replace if change_request else [])
        }

        if merged_context.entity is None:
            merged_context.entity = locked_constraints.entity
        if merged_context.entity_key is None:
            merged_context.entity_key = locked_constraints.entity_key
        if merged_context.measure is None and locked_constraints.measure is not None:
            merged_context.measure = locked_constraints.measure.model_copy(deep=True)
        if merged_context.time_scope is None and locked_constraints.time_scope is not None:
            merged_context.time_scope = locked_constraints.time_scope.model_copy(deep=True)
        if merged_context.ranking is None and locked_constraints.ranking is not None:
            merged_context.ranking = locked_constraints.ranking.model_copy(deep=True)
        if (
            merged_context.resolved_assets is None
            and locked_constraints.resolved_assets is not None
        ):
            merged_context.resolved_assets = locked_constraints.resolved_assets.model_copy(
                deep=True
            )
        if not merged_context.groupings and locked_constraints.groupings:
            merged_context.groupings = [
                grouping.model_copy(deep=True)
                for grouping in locked_constraints.groupings
            ]
        if merged_context.topic_summary is None:
            merged_context.topic_summary = locked_constraints.topic_summary

        if locked_constraints.cohort is None:
            return merged_context

        cohort = (
            merged_context.cohort.model_copy(deep=True)
            if merged_context.cohort is not None
            else AnalyticalCohort()
        )
        if cohort.entity_scope is None:
            cohort.entity_scope = locked_constraints.cohort.entity_scope
        if cohort.description is None:
            cohort.description = locked_constraints.cohort.description

        cohort.filters = self._merge_locked_filters(
            existing_filters=cohort.filters,
            locked_filters=locked_constraints.cohort.filters,
            replacement_keys=replacement_keys,
        )
        cohort.exclusions = self._merge_locked_filters(
            existing_filters=cohort.exclusions,
            locked_filters=locked_constraints.cohort.exclusions,
            replacement_keys=set(),
        )
        merged_context.cohort = cohort
        return merged_context

    def _merge_cohort_filters(
        self,
        *,
        existing_cohort: AnalyticalCohort | None,
        change_request: SemanticChangeRequest,
    ) -> AnalyticalCohort | None:
        if (
            existing_cohort is None
            and not change_request.filters_to_add
            and not change_request.filters_to_replace
        ):
            return None

        cohort = (
            existing_cohort.model_copy(deep=True)
            if existing_cohort is not None
            else AnalyticalCohort()
        )
        filters = [filter_item.model_copy(deep=True) for filter_item in cohort.filters]

        for filter_item in change_request.filters_to_replace:
            filters = [
                existing_filter
                for existing_filter in filters
                if existing_filter.field_key != filter_item.field_key
            ]
            filters.append(filter_item.model_copy(deep=True))

        for filter_item in change_request.filters_to_add:
            if not self._contains_filter(filters, filter_item):
                filters.append(filter_item.model_copy(deep=True))

        cohort.filters = filters
        return cohort

    def _merge_groupings(
        self,
        *,
        existing_groupings: list[AnalyticalGrouping],
        grouping_changes: list[AnalyticalGrouping],
        replace_all: bool,
    ) -> list[AnalyticalGrouping]:
        if replace_all:
            return [grouping.model_copy(deep=True) for grouping in grouping_changes]

        merged_groupings = [
            grouping.model_copy(deep=True) for grouping in existing_groupings
        ]
        for grouping in grouping_changes:
            merged_groupings = [
                existing_grouping
                for existing_grouping in merged_groupings
                if existing_grouping.key != grouping.key
            ]
            merged_groupings.append(grouping.model_copy(deep=True))
        return merged_groupings

    def _merge_locked_filters(
        self,
        *,
        existing_filters: list[AnalyticalFilter],
        locked_filters: list[AnalyticalFilter],
        replacement_keys: set[str],
    ) -> list[AnalyticalFilter]:
        merged_filters = [
            filter_item.model_copy(deep=True) for filter_item in existing_filters
        ]
        for locked_filter in locked_filters:
            if locked_filter.field_key in replacement_keys:
                continue
            if not self._contains_filter(merged_filters, locked_filter):
                merged_filters.append(locked_filter.model_copy(deep=True))
        return merged_filters

    def _contains_filter(
        self,
        filters: list[AnalyticalFilter],
        candidate: AnalyticalFilter,
    ) -> bool:
        candidate_payload = candidate.model_dump(mode="python")
        return any(
            existing_filter.model_dump(mode="python") == candidate_payload
            for existing_filter in filters
        )

    def _default_topic_summary(self, packet: ContextPacket) -> str:
        if packet.change_request is not None and packet.change_request.notes:
            return packet.change_request.notes
        return packet.user_message

    def _build_notes(
        self,
        *,
        requested_operation: str,
        base_label: str,
        change_request: SemanticChangeRequest | None,
    ) -> str:
        details = change_request.notes if change_request is not None else None
        if details:
            return f"Grounded from {base_label} via {requested_operation}. {details}"
        return f"Grounded from {base_label} via {requested_operation}."
