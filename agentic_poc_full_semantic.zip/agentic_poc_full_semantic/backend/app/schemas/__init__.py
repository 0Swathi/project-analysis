"""Pydantic schemas shared across the backend."""

from backend.app.schemas.asset_selection import (
    AssetSelectionPlan,
    SelectedJoin,
    SelectedTable,
    SelectionClarification,
)
from backend.app.schemas.chat import ChatTurnRequest, ChatTurnResponse, MemoryDebugPayload
from backend.app.schemas.requests import GenerateSqlRequest, ValidateSemanticModelRequest
from backend.app.schemas.responses import (
    ContextReport,
    ErrorDetail,
    ErrorResponse,
    GenerateSqlDebug,
    GenerateSqlResponse,
    ResponseMetadata,
    ValidateSemanticModelResponse,
)
from backend.app.schemas.semantic_model import (
    RelationshipEndpoint,
    SemanticField,
    SemanticModel,
    SemanticModelSummary,
    SemanticRelationship,
    SemanticTable,
)

__all__ = [
    "AssetSelectionPlan",
    "ChatTurnRequest",
    "ChatTurnResponse",
    "ContextReport",
    "ErrorDetail",
    "ErrorResponse",
    "GenerateSqlDebug",
    "GenerateSqlRequest",
    "GenerateSqlResponse",
    "MemoryDebugPayload",
    "RelationshipEndpoint",
    "ResponseMetadata",
    "SelectedJoin",
    "SelectedTable",
    "SemanticField",
    "SemanticModel",
    "SemanticModelSummary",
    "SemanticRelationship",
    "SemanticTable",
    "SelectionClarification",
    "ValidateSemanticModelRequest",
    "ValidateSemanticModelResponse",
]
