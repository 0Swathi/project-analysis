from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from backend.app.schemas.semantic_model import SemanticModelSummary


class ContextReport(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True)

    context_window: int | None = Field(default=None, ge=1)
    semantic_layer_tokens: int | None = Field(default=None, ge=0)
    system_prompt_tokens: int | None = Field(default=None, ge=0)
    question_tokens: int | None = Field(default=None, ge=0)
    estimated_input_tokens: int | None = Field(default=None, ge=0)
    semantic_layer_pct: float | None = Field(default=None, ge=0.0)
    input_pct: float | None = Field(default=None, ge=0.0)
    remaining_tokens: int | None = None
    remaining_pct: float | None = None
    near_window: bool = False
    exceeds_window: bool = False


class ResponseMetadata(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True)

    request_id: str | None = None
    model: str | None = None
    prompt_version: str | None = None
    generated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    duration_ms: int | None = Field(default=None, ge=0)


class GenerateSqlDebug(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True)

    context_report: ContextReport | None = None
    trace: list[str] = Field(default_factory=list)


class GenerateSqlResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True)

    status: Literal["ok"] = "ok"
    sql: str = Field(min_length=1)
    explanation: str = Field(min_length=1)
    warnings: list[str] = Field(default_factory=list)
    metadata: ResponseMetadata = Field(default_factory=ResponseMetadata)
    debug: GenerateSqlDebug | None = None


class ValidateSemanticModelResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True)

    status: Literal["ok", "invalid"]
    valid: bool
    errors: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    summary: SemanticModelSummary | None = None


class ErrorDetail(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True)

    code: str = Field(min_length=1)
    message: str = Field(min_length=1)
    details: dict[str, Any] = Field(default_factory=dict)
    request_id: str | None = None


class ErrorResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True)

    error: ErrorDetail
