from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from backend.app.schemas.responses import GenerateSqlResponse


TurnType = Literal["fresh", "follow_up", "historical_callback"]
OperationType = Literal[
    "refine_current_context",
    "add_filter",
    "change_time_scope",
    "change_grouping",
    "change_measure",
    "return_to_snapshot",
    "switch_topic",
]


class ChatTurnRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    session_id: str = Field(min_length=1)
    message: str = Field(min_length=1)
    semantic_model: dict[str, Any] = Field(
        ...,
        description="Raw semantic model JSON for the current chat session.",
    )
    semantic_model_key: str | None = Field(
        default=None,
        description="Stable frontend key identifying the selected semantic model.",
    )
    model: str | None = Field(
        default=None,
        description="Optional SQL generation model override.",
    )
    memory_model: str | None = Field(
        default=None,
        description="Optional memory-reasoning model override.",
    )
    debug: bool = Field(
        default=False,
        description="When true, include memory debug information in the response.",
    )

    @field_validator("session_id", "message")
    @classmethod
    def validate_non_blank_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Value cannot be blank.")
        return value

    @field_validator("semantic_model")
    @classmethod
    def validate_semantic_model(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not value:
            raise ValueError("semantic_model cannot be empty.")
        return value


class MemoryDebugPayload(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True)

    used_active_context: bool = False
    used_snapshot_id: str | None = None
    candidate_snapshot_ids: list[str] = Field(default_factory=list)
    semantic_model_changed: bool = False
    selected_base_table: str | None = None
    selected_tables: list[str] = Field(default_factory=list)
    chat_duration_ms: int | None = Field(default=None, ge=0)
    sql_duration_ms: int | None = Field(default=None, ge=0)


class ChatTurnResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True)

    status: Literal["ok"] = "ok"
    session_id: str = Field(min_length=1)
    turn_type: TurnType | None = None
    assistant_message: str = Field(min_length=1)
    resolved_question: str | None = None
    clarification_required: bool = False
    clarification_question: str | None = None
    sql_result: GenerateSqlResponse | None = None
    memory_debug: MemoryDebugPayload | None = None
