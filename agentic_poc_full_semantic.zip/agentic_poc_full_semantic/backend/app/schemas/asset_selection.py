from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


SelectedTableRole = Literal[
    "base",
    "join",
    "filter_only",
    "dimension",
    "measure_source",
    "ranking_source",
]
JoinType = Literal["inner", "left", "semi", "anti"]


class SelectedTable(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    table_name: str = Field(min_length=1)
    qualified_name: str | None = None
    role: SelectedTableRole | None = None
    required_fields: list[str] = Field(default_factory=list)
    rationale: str | None = None

    @field_validator("required_fields")
    @classmethod
    def validate_required_fields(cls, value: list[str]) -> list[str]:
        for field_name in value:
            if not field_name.strip():
                raise ValueError("Selected table required field names cannot be blank.")
        return value


class SelectedJoin(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    left_table_name: str = Field(min_length=1)
    left_field_name: str = Field(min_length=1)
    right_table_name: str = Field(min_length=1)
    right_field_name: str = Field(min_length=1)
    join_type: JoinType | None = None
    relationship_type: str | None = None
    rationale: str | None = None


class SelectionClarification(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    required: bool = False
    question: str | None = None
    reason: str | None = None

    @model_validator(mode="after")
    def validate_question_when_required(self) -> "SelectionClarification":
        if self.required and not (self.question and self.question.strip()):
            raise ValueError(
                "Selection clarification question is required when clarification is required."
            )
        return self


class AssetSelectionPlan(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    base_table: str | None = None
    selected_tables: list[SelectedTable] = Field(default_factory=list)
    selected_joins: list[SelectedJoin] = Field(default_factory=list)
    entity: str | None = None
    entity_key_field: str | None = None
    grain_description: str | None = None
    business_intent: str | None = None
    measure_intent: str | None = None
    filters_summary: list[str] = Field(default_factory=list)
    ranking_intent: str | None = None
    clarification: SelectionClarification | None = None
    rationale: str | None = None

    @field_validator("base_table", "entity", "entity_key_field", "grain_description")
    @classmethod
    def validate_optional_text(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError("Asset selection text values cannot be blank strings.")
        return value

    @field_validator("filters_summary")
    @classmethod
    def validate_filters_summary(cls, value: list[str]) -> list[str]:
        for filter_summary in value:
            if not filter_summary.strip():
                raise ValueError("Asset selection filter summaries cannot be blank.")
        return value
