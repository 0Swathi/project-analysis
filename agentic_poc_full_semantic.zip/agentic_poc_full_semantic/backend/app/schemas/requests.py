from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from backend.app.schemas.asset_selection import AssetSelectionPlan


class SemanticChangeRequestPayload(BaseModel):
    """Structured description of what changed between the prior turn and this one.
    Used by the follow-up SQL prompt mode to apply a surgical delta to the prior SQL."""

    model_config = ConfigDict(extra="allow", validate_default=True, str_strip_whitespace=True)

    filters_to_add: list[dict[str, Any]] = Field(default_factory=list)
    filters_to_replace: list[dict[str, Any]] = Field(default_factory=list)
    grouping_changes: list[dict[str, Any]] = Field(default_factory=list)
    measure_change: dict[str, Any] | None = None
    time_scope_change: dict[str, Any] | None = None
    ranking_change: dict[str, Any] | None = None
    notes: str | None = None


class GenerateSqlRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True, str_strip_whitespace=True)

    question: str = Field(min_length=1)
    semantic_model: dict[str, Any] = Field(
        ...,
        description="Raw semantic model JSON provided by the caller.",
    )
    asset_selection_plan: AssetSelectionPlan | None = Field(
        default=None,
        description="Optional grounded asset-selection plan for the current turn.",
    )
    prior_sql: str | None = Field(
        default=None,
        description="SQL from the immediately prior turn. When present, triggers follow-up "
                    "editing mode — the generator applies only the described delta.",
    )
    semantic_change_request: SemanticChangeRequestPayload | None = Field(
        default=None,
        description="Structured description of the delta to apply to prior_sql. "
                    "Only meaningful when prior_sql is set.",
    )
    model: str | None = Field(
        default=None,
        description="Optional model override for SQL generation.",
    )
    debug: bool = Field(
        default=False,
        description="When true, include extra generation diagnostics in the response.",
    )
    request_id: str | None = Field(
        default=None,
        description="Optional caller-provided request identifier.",
    )

    @field_validator("question")
    @classmethod
    def validate_question(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Question cannot be blank.")
        return value

    @field_validator("semantic_model")
    @classmethod
    def validate_semantic_model(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not value:
            raise ValueError("semantic_model cannot be empty.")
        return value


class ValidateSemanticModelRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True)

    semantic_model: dict[str, Any] = Field(
        ...,
        description="Raw semantic model JSON to validate and normalize.",
    )

    @field_validator("semantic_model")
    @classmethod
    def validate_semantic_model(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not value:
            raise ValueError("semantic_model cannot be empty.")
        return value
