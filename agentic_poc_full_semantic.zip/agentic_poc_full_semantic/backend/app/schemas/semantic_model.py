from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator


class SemanticField(BaseModel):
    # extra="ignore" is intentional: user-provided semantic models may include
    # vendor-specific metadata that should be preserved without failing validation.
    model_config = ConfigDict(extra="ignore", validate_default=True, str_strip_whitespace=True)

    name: str = Field(min_length=1)
    description: str | None = None
    data_type: str | None = None
    kind: str | None = None
    expression: str | None = None
    default_aggregation: str | None = None
    selection_hints: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class SemanticTable(BaseModel):
    model_config = ConfigDict(extra="ignore", validate_default=True, str_strip_whitespace=True)

    name: str = Field(min_length=1)
    qualified_name: str | None = None
    description: str | None = None
    canonical_entity: str | None = None
    preferred_entity_key: str | None = None
    grain_description: str | None = None
    source_of_truth_for: list[str] = Field(default_factory=list)
    selection_hints: list[str] = Field(default_factory=list)
    fields: list[SemanticField] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class RelationshipEndpoint(BaseModel):
    model_config = ConfigDict(extra="ignore", validate_default=True, str_strip_whitespace=True)

    table_name: str = Field(min_length=1)
    field_name: str = Field(min_length=1)


class SemanticRelationship(BaseModel):
    model_config = ConfigDict(extra="ignore", validate_default=True, str_strip_whitespace=True)

    left: RelationshipEndpoint
    right: RelationshipEndpoint
    relationship_type: str | None = None
    description: str | None = None
    join_hint: str | None = None
    selection_hints: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class SemanticModel(BaseModel):
    model_config = ConfigDict(extra="ignore", validate_default=True, str_strip_whitespace=True)

    name: str | None = None
    description: str | None = None
    domain: str | None = None
    selection_hints: list[str] = Field(default_factory=list)
    tables: list[SemanticTable] = Field(default_factory=list)
    relationships: list[SemanticRelationship] = Field(default_factory=list)
    source_format: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class SemanticModelSummary(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_default=True)

    name: str | None = None
    table_count: int = Field(default=0, ge=0)
    field_count: int = Field(default=0, ge=0)
    relationship_count: int = Field(default=0, ge=0)

    @classmethod
    def from_model(cls, semantic_model: SemanticModel) -> "SemanticModelSummary":
        return cls(
            name=semantic_model.name,
            table_count=len(semantic_model.tables),
            field_count=sum(len(table.fields) for table in semantic_model.tables),
            relationship_count=len(semantic_model.relationships),
        )
