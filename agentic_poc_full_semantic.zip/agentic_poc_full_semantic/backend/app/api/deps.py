from __future__ import annotations

from functools import lru_cache

from backend.app.memory.reasoner import OpenAIMemoryReasoner
from backend.app.memory.store import InMemorySessionStore
from backend.app.services.asset_selector_service import OpenAIAssetSelectorService
from backend.app.services.chat_session_service import ChatSessionService
from backend.app.services.semantic_projection_service import SemanticProjectionService
from backend.app.services.sql_generation_service import SqlGenerationService


@lru_cache(maxsize=1)
def get_sql_generation_service() -> SqlGenerationService:
    return SqlGenerationService()


@lru_cache(maxsize=1)
def get_session_store() -> InMemorySessionStore:
    return InMemorySessionStore()


@lru_cache(maxsize=1)
def get_memory_reasoner() -> OpenAIMemoryReasoner:
    return OpenAIMemoryReasoner()


@lru_cache(maxsize=1)
def get_asset_selector_service() -> OpenAIAssetSelectorService:
    return OpenAIAssetSelectorService()


@lru_cache(maxsize=1)
def get_semantic_projection_service() -> SemanticProjectionService:
    return SemanticProjectionService()


@lru_cache(maxsize=1)
def get_chat_session_service() -> ChatSessionService:
    return ChatSessionService(
        sql_generation_service=get_sql_generation_service(),
        store=get_session_store(),
        reasoner=get_memory_reasoner(),
        asset_selector_service=get_asset_selector_service(),
        projection_service=get_semantic_projection_service(),
    )
