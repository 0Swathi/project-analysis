from __future__ import annotations

import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.app.api.routes.chat import router as chat_router
from backend.app.api.routes.health import router as health_router
from backend.app.api.routes.semantic_models import router as semantic_models_router
from backend.app.api.routes.sql import router as sql_router
from backend.app.core.config import Settings, get_settings
from backend.app.core.errors import AppError
from backend.app.core.logging import configure_logging, get_logger
from backend.app.schemas.responses import ErrorDetail, ErrorResponse


LOGGER_NAME = "semantic_sql_api"


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = getattr(app.state, "settings", get_settings())
    configure_logging(settings.log_level)
    logger = get_logger(LOGGER_NAME)
    logger.info(
        "application_startup",
        extra={
            "request_id": None,
        },
    )
    yield
    logger.info(
        "application_shutdown",
        extra={
            "request_id": None,
        },
    )


def create_app(settings: Settings | None = None) -> FastAPI:
    resolved_settings = settings or get_settings()

    app = FastAPI(
        title=resolved_settings.app_name,
        version=resolved_settings.prompt_version,
        debug=resolved_settings.debug,
        lifespan=lifespan,
    )
    app.state.settings = resolved_settings

    if resolved_settings.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=list(resolved_settings.cors_origins),
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    app.include_router(health_router)
    app.include_router(chat_router, prefix=resolved_settings.api_v1_prefix)
    app.include_router(semantic_models_router, prefix=resolved_settings.api_v1_prefix)
    app.include_router(sql_router, prefix=resolved_settings.api_v1_prefix)

    _register_exception_handlers(app)
    return app


def _register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def handle_app_error(request: Request, exc: AppError) -> JSONResponse:
        request_id = _request_id_from_request(request)
        logger = get_logger(LOGGER_NAME)
        logger.warning(
            exc.message,
            extra={"request_id": request_id},
        )
        payload = ErrorResponse(
            error=ErrorDetail(
                code=exc.code,
                message=exc.message,
                details=exc.details,
                request_id=request_id,
            )
        )
        return JSONResponse(status_code=exc.status_code, content=payload.model_dump(mode="json"))

    @app.exception_handler(RequestValidationError)
    async def handle_validation_error(
        request: Request,
        exc: RequestValidationError,
    ) -> JSONResponse:
        request_id = _request_id_from_request(request)
        logger = get_logger(LOGGER_NAME)
        logger.warning(
            "request_validation_failed",
            extra={"request_id": request_id},
        )
        payload = ErrorResponse(
            error=ErrorDetail(
                code="request_validation_error",
                message="Request body validation failed.",
                details={"errors": exc.errors()},
                request_id=request_id,
            )
        )
        return JSONResponse(status_code=422, content=payload.model_dump(mode="json"))

    @app.exception_handler(Exception)
    async def handle_unexpected_error(request: Request, exc: Exception) -> JSONResponse:
        request_id = _request_id_from_request(request)
        logger = get_logger(LOGGER_NAME)
        logger.exception(
            "unexpected_error",
            extra={"request_id": request_id},
        )
        payload = ErrorResponse(
            error=ErrorDetail(
                code="internal_server_error",
                message="An unexpected error occurred.",
                details={},
                request_id=request_id,
            )
        )
        return JSONResponse(status_code=500, content=payload.model_dump(mode="json"))


def _request_id_from_request(request: Request) -> str:
    return request.headers.get("x-request-id") or str(uuid.uuid4())


app = create_app()
