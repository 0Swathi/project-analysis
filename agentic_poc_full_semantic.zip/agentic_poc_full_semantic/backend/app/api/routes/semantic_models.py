from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.app.api.deps import get_sql_generation_service
from backend.app.schemas.requests import ValidateSemanticModelRequest
from backend.app.schemas.responses import ValidateSemanticModelResponse
from backend.app.services.sql_generation_service import SqlGenerationService


router = APIRouter(prefix="/semantic-models", tags=["semantic-models"])


@router.post(
    "/validate",
    response_model=ValidateSemanticModelResponse,
)
def validate_semantic_model(
    request: ValidateSemanticModelRequest,
    service: SqlGenerationService = Depends(get_sql_generation_service),
) -> ValidateSemanticModelResponse:
    return service.validate_semantic_model(request.semantic_model)
