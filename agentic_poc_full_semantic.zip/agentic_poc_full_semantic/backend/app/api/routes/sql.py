from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.app.api.deps import get_sql_generation_service
from backend.app.schemas.requests import GenerateSqlRequest
from backend.app.schemas.responses import GenerateSqlResponse
from backend.app.services.sql_generation_service import SqlGenerationService


router = APIRouter(prefix="/sql", tags=["sql"])


@router.post(
    "/generate",
    response_model=GenerateSqlResponse,
)
def generate_sql(
    request: GenerateSqlRequest,
    service: SqlGenerationService = Depends(get_sql_generation_service),
) -> GenerateSqlResponse:
    return service.generate(request)
