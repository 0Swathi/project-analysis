from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

from backend.app.api.deps import get_chat_session_service
from backend.app.schemas.chat import ChatTurnRequest, ChatTurnResponse
from backend.app.services.chat_session_service import ChatSessionService


router = APIRouter(prefix="/chat", tags=["chat"])


@router.post(
    "/turn",
    response_model=ChatTurnResponse,
)
def chat_turn(
    request: ChatTurnRequest,
    service: ChatSessionService = Depends(get_chat_session_service),
) -> ChatTurnResponse:
    return service.handle_turn(request)


@router.post("/turn/stream")
def chat_turn_stream(
    request: ChatTurnRequest,
    service: ChatSessionService = Depends(get_chat_session_service),
) -> StreamingResponse:
    return StreamingResponse(
        service.handle_turn_stream(request),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )
