from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


DEFAULT_OPENAI_MODEL = "gpt-5.4"
DEFAULT_OPENAI_MEMORY_MODEL = "gpt-4o-mini"
DEFAULT_API_PREFIX = "/api/v1"
DEFAULT_LOG_LEVEL = "INFO"
DEFAULT_PROMPT_VERSION = "v1"
DEFAULT_VALIDATION_MAX_RETRIES = 2


def _read_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _read_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _read_optional(name: str) -> str | None:
    value = os.getenv(name)
    if value is None:
        return None
    cleaned = value.strip()
    return cleaned or None


def _read_csv(name: str) -> tuple[str, ...]:
    value = _read_optional(name)
    if not value:
        return ()
    return tuple(part.strip() for part in value.split(",") if part.strip())


@dataclass(frozen=True, slots=True)
class Settings:
    app_name: str
    environment: str
    debug: bool
    api_v1_prefix: str
    prompt_version: str
    openai_api_key: str | None
    openai_model: str
    openai_memory_model: str
    openai_timeout_seconds: int
    validation_max_retries: int
    log_level: str
    cors_origins: tuple[str, ...]
    repo_root: Path
    backend_root: Path

    @classmethod
    def from_env(cls) -> "Settings":
        repo_root = Path(__file__).resolve().parents[3]
        backend_root = repo_root / "backend"
        return cls(
            app_name=os.getenv("APP_NAME", "semantic-sql-api").strip(),
            environment=os.getenv("APP_ENV", "development").strip().lower(),
            debug=_read_bool("APP_DEBUG", False),
            api_v1_prefix=os.getenv("API_V1_PREFIX", DEFAULT_API_PREFIX).strip(),
            prompt_version=os.getenv("PROMPT_VERSION", DEFAULT_PROMPT_VERSION).strip(),
            openai_api_key=_read_optional("OPENAI_API_KEY"),
            openai_model=os.getenv("OPENAI_MODEL", DEFAULT_OPENAI_MODEL).strip(),
            openai_memory_model=os.getenv("OPENAI_MEMORY_MODEL", DEFAULT_OPENAI_MEMORY_MODEL).strip(),
            openai_timeout_seconds=_read_int("OPENAI_TIMEOUT_SECONDS", 120),
            validation_max_retries=_read_int("VALIDATION_MAX_RETRIES", DEFAULT_VALIDATION_MAX_RETRIES),
            log_level=os.getenv("LOG_LEVEL", DEFAULT_LOG_LEVEL).strip().upper(),
            cors_origins=_read_csv("CORS_ORIGINS"),
            repo_root=repo_root,
            backend_root=backend_root,
        )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings.from_env()
