from __future__ import annotations

from typing import Any


class AppError(Exception):
    def __init__(
        self,
        *,
        code: str,
        message: str,
        status_code: int = 400,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.details = details or {}

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "details": self.details,
        }


class BadRequestError(AppError):
    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(
            code="bad_request",
            message=message,
            status_code=400,
            details=details,
        )


class ConfigurationError(AppError):
    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(
            code="configuration_error",
            message=message,
            status_code=500,
            details=details,
        )


class SemanticModelError(AppError):
    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(
            code="invalid_semantic_model",
            message=message,
            status_code=422,
            details=details,
        )


class SqlGenerationError(AppError):
    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(
            code="sql_generation_failed",
            message=message,
            status_code=502,
            details=details,
        )


class MemoryReasoningError(AppError):
    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(
            code="memory_reasoning_failed",
            message=message,
            status_code=502,
            details=details,
        )


class AssetSelectionError(AppError):
    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(
            code="asset_selection_failed",
            message=message,
            status_code=502,
            details=details,
        )


class SqlValidationError(AppError):
    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(
            code="sql_validation_failed",
            message=message,
            status_code=502,
            details=details,
        )


class ChatSessionError(AppError):
    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(
            code="chat_session_failed",
            message=message,
            status_code=502,
            details=details,
        )
