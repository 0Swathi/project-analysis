# Follow-Up Resolver — Implementation Guide

This document explains exactly how multi-turn follow-up resolution works in this system: what it is, how it is designed, which technologies it uses, how each component is implemented, and how they connect end-to-end. It is written for a developer who needs to understand, maintain, or extend this subsystem.

---

## Table of Contents

1. [What "Follow-Up Resolver" Means in This System](#1-what-follow-up-resolver-means-in-this-system)
2. [Tech Stack and Libraries](#2-tech-stack-and-libraries)
3. [System Design Overview](#3-system-design-overview)
4. [Entry Point — ChatSessionService](#4-entry-point--chatsessionservice)
5. [The LangGraph State Machine — MemoryWrapperGraph](#5-the-langgraph-state-machine--memorywrappergraph)
6. [Turn Classification — OpenAIMemoryReasoner](#6-turn-classification--openaimemoryreasoner)
7. [The ReasonerDecision Contract](#7-the-reasonerdecision-contract)
8. [Session Memory Data Model](#8-session-memory-data-model)
9. [Snapshot Management](#9-snapshot-management)
10. [Context Grounding — ContextGrounder](#10-context-grounding--contextgrounder)
11. [Prior SQL Resolution](#11-prior-sql-resolution)
12. [SQL Prompt Modes](#12-sql-prompt-modes)
13. [Asset Selection in the Follow-Up Path](#13-asset-selection-in-the-follow-up-path)
14. [Clarification Branching](#14-clarification-branching)
15. [Configuration Reference](#15-configuration-reference)
16. [End-to-End Data Flow Walkthrough](#16-end-to-end-data-flow-walkthrough)
17. [Key Design Decisions and Quirks](#17-key-design-decisions-and-quirks)

---

## 1. What "Follow-Up Resolver" Means in This System

The system generates BigQuery SQL from natural-language questions against a semantic model. When users have multi-turn conversations, questions are frequently incomplete — "break it down by state", "now filter to 2022", "go back to the earlier question about cardiologists".

The **follow-up resolver** is the pipeline that handles these incomplete turns. For every incoming message in a chat session it must:

1. **Classify** the turn as one of three types: `fresh`, `follow_up`, or `historical_callback`
2. **Expand** the raw message into a fully self-contained `resolved_question` that the SQL generator can understand without any prior context
3. **Identify** what analytically changed (new filter, grouping change, time scope, measure change, etc.) and encode it as a structured diff (`SemanticChangeRequest`)
4. **Select** the correct prior SQL to anchor the SQL generator on, when relevant
5. **Ground** the running analytical context by merging the change into the session's accumulated knowledge
6. **Snapshot** the context before each follow-up so any prior turn can be revisited

This is not a single file. It is a pipeline of six cooperating components:

| Component | File | Role |
|---|---|---|
| `ChatSessionService` | `services/chat_session_service.py` | Entry point, assembles graph, returns response |
| `MemoryWrapperGraph` | `memory/graph.py` | LangGraph state machine, orchestrates all nodes |
| `OpenAIMemoryReasoner` | `memory/reasoner.py` | LLM-powered turn classifier and question resolver |
| `ContextGrounder` | `memory/grounder.py` | Deterministic analytical context merger |
| `InMemorySessionStore` | `memory/store.py` | In-process session persistence |
| `SqlPromptBuilder` | `prompts/sql_prompt_builder.py` | Builds the follow-up system prompt with prior SQL |

---

## 2. Tech Stack and Libraries

### Core Framework
- **FastAPI** — HTTP API layer (`backend/app/api/`)
- **Pydantic v2** — All state models, request/response schemas, strict validation throughout
- **LangGraph** (`langgraph`) — Graph-based state machine that orchestrates the follow-up pipeline nodes in a defined execution order with conditional edges

### AI / LLM
- **OpenAI Responses API** (`/v1/responses`) — Called via the custom `OpenAIResponsesClient`. This is **not** the Chat Completions API. It supports structured JSON output with a strict schema enforced server-side.
- **gpt-5.4** (default) — SQL generation model
- **gpt-4o-mini** (default) — Memory reasoning model (configurable via `OPENAI_MEMORY_MODEL` env var). A cheaper, faster model is intentionally used for classification since it does not generate SQL.

### Infrastructure
- **tiktoken** — Optional token estimation for context window reporting
- **Python `functools.lru_cache`** — All services are singletons via `@lru_cache` in `backend/app/api/deps.py`
- **In-process `dict`** — Session store; no database; resets on restart

### Testing
- **`unittest`** — All 19 test modules, discovered from the `tests/` directory
- `FakeMemoryReasoner`, `FakeMemoryReasonerCall` — Test doubles in `reasoner.py` for deterministic unit testing of graph logic

---

## 3. System Design Overview

```
POST /api/v1/chat/turn
        │
        ▼
ChatSessionService.handle_turn()
  │ normalize semantic model
  │ detect model change
        │
        ▼
MemoryWrapperGraph.invoke()          ← LangGraph StateGraph
  │
  ├─ [node] load_session             → fetch/create SessionMemory
  ├─ [node] select_snapshot_candidates → pick up to 3 prior ContextSnapshot objects
  ├─ [node] reason_turn              → OpenAIMemoryReasoner → ReasonerDecision
  │
  ├─ [edge: conditional]
  │    clarification_required?
  │    ├─ yes → respond_with_clarification → update_session_memory → build_response
  │    └─ no  → select_assets
  │
  ├─ [node] select_assets            → OpenAIAssetSelectorService → AssetSelectionPlan
  │
  ├─ [edge: conditional]
  │    asset selector needs clarification?
  │    ├─ yes → respond_with_clarification → update_session_memory → build_response
  │    └─ no  → project_semantic_model
  │
  ├─ [node] project_semantic_model   → filter semantic model to selected assets only
  ├─ [node] invoke_sql_generation    → resolve prior_sql + call SqlGenerationService
  ├─ [node] update_session_memory    → snapshot + ground context + persist
  └─ [node] build_response           → format GraphTurnState → ChatTurnResponse
```

The graph is **compiled once** at construction time and is reused across all requests. LangGraph handles the node execution order and conditional routing deterministically.

---

## 4. Entry Point — ChatSessionService

**File:** `backend/app/services/chat_session_service.py`

`ChatSessionService` is the public-facing service. The API route calls `handle_turn()` or `handle_turn_stream()`.

```python
class ChatSessionService:
    def __init__(
        self,
        *,
        semantic_model_service: SemanticModelService | None = None,
        sql_generation_service: SqlGenerationService | None = None,
        store: InMemorySessionStore | None = None,
        reasoner: MemoryReasoner | None = None,
        asset_selector_service: AssetSelectorService | None = None,
        projection_service: SemanticProjectionService | None = None,
        graph: GraphInvoker | None = None,
    ) -> None:
        ...
        self.graph = graph or MemoryWrapperGraph(
            store=self.store,
            reasoner=self.reasoner,
            sql_executor=SqlGenerationExecutorAdapter(self.sql_generation_service),
            asset_selector=asset_selector_service,
            projection_service=projection_service,
        )
```

All dependencies are injected via `__init__` — no globals. The `GraphInvoker` protocol allows tests to swap in a fake graph.

### `handle_turn` flow

```python
def handle_turn(self, request: ChatTurnRequest) -> ChatTurnResponse:
    # 1. Normalize the incoming semantic model (entities → tables canonical form)
    adapted_model = self.semantic_model_service.normalize_or_raise(request.semantic_model)
    normalized_semantic_model = adapted_model.semantic_model.model_dump(...)

    # 2. Resolve the semantic model key (used to detect model switches mid-session)
    resolved_semantic_model_key = request.semantic_model_key or adapted_model.semantic_model.name

    # 3. Check if the model changed since the last turn
    semantic_model_changed = self._semantic_model_changed(
        session_id=request.session_id,
        semantic_model_key=resolved_semantic_model_key,
        semantic_model=normalized_semantic_model,
    )

    # 4. Run the full graph pipeline
    graph_result = self.graph.invoke(
        GraphTurnState(
            session_id=request.session_id,
            incoming_message=request.message,
            semantic_model=normalized_semantic_model,
            semantic_model_key=resolved_semantic_model_key,
            model=request.model,
            memory_model=request.memory_model,
            debug=request.debug,
        )
    )

    # 5. Build the HTTP response
    return self._build_response_from_graph_result(...)
```

### Semantic Model Change Detection

When the semantic model switches mid-session, the current `active_context` is snapshotted and cleared before the new turn runs. This prevents stale table references from leaking across model boundaries.

```python
def _semantic_model_changed(self, *, session_id, semantic_model_key, semantic_model) -> bool:
    previous_session = self.store.get(session_id)
    if previous_session is None:
        return False
    current_fingerprint = _fingerprint_semantic_model(semantic_model)
    return bool(
        (previous_session.semantic_model_key != semantic_model_key)
        or (previous_session.semantic_model_fingerprint != current_fingerprint)
    )
```

The fingerprint is a SHA-256 hash of the entire semantic model dict (JSON-serialized, keys sorted). This means even a single added field counts as a model change.

### `SqlGenerationExecutorAdapter`

The graph's `SqlExecutor` protocol is satisfied by this adapter, which translates between the graph's internal `SemanticChangeRequest` (state model) and the service's `SemanticChangeRequestPayload` (schema model):

```python
@dataclass(slots=True)
class SqlGenerationExecutorAdapter:
    service: SqlGenerationService

    def execute(self, *, question, semantic_model, asset_selection_plan=None,
                prior_sql=None, semantic_change_request=None, model=None, debug=False):
        scr_payload: SemanticChangeRequestPayload | None = None
        if semantic_change_request is not None:
            if hasattr(semantic_change_request, "model_dump"):
                scr_payload = SemanticChangeRequestPayload.model_validate(
                    semantic_change_request.model_dump(mode="python")
                )
        return self.service.generate(GenerateSqlRequest(
            question=question,
            semantic_model=semantic_model,
            asset_selection_plan=asset_selection_plan,
            prior_sql=prior_sql,
            semantic_change_request=scr_payload,
            model=model,
            debug=debug,
        ))
```

---

## 5. The LangGraph State Machine — MemoryWrapperGraph

**File:** `backend/app/memory/graph.py`

This is the orchestrator. It builds a `StateGraph` using LangGraph, compiles it once, and runs it per turn.

### Graph State

```python
class MemoryGraphState(TypedDict, total=False):
    session_id: str
    incoming_message: str
    semantic_model: dict[str, Any]
    semantic_model_key: str | None
    model: str | None
    memory_model: str | None
    debug: bool
    session: SessionMemory
    candidate_snapshots: list[ContextSnapshot]
    reasoner_output: ReasonerDecision
    resolved_question: str | None
    turn_type: str | None
    clarification_required: bool
    clarification_question: str | None
    asset_selection_plan: AssetSelectionPlan | None
    projected_semantic_model: dict[str, Any] | None
    sql_result: GenerateSqlResponse | None
    assistant_message: str | None
    semantic_model_changed: bool
```

All nodes read from and write to this `TypedDict`. LangGraph merges node output dicts into the running state automatically.

### Graph Construction

```python
def _build_graph(self):
    builder = StateGraph(MemoryGraphState)

    # Register all nodes
    builder.add_node("load_session", self._load_session)
    builder.add_node("select_snapshot_candidates", self._select_snapshot_candidates)
    builder.add_node("reason_turn", self._reason_turn)
    builder.add_node("select_assets", self._select_assets)
    builder.add_node("project_semantic_model", self._project_semantic_model)
    builder.add_node("respond_with_clarification", self._respond_with_clarification)
    builder.add_node("invoke_sql_generation", self._invoke_sql_generation)
    builder.add_node("update_session_memory", self._update_session_memory)
    builder.add_node("build_response", self._build_response)

    # Linear edges
    builder.add_edge(START, "load_session")
    builder.add_edge("load_session", "select_snapshot_candidates")
    builder.add_edge("select_snapshot_candidates", "reason_turn")

    # Conditional: after reasoner — clarification or asset selection
    builder.add_conditional_edges(
        "reason_turn",
        self._route_after_reasoner,
        {"clarification": "respond_with_clarification", "asset_selection": "select_assets"},
    )

    # Conditional: after asset selection — clarification or project
    builder.add_conditional_edges(
        "select_assets",
        self._route_after_asset_selection,
        {"clarification": "respond_with_clarification", "project": "project_semantic_model"},
    )

    builder.add_edge("project_semantic_model", "invoke_sql_generation")
    builder.add_edge("respond_with_clarification", "update_session_memory")
    builder.add_edge("invoke_sql_generation", "update_session_memory")
    builder.add_edge("update_session_memory", "build_response")
    builder.add_edge("build_response", END)

    return builder.compile()
```

### `load_session` node

Fetches or creates the `SessionMemory`. Also handles semantic model switching: if the model fingerprint or key changed, the active context is snapshotted and cleared before the new turn runs.

```python
def _load_session(self, state: MemoryGraphState) -> MemoryGraphState:
    session = self.store.get(session_id) or SessionMemory(session_id=session_id)

    semantic_model_changed = (
        session.semantic_model_fingerprint is not None
        and session.semantic_model_fingerprint != semantic_model_fingerprint
    ) or (
        session.semantic_model_key is not None
        and semantic_model_key is not None
        and session.semantic_model_key != semantic_model_key
    )

    if semantic_model_changed and session.active_context is not None:
        # Save current context as a snapshot before clearing
        snapshot = _snapshot_from_active_context(session.active_context, ...)
        if snapshot is not None:
            session.snapshots.append(snapshot)
        session.active_context = None
        session.last_sql_result = None

    return {"session": session, "semantic_model_changed": semantic_model_changed}
```

### `select_snapshot_candidates` node

Picks up to `max_candidate_snapshots` (default: 3) snapshots to pass to the reasoner. Always includes the oldest snapshot (for rewinding to the beginning of long chains) plus the most recent N-1.

```python
def _select_snapshot_candidates(self, state: MemoryGraphState) -> MemoryGraphState:
    oldest = session.snapshots[:1]
    recent = session.snapshots[-(self.max_candidate_snapshots - 1):]
    # deduplicate and return
    ...
```

### Routing functions

```python
def _route_after_reasoner(self, state: MemoryGraphState) -> str:
    return "clarification" if state.get("clarification_required") else "asset_selection"

def _route_after_asset_selection(self, state: MemoryGraphState) -> str:
    return "clarification" if state.get("clarification_required") else "project"
```

---

## 6. Turn Classification — OpenAIMemoryReasoner

**File:** `backend/app/memory/reasoner.py`

This is the most important component. It calls the LLM to classify the turn and produce a `ReasonerDecision`.

```python
class OpenAIMemoryReasoner(MemoryReasoner):
    def __init__(self, *, client=None, prompt_builder=None, settings=None):
        self.settings = settings or get_settings()
        self.client = client or OpenAIResponsesClient(
            settings=self.settings,
            model=self.settings.openai_memory_model,   # gpt-4o-mini by default
            reasoning_effort=None,                      # no chain-of-thought needed for classification
        )
        self.prompt_builder = prompt_builder or MemoryReasonerPromptBuilder()

    def reason(self, *, message, session, candidate_snapshots, semantic_model,
               semantic_model_key=None, model=None) -> ReasonerDecision:
        system_prompt = self.prompt_builder.build_system_prompt()
        user_prompt = self.prompt_builder.build_user_prompt(
            message=message,
            session=session,
            candidate_snapshots=candidate_snapshots,
            semantic_model=semantic_model,
            semantic_model_key=semantic_model_key,
        )
        schema = self.prompt_builder.build_response_schema()

        payload = self.client.generate_json(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            schema=schema,
            model=model,
        )

        return ReasonerDecision.model_validate(self._normalize_payload(payload))
```

### System Prompt (classification rules)

The system prompt encodes the classification heuristics directly as numbered rules. Key rules:

- **Rule 1** — Classify as `follow_up` ONLY when the message contains explicit back-references: pronouns (it, them, those, that, they), contextual modifiers (also, instead, additionally, filter that, break that down, now do it by), or phrases semantically incomplete without prior context.
- **Rule 2** — Classify as `fresh` when the message introduces a new entity, metric, table, or analytical intent — or when it could stand alone as a first question in a new session.
- **Rule 3** — Tie-breaker: when genuinely ambiguous between fresh and follow_up, **prefer fresh**. The cost of incorrectly starting fresh is lower than incorrectly inheriting a stale context.
- **Rule 4** — `historical_callback` only when the message explicitly requests return to an earlier topic: "go back to…", "return to the earlier question about…"
- **Rule 5** — If `active_context.last_updated_turn_index` is more than 3 turns behind the current `turn_index`, treat the active context as background reference only — do not classify as `follow_up` solely because the tables or domain overlap.
- **Rule 7** — `resolved_question` expansion rules:
  - `fresh` → rephrase for clarity only, do NOT inject active context
  - `follow_up` → expand into a standalone question using the minimal necessary prior context
  - `historical_callback` → expand using the target snapshot's context

### User Prompt

The user prompt is a JSON payload with all session context the LLM needs:

```python
payload = {
    "current_message": message,
    "semantic_model": {
        "semantic_model_key": semantic_model_key,
        "dataset_name": ...,
        "table_names": [...],  # up to 20 table names
        "table_count": N,
    },
    "active_context": session.active_context.model_dump(mode="json"),
    "recent_messages": [msg.model_dump(mode="json") for msg in session.messages[-6:]],
    "candidate_snapshots": [snap.model_dump(mode="json") for snap in candidate_snapshots],
    "rolling_summary": session.rolling_summary,
    "turn_index": session.turn_index,
}
```

Note that the semantic model is summarized (table names only, not full schema) to keep the reasoning call cheap.

### Output Normalization

After the LLM response, `_normalize_payload` handles common model output quirks:

```python
def _normalize_payload(self, payload: dict) -> dict:
    # If operation_type is missing, derive it from turn_type
    if normalized_payload.get("operation_type") is None:
        normalized_payload["operation_type"] = self._default_operation_type(turn_type)

    # If semantic_change_request is not a dict, replace with empty structure
    if not isinstance(semantic_change_request, dict):
        normalized_payload["semantic_change_request"] = self._empty_semantic_change_request()

    # Normalize state_patch.filters: convert [{key, value}] list to {key: value} dict
    if key == "filters" and isinstance(value, list):
        normalized_filters = {item["key"]: item["value"] for item in value if "key" in item}
        normalized_patch["filters"] = normalized_filters
```

This is because OpenAI structured output sometimes returns filters as a list of objects (which is what the schema allows) but the runtime expects a `dict[str, Any]`.

### FakeMemoryReasoner (for tests)

```python
class FakeMemoryReasoner(MemoryReasoner):
    def __init__(self, decisions=None, *, default_decision=None):
        self._decision_queue = list(decisions or [])
        self._default_decision = default_decision
        self.calls: list[FakeMemoryReasonerCall] = []

    def reason(self, *, message, session, candidate_snapshots, semantic_model,
               semantic_model_key=None, model=None) -> ReasonerDecision:
        self.calls.append(FakeMemoryReasonerCall(...))
        payload = self._decision_queue.pop(0) if self._decision_queue else self._default_decision
        if isinstance(payload, ReasonerDecision):
            return payload.model_copy(deep=True)
        return ReasonerDecision.model_validate(payload)
```

Use `FakeMemoryReasoner` in tests by passing a list of `ReasonerDecision` objects or raw dicts. The `calls` list lets you assert what the graph sent to the reasoner.

---

## 7. The ReasonerDecision Contract

**File:** `backend/app/memory/state.py`

```python
class ReasonerDecision(BaseModel):
    turn_type: TurnType                          # "fresh" | "follow_up" | "historical_callback"
    operation_type: OperationType | None         # fine-grained semantic action
    resolved_question: str | None                # standalone expanded question
    use_active_context: bool = False             # carry forward active_context?
    target_snapshot_id: str | None               # for historical_callback
    semantic_change_request: SemanticChangeRequest | None  # structured diff
    state_patch: dict[str, Any]                  # legacy compatibility patch
    clarification_required: bool = False
    clarification_question: str | None = None
    topic_label: str | None                      # human-readable topic name
    reason: str | None                           # LLM's explanation (for debugging)
```

### `TurnType` and `OperationType`

```python
TurnType = Literal["fresh", "follow_up", "historical_callback"]

OperationType = Literal[
    "refine_current_context",   # follow_up: general refinement
    "add_filter",               # follow_up: add a WHERE clause
    "change_time_scope",        # follow_up: change the time period
    "change_grouping",          # follow_up: change GROUP BY
    "change_measure",           # follow_up: change the metric
    "return_to_snapshot",       # historical_callback: rewind to a snapshot
    "switch_topic",             # fresh: start a new analytical thread
]
```

### `SemanticChangeRequest`

This is the structured representation of **what changed** in business terms, not SQL terms:

```python
class SemanticChangeRequest(BaseModel):
    filters_to_add: list[AnalyticalFilter]       # additive refinements
    filters_to_replace: list[AnalyticalFilter]   # replacements (old filter evicted)
    grouping_changes: list[AnalyticalGrouping]   # GROUP BY changes
    measure_change: AnalyticalMeasure | None     # metric change
    time_scope_change: AnalyticalTimeScope | None
    ranking_change: AnalyticalRanking | None
    notes: str | None
```

This is passed to both:
- `ContextGrounder` — to merge changes into the analytical context
- `SqlGenerationService` → `SqlPromptBuilder` — encoded in the system prompt as a description of what to apply to the prior SQL

---

## 8. Session Memory Data Model

**File:** `backend/app/memory/state.py`

### `SessionMemory`

The top-level session object, stored in `InMemorySessionStore`:

```python
class SessionMemory(BaseModel):
    session_id: str
    semantic_model_key: str | None = None
    semantic_model_fingerprint: str | None = None
    turn_index: int = 0                          # increments every turn
    messages: list[ConversationMessage]          # bounded to 20 recent messages
    active_context: ActiveContext | None         # current analytical thread
    snapshots: list[ContextSnapshot]             # bounded to 10 snapshots
    rolling_summary: str | None                 # "Recent topics: A | B | C"
    last_sql_result: GenerateSqlResponse | None
```

### `ActiveContext`

The mutable, continuously-updated state of the current analytical thread:

```python
class ActiveContext(BaseModel):
    topic_id: str | None
    topic_label: str | None                     # e.g. "Medicare Cardiologist Payments 2022"
    semantic_model_key: str | None
    dataset_name: str | None
    base_table: str | None                      # e.g. "project.dataset.physicians"
    tables_used: list[str]                      # all tables referenced
    join_path: list[str]                        # join conditions as strings
    entity_key_field: str | None                # e.g. "npi"
    grain_description: str | None
    selection_rationale: str | None
    tables: list[str]                           # thin copy of tables_used
    metric: str | None                          # e.g. "total_payment_amount"
    dimensions: list[str]                       # e.g. ["state", "specialty"]
    filters: dict[str, Any]                     # e.g. {"specialty": "Cardiology", "year": 2022}
    last_resolved_question: str | None
    last_sql: str | None                        # the most recent generated SQL
    last_explanation: str | None
    last_turn_type: TurnType | None
    last_updated_turn_index: int | None
    asset_selection_plan: AssetSelectionPlan | None
    analytical_context: AnalyticalContext | None  # rich structured representation
```

### `AnalyticalContext`

The rich, structured analytical representation inside `ActiveContext`:

```python
class AnalyticalContext(BaseModel):
    topic_summary: str | None
    entity: str | None                          # business entity, e.g. "physician"
    entity_key: str | None
    cohort: AnalyticalCohort | None             # filters + exclusions
    measure: AnalyticalMeasure | None           # metric being measured
    groupings: list[AnalyticalGrouping]         # GROUP BY dimensions
    time_scope: AnalyticalTimeScope | None
    ranking: AnalyticalRanking | None
    resolved_assets: ResolvedAssets | None      # tables, joins
    last_question: str | None
    last_sql: str | None
```

### `ContextSnapshot`

An immutable point-in-time capture of `ActiveContext`, created when a topic changes or a follow-up SQL is generated. Snapshots enable `historical_callback`.

```python
class ContextSnapshot(BaseModel):
    snapshot_id: str                # usually the topic_id, or "snap-N"
    topic_id: str | None
    topic_label: str | None
    summary: str | None
    # ... same fields as ActiveContext ...
    last_sql: str | None            # the SQL at the time of snapshot
    created_at_turn: int | None
    asset_selection_plan: AssetSelectionPlan | None
    analytical_context: AnalyticalContext | None
```

---

## 9. Snapshot Management

Snapshots are created in two situations, both inside `_update_session_memory`:

**1. Before every SQL-generating follow-up turn**

```python
if (
    decision.turn_type == "follow_up"
    and previous_active_context is not None
    and state.get("sql_result") is not None
):
    per_turn_snapshot = _snapshot_from_active_context(
        previous_active_context,
        created_at_turn=session.turn_index,
        snapshot_index=len(session.snapshots) + 1,
    )
    if per_turn_snapshot is not None:
        session.snapshots.append(per_turn_snapshot)
```

This means every turn in a follow-up chain is addressable via `historical_callback`.

**2. When a fresh turn starts and there was a prior active context**

```python
if decision.turn_type == "fresh" and previous_active_context is not None:
    previous_snapshot = _snapshot_from_active_context(
        previous_active_context,
        created_at_turn=session.turn_index,
        snapshot_index=len(session.snapshots) + 1,
    )
    if previous_snapshot is not None:
        session.snapshots.append(previous_snapshot)
```

This preserves the prior topic so it can be returned to later.

### Snapshot validity check

A snapshot is only created if the active context has meaningful values — not if it is entirely empty:

```python
def _context_has_memory_value(active_context: ActiveContext) -> bool:
    return any([
        active_context.topic_label,
        active_context.dataset_name,
        active_context.base_table,
        active_context.tables_used,
        active_context.last_sql,
        active_context.asset_selection_plan is not None,
        active_context.analytical_context is not None,
        # ... etc
    ])
```

### Snapshot candidate selection

```python
def _select_snapshot_candidates(self, state):
    # Always include the oldest snapshot (for rewinding to the very beginning)
    oldest = session.snapshots[:1]
    # Plus the most recent N-1
    recent = session.snapshots[-(self.max_candidate_snapshots - 1):]
    # Deduplicate
    ...
```

The oldest snapshot is always included so the reasoner can classify a `historical_callback` that refers to the very first topic, even if the session has grown long.

---

## 10. Context Grounding — ContextGrounder

**File:** `backend/app/memory/grounder.py`

The `ContextGrounder` is a **deterministic** (no LLM) component. It takes the `ContextPacket` — which contains the reasoner's `SemanticChangeRequest` and a reference to the current analytical context — and produces a new `AnalyticalContext` by merging the change.

### ContextPacket

```python
class ContextPacket(BaseModel):
    session_id: str
    user_message: str
    requested_operation: OperationType          # from ReasonerDecision.operation_type
    turn_type: TurnType | None
    semantic_model_key: str | None
    active_context: AnalyticalContext | None    # current session context
    snapshot_context: AnalyticalContext | None  # for historical_callback
    locked_constraints: AnalyticalContext | None  # what must NOT change
    target_snapshot_id: str | None
    change_request: SemanticChangeRequest | None
```

### `ground()` method

```python
def ground(self, packet: ContextPacket) -> GroundedContextResult:
    # 1. Pick the base context to start from
    base_context, preserved_active_context, base_label = self._select_base_context(packet)

    # 2. Apply the change request on top of the base
    grounded_context = self._apply_change_request(
        base_context=base_context,
        requested_operation=packet.requested_operation,
        change_request=packet.change_request,
    )

    # 3. Re-apply locked constraints that must not be lost
    if packet.locked_constraints is not None and packet.requested_operation != "switch_topic":
        grounded_context = self._apply_locked_constraints(
            grounded_context=grounded_context,
            locked_constraints=packet.locked_constraints,
            change_request=packet.change_request,
        )

    grounded_context.last_question = packet.user_message
    ...
    return GroundedContextResult(grounded_context=grounded_context, ...)
```

### Base context selection

| `requested_operation` | Base context used |
|---|---|
| `return_to_snapshot` | `packet.snapshot_context` |
| anything except `switch_topic` | `packet.active_context` (if present), else `packet.snapshot_context` |
| `switch_topic` | Fresh `AnalyticalContext()` |

### Applying change requests

```python
def _apply_change_request(self, *, base_context, requested_operation, change_request):
    grounded_context = base_context.model_copy(deep=True)
    if change_request is None:
        return grounded_context

    # Merge cohort filters (add + replace)
    grounded_context.cohort = self._merge_cohort_filters(
        existing_cohort=grounded_context.cohort,
        change_request=change_request,
    )

    # Replace measure if changed
    if change_request.measure_change is not None:
        grounded_context.measure = change_request.measure_change.model_copy(deep=True)

    # Replace time scope if changed
    if change_request.time_scope_change is not None:
        grounded_context.time_scope = change_request.time_scope_change.model_copy(deep=True)

    # Replace ranking if changed
    if change_request.ranking_change is not None:
        grounded_context.ranking = change_request.ranking_change.model_copy(deep=True)

    # Merge or replace groupings
    if change_request.grouping_changes:
        grounded_context.groupings = self._merge_groupings(
            existing_groupings=grounded_context.groupings,
            grouping_changes=change_request.grouping_changes,
            replace_all=requested_operation in {"change_grouping", "switch_topic"},
        )
    return grounded_context
```

### Locked constraints

For `follow_up` and `historical_callback`, a `locked_constraints` context is passed. After applying the change, the grounder re-asserts any values in `locked_constraints` that are missing from the grounded result — things like `entity`, `entity_key`, `measure`, `resolved_assets`, `groupings`, and existing filters. The `filters_to_replace` keys are excluded from locking (because the change explicitly evicts them).

This prevents a partial update (e.g., "filter by 2022") from accidentally losing the entity, join path, or base table that was established in a prior turn.

---

## 11. Prior SQL Resolution

**File:** `backend/app/memory/graph.py`, method `_resolve_prior_sql`

This is what enables the follow-up SQL prompt mode. The method selects the `prior_sql` string to pass to the SQL generator:

```python
def _resolve_prior_sql(self, state: MemoryGraphState, decision: ReasonerDecision) -> str | None:
    turn_type = decision.turn_type

    if turn_type == "fresh":
        return None                                        # start from scratch

    if turn_type == "follow_up":
        active = state["session"].active_context
        return active.last_sql if active else None         # use current thread's SQL

    if turn_type == "historical_callback":
        snapshot = _find_snapshot(state["session"], decision.target_snapshot_id)
        return snapshot.last_sql if snapshot else None     # use snapshot's SQL

    return None
```

The resolved `prior_sql` is then passed to `SqlGenerationService.generate()`, which passes it to `SqlPromptBuilder.build_system_prompt()`. When `prior_sql` is present, the prompt builder switches to the **follow-up prompt mode** (see Section 12).

The `semantic_change_request` is only passed alongside `prior_sql` — it is `None` for fresh turns:

```python
def _invoke_sql_generation(self, state: MemoryGraphState) -> MemoryGraphState:
    decision = state["reasoner_output"]
    prior_sql = self._resolve_prior_sql(state, decision)
    semantic_change_request = decision.semantic_change_request if prior_sql else None
    sql_result = self.sql_executor.execute(
        question=state["resolved_question"] or state["incoming_message"],
        semantic_model=state.get("projected_semantic_model") or state["semantic_model"],
        asset_selection_plan=state.get("asset_selection_plan"),
        prior_sql=prior_sql,
        semantic_change_request=semantic_change_request,
        model=state.get("model"),
        debug=state.get("debug", False),
    )
```

---

## 12. SQL Prompt Modes

**File:** `backend/app/prompts/sql_prompt_builder.py`

The prompt builder produces three distinct system prompts depending on what is available:

```python
def build_system_prompt(self, semantic_model, asset_selection_plan=None,
                        prior_sql=None, semantic_change_request=None) -> str:
    if prior_sql:
        return self._build_followup_system_prompt(...)    # mode 3: follow-up
    if _has_grounded_plan(asset_selection_plan):
        return self._build_grounded_system_prompt(...)    # mode 2: grounded
    return self._build_unconstrained_system_prompt(...)   # mode 1: unconstrained
```

### Mode 1 — Unconstrained (fresh turn, no asset plan)

Full schema included. Model picks its own tables and joins. 23 rules covering joins, data quality, result shaping.

### Mode 2 — Grounded (fresh turn with asset plan)

Narrowed schema (only selected tables). Grounded data plan included as authoritative. Model must stay within the plan.

### Mode 3 — Follow-up (any turn with prior_sql)

This is the key mode for follow-up resolution:

```
You are a careful analytics engineer and BigQuery SQL expert. A prior SQL query exists
for this session. Apply ONLY the change described in the user question. Do not rewrite
from scratch.

--- PRIOR SQL (anchor — preserve structure, aliases, normalization, and logic) ---
```sql
{prior_sql}
```

--- CHANGE TO APPLY ---
Read the user question below and apply exactly what it asks.

NARROWED SEMANTIC MODEL (for field reference):
{schema_text}

--- EDITING RULES ---
1.  Start from the prior SQL above. Apply only the described change. Preserve everything else.
2.  Keep all existing CTE names, table aliases, JOIN logic, NCI normalization...
3.  Do not add, remove, or restructure CTEs unless the change requires a new data path.
...
10. If a ranking or ORDER BY change is described with explicit sort columns, use exactly
    those columns in that order.
```

The key instruction is "minimal diff from the prior SQL". This preserves data quality patterns (SAFE_CAST, COALESCE, LOWER(TRIM(...))), CTE structure, and join logic across follow-up turns — the model only makes the described change.

---

## 13. Asset Selection in the Follow-Up Path

**File:** `backend/app/memory/graph.py`, `_select_assets` node

The `_select_assets` node runs for every non-clarification turn, regardless of turn type. It calls `OpenAIAssetSelectorService.select_assets()` with the turn's full context:

```python
def _select_assets(self, state: MemoryGraphState) -> MemoryGraphState:
    decision = state["reasoner_output"]
    target_snapshot = _find_snapshot(session, decision.target_snapshot_id)

    selection_plan = self.asset_selector.select_assets(
        message=state["incoming_message"],
        resolved_question=state.get("resolved_question"),
        session=session,
        semantic_model=state["semantic_model"],
        semantic_model_key=state.get("semantic_model_key"),
        turn_type=decision.turn_type,
        operation_type=decision.operation_type or _default_operation_type(decision.turn_type),
        target_snapshot=target_snapshot,            # passed for historical_callback
        model=state.get("memory_model") or state.get("model"),
    )
    ...
```

If the asset selector itself needs clarification (ambiguous table choice, etc.), it returns an `AssetSelectionPlan` with `clarification.required = True`. The graph then routes to `respond_with_clarification` instead of SQL generation.

The `AssetSelectionPlan` produced here feeds into:
- `_project_semantic_model` — filters the full semantic model down to only the selected tables
- `SqlPromptBuilder` — included in the grounded/follow-up prompt
- `SqlPlanValidator` — validates that the generated SQL only references allowed tables
- `_update_session_memory` — stored on `active_context.asset_selection_plan` for future turns

---

## 14. Clarification Branching

Two separate places in the graph can trigger clarification:

**From the reasoner** (`reason_turn` node):
```python
# In ReasonerDecision
clarification_required: bool = False
clarification_question: str | None = None
```
Used when the turn itself is too ambiguous to resolve (e.g., the user message is genuinely uninterpretable without more information).

**From the asset selector** (`select_assets` node):
```python
clarification = selection_plan.clarification
if clarification is not None and clarification.required:
    return {
        "asset_selection_plan": selection_plan,
        "clarification_required": True,
        "clarification_question": clarification.question or "I need clarification...",
        "assistant_message": clarification.question,
        "sql_result": None,
    }
```
Used when the question is understood but the correct data source is ambiguous.

Both paths route to `respond_with_clarification`:

```python
def _respond_with_clarification(self, state: MemoryGraphState) -> MemoryGraphState:
    decision = state["reasoner_output"]
    clarification_question = (
        state.get("clarification_question")
        or decision.clarification_question
        or "I need clarification before I can continue."
    )
    return {
        "clarification_question": clarification_question,
        "assistant_message": state.get("assistant_message") or clarification_question,
        "sql_result": None,
    }
```

Clarification turns still go through `update_session_memory` — the conversation message is recorded and session is persisted — but no SQL is generated and no snapshot is created.

---

## 15. Configuration Reference

**File:** `backend/app/core/config.py`

| Environment Variable | Default | Notes |
|---|---|---|
| `OPENAI_API_KEY` | — | Required |
| `OPENAI_MODEL` | `gpt-5.4` | SQL generation model |
| `OPENAI_MEMORY_MODEL` | `gpt-4o-mini` | Memory reasoning and asset selection model |
| `OPENAI_TIMEOUT_SECONDS` | `120` | Applied to both models |
| `VALIDATION_MAX_RETRIES` | `2` | SQL plan validator retries |
| `CORS_ORIGINS` | — | Comma-separated |
| `LOG_LEVEL` | `INFO` | |
| `APP_ENV` | `development` | |
| `PROMPT_VERSION` | `v1` | |

The settings object is a frozen dataclass, loaded once via `@lru_cache`:

```python
@dataclass(frozen=True, slots=True)
class Settings:
    openai_model: str
    openai_memory_model: str
    ...

@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings.from_env()
```

The memory model (`gpt-4o-mini` by default) is intentionally a cheaper, faster model than the SQL generation model (`gpt-5.4`). Classification does not require reasoning capability; it requires speed and low cost.

The per-request `memory_model` field on `ChatTurnRequest` allows the caller to override the memory model on a per-request basis (useful for testing or A/B experiments without changing env vars).

---

## 16. End-to-End Data Flow Walkthrough

Here is a concrete example of three turns to show how all components work together.

### Turn 1 — Fresh

**User:** "Show me total Medicare payments by cardiologists in 2022"

1. `reason_turn` → `turn_type=fresh`, `operation_type=switch_topic`, `resolved_question="Show total Medicare payments by cardiologists in 2022"`, `use_active_context=False`, no snapshot target, no semantic change request
2. `select_assets` → selects `physicians` table, `payments` table, join on `npi`
3. `project_semantic_model` → narrows semantic model to selected tables
4. `_resolve_prior_sql` → `None` (fresh turn)
5. `SqlPromptBuilder` → mode 2 (grounded, no prior_sql)
6. SQL generated: `SELECT specialty, SUM(payment_amount) FROM physicians JOIN payments ON physicians.npi = payments.npi WHERE EXTRACT(YEAR FROM payment_date) = 2022 AND LOWER(TRIM(specialty)) = 'cardiology' GROUP BY specialty`
7. `update_session_memory` → no snapshot needed (no prior active context), sets `active_context` with the result

### Turn 2 — Follow-up

**User:** "Now break it down by state"

1. `reason_turn` → `turn_type=follow_up`, `operation_type=change_grouping`, `resolved_question="Break down total Medicare payments by cardiologists in 2022 by state"`, `use_active_context=True`, `semantic_change_request.grouping_changes=[{key: "state"}]`
2. `select_assets` → same assets as before (follow-up inherits context)
3. `project_semantic_model` → same narrowed model
4. `_resolve_prior_sql` → returns the SQL from turn 1
5. `SqlPromptBuilder` → mode 3 (follow-up), system prompt contains the prior SQL as anchor
6. `ContextGrounder` → merges `grouping_changes=[state]` into the active context's `groupings`
7. SQL generated: prior SQL + `GROUP BY state, specialty` (minimal diff)
8. `update_session_memory` → snapshots turn 1's active context before updating to turn 2's result

### Turn 3 — Historical Callback

**User:** "Go back to the original question without the state breakdown"

1. `reason_turn` → `turn_type=historical_callback`, `target_snapshot_id=<snap from turn 1>`, `resolved_question="Show total Medicare payments by cardiologists in 2022"`, `operation_type=return_to_snapshot`
2. `select_assets` → uses `target_snapshot` to restore the turn 1 asset plan
3. `_resolve_prior_sql` → finds the turn 1 snapshot, returns its `last_sql`
4. `SqlPromptBuilder` → mode 3 with turn 1 SQL as anchor
5. `ContextGrounder` → base context = snapshot context (turn 1), no change request — restores exactly
6. SQL generated: essentially turn 1's SQL (change = remove GROUP BY state)

---

## 17. Key Design Decisions and Quirks

### Why gpt-4o-mini for memory reasoning?

Classification into `fresh`/`follow_up`/`historical_callback` does not require deep reasoning. It requires understanding pronouns and topic continuity. `gpt-4o-mini` is 10-20x cheaper than `gpt-5.4` and adds <200ms latency. The SQL generation model handles the heavy lifting.

### Why prefer `fresh` on ties?

Inheriting a stale context causes hard-to-debug SQL mutations. A `fresh` misclassification produces a correct but standalone SQL with no context — the user can always rephrase as a follow-up. A `follow_up` misclassification silently mutates a prior query with unrelated context, which is much worse.

### Why snapshot before every follow-up SQL turn?

So that every step in a follow-up chain is individually addressable via `historical_callback`. Without per-turn snapshots, a user could only go back to topic boundaries, not to intermediate steps within a topic.

### Why is session memory in-process?

Simplicity. The current use case is single-user demos and evaluation sessions. In-process memory resets on restart, which is acceptable. Extending to Redis or Postgres would require implementing `InMemorySessionStore` as an abstract base class and providing a persistent implementation.

### Why does the grounder re-apply locked constraints after applying the change?

A partial update like "change time scope to 2023" should not erase the entity join path, the base table, or existing non-conflicting filters. The grounder's `_apply_locked_constraints` preserves everything in `locked_constraints` that is absent in the grounded result, except fields explicitly evicted by `filters_to_replace`.

### Rolling summary

After every turn, `_build_rolling_summary` rebuilds a compact text string from the last 3 snapshot labels plus the active context label:

```python
def _build_rolling_summary(session: SessionMemory) -> str | None:
    labels = [snap.topic_label for snap in session.snapshots[-3:] if snap.topic_label]
    if session.active_context and session.active_context.topic_label:
        labels.append(session.active_context.topic_label)
    if not labels:
        return session.rolling_summary
    return "Recent topics: " + " | ".join(deduped)
```

This is included in the reasoner's user prompt so the LLM has a quick summary of the session's history without reading all snapshots.

### `state_patch` vs `SemanticChangeRequest`

`state_patch` is a legacy flat dict that predates `SemanticChangeRequest`. It carries thin scalar fields (`topic_id`, `topic_label`, `metric`, `dimensions`, `filters`, `tables`, `dataset_name`). `SemanticChangeRequest` is the richer, business-intent-aware replacement. Both coexist; `_sync_active_context_from_grounded` merges both sources into the active context, with `SemanticChangeRequest` taking priority when it has meaningful values.

### Session bounds

- `messages` is bounded to 20 recent messages (the store trims on save)
- `snapshots` is bounded to 10 per session
- The reasoner only sees the last 6 messages via `session.messages[-6:]`
- Snapshot candidates: up to 3 (oldest + 2 most recent)

---

## File Map

```
backend/app/
├── api/
│   ├── deps.py                     # @lru_cache singletons, DI wiring
│   └── routes/
│       └── chat.py                 # POST /api/v1/chat/turn
├── core/
│   ├── config.py                   # Settings, OPENAI_MEMORY_MODEL
│   └── errors.py                   # MemoryReasoningError, ChatSessionError
├── memory/
│   ├── graph.py                    # MemoryWrapperGraph (LangGraph state machine)
│   ├── grounder.py                 # ContextGrounder (deterministic context merger)
│   ├── memory_contracts.py         # ContextPacket, GroundedContextResult
│   ├── reasoner.py                 # OpenAIMemoryReasoner, FakeMemoryReasoner
│   ├── state.py                    # All state models: SessionMemory, ActiveContext,
│   │                               # ContextSnapshot, ReasonerDecision, AnalyticalContext
│   └── store.py                    # InMemorySessionStore
├── prompts/
│   ├── memory_reasoner_prompt.py   # MemoryReasonerPromptBuilder (classification rules + schema)
│   └── sql_prompt_builder.py       # SqlPromptBuilder (mode 1/2/3 system prompts)
├── schemas/
│   ├── chat.py                     # ChatTurnRequest, ChatTurnResponse, TurnType, OperationType
│   └── asset_selection.py          # AssetSelectionPlan
└── services/
    ├── asset_selector_service.py   # OpenAIAssetSelectorService
    ├── chat_session_service.py     # ChatSessionService (public entry point)
    ├── semantic_projection_service.py  # SemanticProjectionService
    └── sql_generation_service.py   # SqlGenerationService
```
