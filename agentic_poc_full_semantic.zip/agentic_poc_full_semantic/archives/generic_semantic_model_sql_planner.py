# Generated from generic_semantic_model_sql_planner.ipynb

# %% [markdown]
# # Generic Semantic Model → SQL Planning Notebook
#
# This notebook is a **generic baseline**, not a one-question demo.
#
# It is designed to work with semantic models like the uploaded JSON and answer many analytical questions by:
#
# 1. loading the semantic model
# 2. normalizing entities and fields
# 3. extracting concepts from the question
# 4. scoring entities and fields dynamically
# 5. picking a best single-table plan
# 6. generating SQL generically
# 7. showing where to extend to multi-table planning
#
# ## What is generic here
#
# This notebook does **not** hard-code:
# - one specific table name
# - one specific field name
# - one metric only
# - one dimension only
# - one year only
#
# Instead, it uses:
# - concept dictionaries
# - token-based matching
# - score-based ranking
# - dynamic field selection
#
# ## Current scope
#
# This version supports strong **single-table planning** and gives a clean extension point for multi-table planning.
#
# Assumption: the semantic model file exists at `/mnt/data/medicare-physician-4t-semantic.payload.json`.

# %%
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from collections import defaultdict

# %% [markdown]
# ## 1) Load semantic model

# %%
SEMANTIC_MODEL_PATH = Path('medicare-physician-4t-semantic.payload.json')

with SEMANTIC_MODEL_PATH.open('r', encoding='utf-8') as f:
    semantic_model_raw = json.load(f)

list(semantic_model_raw.keys())

# %% [markdown]
# ## 2) Normalize model objects

# %%
def norm(text: Optional[str]) -> str:
    return re.sub(r'\s+', ' ', (text or '').strip().lower())

def tokenize(text: Optional[str]) -> List[str]:
    if not text:
        return []
    return re.findall(r'[a-zA-Z0-9_]+', norm(text))

@dataclass
class FieldInfo:
    name: str
    expression: Optional[str]
    kind: Optional[str]
    data_type: Optional[str]
    description: Optional[str]
    default_aggregation: Optional[str] = None
    entity_name: Optional[str] = None

    @property
    def search_text(self) -> str:
        return " ".join([
            norm(self.name),
            norm(self.expression),
            norm(self.kind),
            norm(self.data_type),
            norm(self.description),
        ])

@dataclass
class EntityInfo:
    name: str
    qualified_name: Optional[str]
    database: Optional[str]
    schema: Optional[str]
    table: Optional[str]
    description: Optional[str]
    fields: List[FieldInfo] = field(default_factory=list)

    @property
    def search_text(self) -> str:
        return " ".join([
            norm(self.name),
            norm(self.description),
            *[f.search_text for f in self.fields]
        ])

class SemanticCatalog:
    def __init__(self, raw_model: Dict[str, Any]):
        self.raw_model = raw_model
        self.entities = self._load_entities(raw_model)
        self.relationships = raw_model.get('relationships', [])

    def _load_entities(self, raw_model: Dict[str, Any]) -> List[EntityInfo]:
        entities: List[EntityInfo] = []
        for e in raw_model.get('entities', []):
            base_table = e.get('base_table', {})
            entity = EntityInfo(
                name=e.get('name'),
                qualified_name=base_table.get('qualified_name'),
                database=base_table.get('database'),
                schema=base_table.get('schema'),
                table=base_table.get('table'),
                description=e.get('description'),
                fields=[],
            )
            for f in e.get('fields', []):
                entity.fields.append(
                    FieldInfo(
                        name=f.get('name'),
                        expression=f.get('expression'),
                        kind=f.get('kind'),
                        data_type=f.get('data_type'),
                        description=f.get('description'),
                        default_aggregation=f.get('default_aggregation'),
                        entity_name=entity.name,
                    )
                )
            entities.append(entity)
        return entities

    def get_entity(self, name: str) -> Optional[EntityInfo]:
        for entity in self.entities:
            if entity.name == name:
                return entity
        return None

catalog = SemanticCatalog(semantic_model_raw)
[(e.name, len(e.fields)) for e in catalog.entities]

# %% [markdown]
# ## 3) Generic concept dictionaries
#
# These are configurable. Add more business vocabulary as your system grows.

# %%
SEMANTIC_HINTS = {
    "dimension": {
        "state": ["state", "province", "region_state", "state_abbreviation"],
        "city": ["city", "town"],
        "provider": ["provider", "physician", "doctor", "npi", "rendering provider"],
        "specialty": ["specialty", "taxonomy", "classification", "provider type"],
        "service": ["service", "hcpcs", "procedure", "code"],
        "country": ["country", "nation"],
        "year": ["year", "reporting year", "calendar year"],
        "date": ["date", "day", "month", "quarter"],
    },
    "metric": {
        "payment": ["payment", "reimbursement", "paid amount", "medicare payment", "pymt"],
        "allowed_amount": ["allowed amount", "allowed", "alowd", "allowable"],
        "standardized_amount": ["standardized amount", "stdzd", "standardized payment"],
        "submitted_charge": ["submitted charge", "charge", "sbmtd chrg"],
        "services": ["services", "service count", "tot srvcs", "volume"],
        "beneficiaries": ["beneficiaries", "patients", "benes"],
        "count": ["count", "how many", "number of"],
    },
    "time": {
        "year": ["year", "calendar year", "reporting year"],
        "date": ["date", "day", "month", "quarter"],
    }
}

AGGREGATION_HINTS = {
    "sum": ["total", "sum", "overall", "aggregate"],
    "avg": ["average", "avg", "mean"],
    "count": ["count", "how many", "number of"],
    "top": ["top", "highest", "largest", "most"],
    "bottom": ["bottom", "lowest", "least"],
}

NUMERIC_FIELD_TOKENS = ["amt", "amount", "payment", "pymt", "allowed", "charge", "count", "srvcs", "benes", "total", "avg", "stdzd"]
VOLUME_FIELD_TOKENS = ["srvcs", "services", "count", "benes", "beneficiaries", "volume"]
AVG_FIELD_TOKENS = ["avg", "average", "mean"]

# %% [markdown]
# ## 4) Generic intent extraction

# %%
@dataclass
class ParsedConcept:
    concept_type: str   # dimension / metric / time
    canonical_name: str
    matched_phrase: str
    score: int

@dataclass
class Intent:
    raw_question: str
    parsed_concepts: List[ParsedConcept]
    filters: List[Dict[str, Any]]
    requested_aggregation: Optional[str] = None
    ranking_mode: Optional[str] = None

class GenericIntentParser:
    def _match_concepts(self, question: str) -> List[ParsedConcept]:
        q = norm(question)
        found: List[ParsedConcept] = []

        for concept_type, mapping in SEMANTIC_HINTS.items():
            for canonical_name, phrases in mapping.items():
                best_score = 0
                best_phrase = None
                for phrase in phrases:
                    if phrase in q:
                        score = max(10, len(phrase.split()) * 10)
                        if score > best_score:
                            best_score = score
                            best_phrase = phrase
                if best_phrase:
                    found.append(
                        ParsedConcept(
                            concept_type=concept_type,
                            canonical_name=canonical_name,
                            matched_phrase=best_phrase,
                            score=best_score,
                        )
                    )
        return found

    def _extract_filters(self, question: str) -> List[Dict[str, Any]]:
        q = norm(question)
        filters = []

        # Year filter: 4-digit years
        for match in re.finditer(r'\b(19\d{2}|20\d{2})\b', q):
            filters.append({
                "concept": "year",
                "op": "=",
                "value": int(match.group(1))
            })

        return filters

    def _extract_requested_aggregation(self, question: str) -> Optional[str]:
        q = norm(question)
        for agg, phrases in AGGREGATION_HINTS.items():
            if any(phrase in q for phrase in phrases):
                return agg
        return None

    def _extract_ranking_mode(self, question: str) -> Optional[str]:
        q = norm(question)
        if any(p in q for p in AGGREGATION_HINTS["top"]):
            return "top"
        if any(p in q for p in AGGREGATION_HINTS["bottom"]):
            return "bottom"
        return None

    def parse(self, question: str) -> Intent:
        return Intent(
            raw_question=question,
            parsed_concepts=self._match_concepts(question),
            filters=self._extract_filters(question),
            requested_aggregation=self._extract_requested_aggregation(question),
            ranking_mode=self._extract_ranking_mode(question),
        )

intent_parser = GenericIntentParser()

sample_questions = [
    "by state give me medicare reimbursement for the year 2020",
    "top 10 states by total allowed amount in 2021",
    "count providers by specialty",
    "average submitted charge by hcpcs code for 2019",
]

for q in sample_questions:
    print("QUESTION:", q)
    print(intent_parser.parse(q))
    print("-" * 100)

# %% [markdown]
# ## 5) Generic entity scoring
#
# This is where the system picks the best table dynamically.

# %%
class GenericEntityRanker:
    def score_entity(self, entity: EntityInfo, intent: Intent) -> Dict[str, Any]:
        score = 0
        reasons: List[str] = []

        entity_text = entity.search_text
        entity_name = norm(entity.name)

        # Base classifier: likely fact vs lookup/reference
        if any(tok in entity_name for tok in ["fact", "billing", "claims", "payment", "utilization", "transaction"]):
            score += 25
            reasons.append("looks like a fact table")

        if any(tok in entity_name for tok in ["crosswalk", "taxonomy", "reference", "lookup", "mapping"]):
            score -= 15
            reasons.append("looks like a lookup/reference table")

        # Concept coverage
        for concept in intent.parsed_concepts:
            concept_bonus = 0
            concept_terms = SEMANTIC_HINTS.get(concept.concept_type, {}).get(concept.canonical_name, [concept.canonical_name])

            matched_in_entity = any(term in entity_text for term in concept_terms)
            matched_in_fields = any(any(term in f.search_text for term in concept_terms) for f in entity.fields)

            if matched_in_entity:
                concept_bonus += 8
            if matched_in_fields:
                concept_bonus += 12

            if concept.concept_type == "metric" and matched_in_fields:
                concept_bonus += 10
            if concept.concept_type == "dimension" and matched_in_fields:
                concept_bonus += 5
            if concept.concept_type == "time" and matched_in_fields:
                concept_bonus += 5

            if concept_bonus:
                reasons.append(f"covers concept '{concept.canonical_name}' (+{concept_bonus})")
            score += concept_bonus

        # Structural bonuses
        if any(f.kind == "time_dimension" for f in entity.fields):
            score += 5
            reasons.append("has explicit time dimension")

        if any(any(tok in norm(f.name) for tok in NUMERIC_FIELD_TOKENS) for f in entity.fields):
            score += 5
            reasons.append("has numeric-like fields")

        return {"entity": entity, "score": score, "reasons": reasons}

    def rank(self, catalog: SemanticCatalog, intent: Intent) -> List[Dict[str, Any]]:
        ranked = [self.score_entity(entity, intent) for entity in catalog.entities]
        ranked.sort(key=lambda x: x["score"], reverse=True)
        return ranked

entity_ranker = GenericEntityRanker()

intent = intent_parser.parse("top 10 states by total allowed amount in 2021")
entity_rankings = entity_ranker.rank(catalog, intent)
[(r["entity"].name, r["score"]) for r in entity_rankings]

# %% [markdown]
# ## 6) Generic field scoring and selection

# %%
class GenericFieldResolver:
    def score_field(self, field: FieldInfo, concept: ParsedConcept) -> int:
        score = 0
        text = field.search_text
        fname = norm(field.name)
        phrases = SEMANTIC_HINTS.get(concept.concept_type, {}).get(concept.canonical_name, [concept.canonical_name])

        for phrase in phrases:
            if phrase in text:
                score += 10
            if phrase in fname:
                score += 10

        if concept.concept_type == "dimension" and field.kind == "dimension":
            score += 5

        if concept.concept_type == "time":
            if field.kind == "time_dimension":
                score += 10
            if "year" in fname and concept.canonical_name == "year":
                score += 10

        if concept.concept_type == "metric":
            if any(tok in fname for tok in NUMERIC_FIELD_TOKENS):
                score += 5
            if field.default_aggregation:
                score += 3

        return score

    def rank_fields_for_concept(self, entity: EntityInfo, concept: ParsedConcept) -> List[Tuple[FieldInfo, int]]:
        scored = [(field, self.score_field(field, concept)) for field in entity.fields]
        scored = [item for item in scored if item[1] > 0]
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored

    def resolve(self, entity: EntityInfo, intent: Intent) -> Dict[str, List[Tuple[FieldInfo, int]]]:
        result: Dict[str, List[Tuple[FieldInfo, int]]] = {}
        for concept in intent.parsed_concepts:
            result[f"{concept.concept_type}:{concept.canonical_name}"] = self.rank_fields_for_concept(entity, concept)
        return result

field_resolver = GenericFieldResolver()

chosen_entity = entity_rankings[0]["entity"]
field_candidates = field_resolver.resolve(chosen_entity, intent)

for key, values in field_candidates.items():
    print(key, "->", [(f.name, s) for f, s in values[:5]])

# %% [markdown]
# ## 7) Generic metric planning
#
# This step tries to decide whether a metric is directly aggregatable or needs support, such as `Avg_* × volume`.

# %%
@dataclass
class MetricPlan:
    metric_field: FieldInfo
    aggregation: str
    supporting_fields: List[FieldInfo]
    sql_expression: str
    explanation: str

class GenericMetricPlanner:
    def is_avg_like(self, field: FieldInfo) -> bool:
        text = field.search_text
        fname = norm(field.name)
        return any(tok in fname for tok in AVG_FIELD_TOKENS) or "average" in text or "mean" in text

    def find_volume_field(self, entity: EntityInfo) -> Optional[FieldInfo]:
        candidates = []
        for f in entity.fields:
            fname = norm(f.name)
            score = 0
            if any(tok in fname for tok in VOLUME_FIELD_TOKENS):
                score += 10
            if "tot_" in fname:
                score += 5
            if "count" in fname:
                score += 3
            if score > 0:
                candidates.append((f, score))
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][0] if candidates else None

    def build(self, entity: EntityInfo, metric_field: FieldInfo, requested_aggregation: Optional[str]) -> MetricPlan:
        agg = requested_aggregation or metric_field.default_aggregation or "sum"

        if agg == "count":
            return MetricPlan(
                metric_field=metric_field,
                aggregation="count",
                supporting_fields=[],
                sql_expression="COUNT(*)",
                explanation="User asked for count, so count rows in the chosen grain."
            )

        if self.is_avg_like(metric_field) and agg == "sum":
            volume_field = self.find_volume_field(entity)
            if volume_field:
                return MetricPlan(
                    metric_field=metric_field,
                    aggregation="derived_sum",
                    supporting_fields=[volume_field],
                    sql_expression=f"SUM(SAFE_CAST({metric_field.name} AS NUMERIC) * SAFE_CAST({volume_field.name} AS NUMERIC))",
                    explanation=f"{metric_field.name} is average-like, so estimate total using {metric_field.name} × {volume_field.name}."
                )

        if agg == "avg":
            return MetricPlan(
                metric_field=metric_field,
                aggregation="avg",
                supporting_fields=[],
                sql_expression=f"AVG(SAFE_CAST({metric_field.name} AS NUMERIC))",
                explanation=f"Average requested, so use AVG on {metric_field.name}."
            )

        return MetricPlan(
            metric_field=metric_field,
            aggregation="sum",
            supporting_fields=[],
            sql_expression=f"SUM(SAFE_CAST({metric_field.name} AS NUMERIC))",
            explanation=f"Default to SUM on {metric_field.name}."
        )

metric_planner = GenericMetricPlanner()

# %% [markdown]
# ## 8) Generic SQL builder

# %%
class GenericSqlBuilder:
    def quote_table(self, qualified_name: str) -> str:
        return f"`{qualified_name}`"

    def build_where_clause(self, time_field: Optional[FieldInfo], filters: List[Dict[str, Any]]) -> List[str]:
        clauses = []
        for filt in filters:
            if filt["concept"] == "year" and time_field is not None:
                clauses.append(f"EXTRACT(YEAR FROM {time_field.name}) = {int(filt['value'])}")
        return clauses

    def build(
        self,
        entity: EntityInfo,
        dimension_fields: List[FieldInfo],
        metric_plan: MetricPlan,
        time_field: Optional[FieldInfo],
        filters: List[Dict[str, Any]],
        ranking_mode: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> str:
        select_lines = []
        group_by_aliases = []

        for i, field in enumerate(dimension_fields, start=1):
            alias = field.name.lower()
            select_lines.append(f"  {field.name} AS {alias}")
            group_by_aliases.append(alias)

        metric_alias = f"{metric_plan.metric_field.name.lower()}_{metric_plan.aggregation}"
        select_lines.append(f"  {metric_plan.sql_expression} AS {metric_alias}")

        where_clauses = self.build_where_clause(time_field, filters)
        # null protection for dimensions
        where_clauses.extend([f"{field.name} IS NOT NULL" for field in dimension_fields])

        sql_parts = [
            "SELECT",
            ",\n".join(select_lines),
            f"FROM {self.quote_table(entity.qualified_name)}",
        ]

        if where_clauses:
            sql_parts.append("WHERE " + "\n  AND ".join(where_clauses))

        if group_by_aliases:
            sql_parts.append("GROUP BY " + ", ".join(group_by_aliases))

        if ranking_mode == "bottom":
            sql_parts.append(f"ORDER BY {metric_alias} ASC")
        else:
            sql_parts.append(f"ORDER BY {metric_alias} DESC")

        if limit:
            sql_parts.append(f"LIMIT {limit}")

        return "\n".join(sql_parts) + ";"

sql_builder = GenericSqlBuilder()

# %% [markdown]
# ## 9) End-to-end generic planner

# %%
class GenericSemanticSqlPlanner:
    def __init__(self, catalog: SemanticCatalog):
        self.catalog = catalog
        self.intent_parser = GenericIntentParser()
        self.entity_ranker = GenericEntityRanker()
        self.field_resolver = GenericFieldResolver()
        self.metric_planner = GenericMetricPlanner()
        self.sql_builder = GenericSqlBuilder()

    def _choose_best_field(self, ranked_fields: List[Tuple[FieldInfo, int]]) -> Optional[FieldInfo]:
        return ranked_fields[0][0] if ranked_fields else None

    def _infer_limit(self, question: str) -> Optional[int]:
        q = norm(question)
        match = re.search(r'\btop\s+(\d+)\b', q)
        if match:
            return int(match.group(1))
        match = re.search(r'\bbottom\s+(\d+)\b', q)
        if match:
            return int(match.group(1))
        return None

    def plan(self, question: str) -> Dict[str, Any]:
        intent = self.intent_parser.parse(question)
        entity_rankings = self.entity_ranker.rank(self.catalog, intent)
        chosen_entity = entity_rankings[0]["entity"]

        resolved = self.field_resolver.resolve(chosen_entity, intent)

        dimension_fields = []
        time_field = None
        metric_field = None

        for concept in intent.parsed_concepts:
            key = f"{concept.concept_type}:{concept.canonical_name}"
            best = self._choose_best_field(resolved.get(key, []))
            if best is None:
                continue

            if concept.concept_type == "dimension":
                if concept.canonical_name not in ["year", "date"]:
                    dimension_fields.append(best)
            elif concept.concept_type == "time":
                if time_field is None:
                    time_field = best
            elif concept.concept_type == "metric" and metric_field is None:
                metric_field = best

        # If user only has year filter but no explicit time concept, still resolve a time field
        if time_field is None and intent.filters:
            year_concept = ParsedConcept("time", "year", "year", 1)
            time_candidates = self.field_resolver.rank_fields_for_concept(chosen_entity, year_concept)
            time_field = self._choose_best_field(time_candidates)

        if metric_field is None:
            raise ValueError("Could not resolve a metric field for the question.")

        metric_plan = self.metric_planner.build(chosen_entity, metric_field, intent.requested_aggregation)
        limit = self._infer_limit(question)

        sql = self.sql_builder.build(
            entity=chosen_entity,
            dimension_fields=dimension_fields,
            metric_plan=metric_plan,
            time_field=time_field,
            filters=intent.filters,
            ranking_mode=intent.ranking_mode,
            limit=limit,
        )

        compact_context = {
            "question": question,
            "chosen_entity": {
                "name": chosen_entity.name,
                "qualified_name": chosen_entity.qualified_name,
                "description": chosen_entity.description,
            },
            "dimensions": [f.name for f in dimension_fields],
            "time_field": time_field.name if time_field else None,
            "metric_field": metric_field.name,
            "metric_plan": metric_plan.explanation,
            "filters": intent.filters,
        }

        return {
            "intent": intent,
            "entity_rankings": entity_rankings,
            "chosen_entity": chosen_entity,
            "resolved_fields": resolved,
            "dimension_fields": dimension_fields,
            "time_field": time_field,
            "metric_field": metric_field,
            "metric_plan": metric_plan,
            "compact_context": compact_context,
            "sql": sql,
        }

planner = GenericSemanticSqlPlanner(catalog)

# %% [markdown]
# ## 10) Try multiple questions
#
# This is the key difference from the hard-coded version.

# %%
questions = [
    "by state give me medicare reimbursement for the year 2020",
    "top 10 states by total allowed amount in 2021",
    "count providers by specialty",
    "average submitted charge by service for 2019",
]

for q in questions:
    print("=" * 120)
    print("QUESTION:", q)
    result = planner.plan(q)
    print("CHOSEN ENTITY:", result["chosen_entity"].name)
    print("METRIC FIELD:", result["metric_field"].name)
    print("DIMENSIONS:", [f.name for f in result["dimension_fields"]])
    print("TIME FIELD:", result["time_field"].name if result["time_field"] else None)
    print("METRIC PLAN:", result["metric_plan"].explanation)
    print("SQL:")
    print(result["sql"])
    print()

# %% [markdown]
# ## 11) Debug helpers

# %%
def show_entity_rankings(result: Dict[str, Any]) -> None:
    for rank in result["entity_rankings"]:
        entity = rank["entity"]
        print(f"Entity: {entity.name} | Score: {rank['score']}")
        for reason in rank["reasons"]:
            print(f"  - {reason}")
        print()

def show_field_candidates(result: Dict[str, Any]) -> None:
    for key, values in result["resolved_fields"].items():
        print(key)
        for field, score in values[:5]:
            print(f"  - {field.name}: {score}")
        print()

debug_result = planner.plan("top 10 states by total allowed amount in 2021")
show_entity_rankings(debug_result)
show_field_candidates(debug_result)
print(debug_result["compact_context"])

# %% [markdown]
# ## 12) How to make this more generic in production
#
# ### Better intent parsing
# Replace the rule-based parser with:
# - an LLM-based structured intent extractor
# - or a hybrid parser with rules + LLM fallback
#
# ### Better concept dictionaries
# Expand synonyms for:
# - business metrics
# - dimensions
# - domain jargon
# - abbreviations
#
# ### Multi-table support
# You need explicit relationships in the semantic model, for example:
# ```json
# {
#   "from_entity": "MedicareBillingData",
#   "from_field": "Rndrng_NPI",
#   "to_entity": "npidata",
#   "to_field": "npi",
#   "relationship_type": "many_to_one"
# }
# ```
#
# Then:
# 1. detect concepts across entities
# 2. build an entity graph
# 3. find the smallest join path covering all required concepts
# 4. rank join plans by coverage, join count, and grain safety
# 5. generate SQL from the join plan
#
# ### Validation
# Add:
# - field existence validation
# - join safety validation
# - aggregation checks
# - repair loops
#
# ### LLM usage
# Do **not** send the full semantic model.
# Send only:
# - chosen entity or join plan
# - chosen fields
# - metric rules
# - filters
# - a compact context packet

# %%
# Optional starter sketch for multi-table planning

class MultiTableJoinPlanner:
    def __init__(self, relationships: List[Dict[str, Any]]):
        self.relationships = relationships

    def build_graph(self) -> Dict[str, List[str]]:
        graph = defaultdict(list)
        for rel in self.relationships:
            left = rel.get("from_entity")
            right = rel.get("to_entity")
            if left and right:
                graph[left].append(right)
                graph[right].append(left)
        return graph

    def status(self) -> Dict[str, Any]:
        if not self.relationships:
            return {
                "status": "not_ready",
                "reason": "Semantic model has no explicit relationships, so generic multi-table planning cannot be done safely yet."
            }
        return {
            "status": "ready_for_graph_search",
            "reason": "Relationships exist. Next step is shortest-path / minimal-cover join planning."
        }

multi_table_planner = MultiTableJoinPlanner(catalog.relationships)
multi_table_planner.status()

