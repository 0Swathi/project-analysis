from __future__ import annotations

import argparse
import json
import os
import re
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional, Protocol


READ_ONLY_SQL_PATTERN = re.compile(r"^\s*(with|select)\b", re.IGNORECASE)
BLOCKED_SQL_PATTERN = re.compile(
    r"\b(insert|update|delete|drop|alter|create|truncate|merge|grant|revoke|call)\b",
    re.IGNORECASE,
)


PLANNING_SCHEMA = {
    "name": "semantic_sql_plan",
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "status": {
                "type": "string",
                "enum": ["ok", "needs_clarification", "unsupported"],
            },
            "reasoning": {"type": "string"},
            "clarification_question": {"type": ["string", "null"]},
            "unsupported_reason": {"type": ["string", "null"]},
            "selected_entities": {
                "type": "array",
                "items": {"type": "string"},
            },
            "field_bindings": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "role": {
                            "type": "string",
                            "enum": ["dimension", "metric", "filter", "time"],
                        },
                        "entity_name": {"type": "string"},
                        "field_name": {"type": "string"},
                        "question_phrase": {"type": "string"},
                    },
                    "required": ["role", "entity_name", "field_name", "question_phrase"],
                },
            },
        },
        "required": [
            "status",
            "reasoning",
            "clarification_question",
            "unsupported_reason",
            "selected_entities",
            "field_bindings",
        ],
    },
}

SQL_SCHEMA = {
    "name": "semantic_sql_output",
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "status": {
                "type": "string",
                "enum": ["ok", "needs_clarification", "unsupported"],
            },
            "reasoning": {"type": "string"},
            "clarification_question": {"type": ["string", "null"]},
            "unsupported_reason": {"type": ["string", "null"]},
            "sql": {"type": ["string", "null"]},
            "table_references": {
                "type": "array",
                "items": {"type": "string"},
            },
            "referenced_fields": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "entity_name": {"type": "string"},
                        "field_name": {"type": "string"},
                    },
                    "required": ["entity_name", "field_name"],
                },
            },
            "assumptions": {
                "type": "array",
                "items": {"type": "string"},
            },
        },
        "required": [
            "status",
            "reasoning",
            "clarification_question",
            "unsupported_reason",
            "sql",
            "table_references",
            "referenced_fields",
            "assumptions",
        ],
    },
}

PLANNER_SYSTEM_PROMPT = """You are a semantic-layer planner.

Work only from the semantic-model context provided in the user message.

Rules:
- Do not invent entities, fields, joins, or business logic.
- Bind the user's request to exact entity and field names from the semantic model.
- If the question requires multiple entities, include every required entity.
- If the semantic model does not provide enough relationship information for a safe join, return "unsupported".
- If the question is ambiguous, return "needs_clarification".
- Keep the reasoning brief and concrete.
- Return JSON only that matches the schema.
"""

PLAN_REPAIR_SYSTEM_PROMPT = """You are repairing a semantic-layer planning output.

Use the semantic-model context and the validation errors from the user message.

Rules:
- Fix only the invalid parts.
- Do not invent entities, fields, joins, or business logic.
- If the request still cannot be grounded safely, return "unsupported" or "needs_clarification".
- Return JSON only that matches the schema.
"""

SQL_SYSTEM_PROMPT = """You are a SQL generation agent.

You are given:
- the validated user question
- the validated semantic-layer bindings
- the allowed entities, fields, and relationships

Rules:
- Generate exactly one read-only SQL query.
- Use only the allowed entities and fields.
- If more than one entity is required, only join when the provided relationships are sufficient.
- Do not invent columns, tables, filters, calculations, or join keys.
- If the semantic layer only exposes average-like metrics but the user asks for totals, you may derive totals only when a clearly relevant supporting volume/count field exists in the same allowed context, and record that assumption.
- If the request is still ambiguous or unsupported, say so in the structured output instead of guessing.
- Return JSON only that matches the schema.
"""

SQL_REPAIR_SYSTEM_PROMPT = """You are repairing a SQL draft.

Use the validated semantic context and the validation errors from the user message.

Rules:
- Fix only the invalid parts.
- Keep the query read-only.
- Use only allowed entities and fields.
- If it cannot be repaired safely, return "unsupported" or "needs_clarification".
- Return JSON only that matches the schema.
"""

AUTO_ENV_FILENAMES = (".env", "openaikeys.txt")


def json_dumps(data: Any) -> str:
    return json.dumps(data, indent=2, ensure_ascii=True, sort_keys=True)


def norm(text: Optional[str]) -> str:
    return re.sub(r"\s+", " ", (text or "").strip().lower())


def field_key(entity_name: str, field_name: str) -> tuple[str, str]:
    return entity_name, field_name


def _load_env_file(path: Path) -> bool:
    if not path.exists() or not path.is_file():
        return False

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())
    return True


def _auto_load_env_file() -> Optional[Path]:
    for filename in AUTO_ENV_FILENAMES:
        candidate = Path(filename)
        if _load_env_file(candidate):
            return candidate
    return None


def _looks_like_semantic_model(path: Path) -> bool:
    if path.suffix.lower() != ".json" or not path.is_file():
        return False
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return isinstance(payload, dict) and isinstance(payload.get("entities"), list)


def _discover_semantic_model_path(explicit_path: Optional[str]) -> Optional[str]:
    if explicit_path:
        return explicit_path

    env_path = os.environ.get("SEMANTIC_MODEL_PATH")
    if env_path:
        return env_path

    candidates = [path for path in sorted(Path.cwd().glob("*.json")) if _looks_like_semantic_model(path)]
    if len(candidates) == 1:
        return str(candidates[0])
    return None


@dataclass
class FieldInfo:
    name: str
    expression: Optional[str]
    kind: Optional[str]
    data_type: Optional[str]
    description: Optional[str]
    default_aggregation: Optional[str] = None
    entity_name: Optional[str] = None

    def to_prompt_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "expression": self.expression,
            "kind": self.kind,
            "data_type": self.data_type,
            "default_aggregation": self.default_aggregation,
            "description": self.description,
        }


@dataclass
class EntityInfo:
    name: str
    qualified_name: Optional[str]
    database: Optional[str]
    schema: Optional[str]
    table: Optional[str]
    description: Optional[str]
    fields: list[FieldInfo] = field(default_factory=list)

    def get_field(self, field_name: str) -> Optional[FieldInfo]:
        for field in self.fields:
            if field.name == field_name:
                return field
        return None

    def to_prompt_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "qualified_name": self.qualified_name,
            "description": self.description,
            "fields": [field.to_prompt_dict() for field in self.fields],
        }


class SemanticCatalog:
    def __init__(self, raw_model: dict[str, Any]):
        self.raw_model = raw_model
        self.entities = self._load_entities(raw_model)
        self.relationships = raw_model.get("relationships", [])

    @classmethod
    def from_path(cls, path: Path | str) -> "SemanticCatalog":
        model_path = Path(path)
        with model_path.open("r", encoding="utf-8") as handle:
            return cls(json.load(handle))

    def _load_entities(self, raw_model: dict[str, Any]) -> list[EntityInfo]:
        entities: list[EntityInfo] = []
        for entity_payload in raw_model.get("entities", []):
            base_table = entity_payload.get("base_table", {})
            entity = EntityInfo(
                name=entity_payload.get("name"),
                qualified_name=base_table.get("qualified_name"),
                database=base_table.get("database"),
                schema=base_table.get("schema"),
                table=base_table.get("table"),
                description=entity_payload.get("description"),
                fields=[],
            )
            for field_payload in entity_payload.get("fields", []):
                entity.fields.append(
                    FieldInfo(
                        name=field_payload.get("name"),
                        expression=field_payload.get("expression"),
                        kind=field_payload.get("kind"),
                        data_type=field_payload.get("data_type"),
                        description=field_payload.get("description"),
                        default_aggregation=field_payload.get("default_aggregation"),
                        entity_name=entity.name,
                    )
                )
            entities.append(entity)
        return entities

    def get_entity(self, entity_name: str) -> Optional[EntityInfo]:
        for entity in self.entities:
            if entity.name == entity_name:
                return entity
        return None

    def prompt_context(self) -> dict[str, Any]:
        return {
            "model_name": self.raw_model.get("name"),
            "description": self.raw_model.get("description"),
            "relationships": self.relationships,
            "entities": [entity.to_prompt_dict() for entity in self.entities],
        }

    def prompt_context_for_entities(self, entity_names: list[str]) -> dict[str, Any]:
        chosen = [self.get_entity(name) for name in entity_names]
        return {
            "relationships": self.relationships,
            "entities": [entity.to_prompt_dict() for entity in chosen if entity is not None],
        }

    def field_exists(self, entity_name: str, field_name: str) -> bool:
        entity = self.get_entity(entity_name)
        return entity is not None and entity.get_field(field_name) is not None

    def qualified_names_for_entities(self, entity_names: list[str]) -> set[str]:
        names: set[str] = set()
        for entity_name in entity_names:
            entity = self.get_entity(entity_name)
            if entity and entity.qualified_name:
                names.add(entity.qualified_name)
        return names


class LLMJsonClient(Protocol):
    def generate_json(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        schema: dict[str, Any],
    ) -> dict[str, Any]:
        ...


class OpenAIResponsesClient:
    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        model: str = "gpt-5.4",
        base_url: str = "https://api.openai.com/v1/responses",
        reasoning_effort: Optional[str] = "medium",
        timeout_seconds: int = 120,
    ):
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self.model = model
        self.base_url = base_url
        self.reasoning_effort = reasoning_effort
        self.timeout_seconds = timeout_seconds
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY is not set.")

    def generate_json(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        schema: dict[str, Any],
    ) -> dict[str, Any]:
        payload = {
            "model": self.model,
            "input": [
                self._message("system", system_prompt),
                self._message("user", user_prompt),
            ],
            "text": {
                "format": {
                    "type": "json_schema",
                    "name": schema["name"],
                    "strict": True,
                    "schema": schema["schema"],
                }
            },
        }
        if self.reasoning_effort:
            payload["reasoning"] = {"effort": self.reasoning_effort}

        request = urllib.request.Request(
            self.base_url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                body = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            details = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Responses API request failed: {exc.code} {details}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Responses API request failed: {exc.reason}") from exc

        parsed_body = json.loads(body)
        refusal = self._extract_refusal(parsed_body)
        if refusal:
            raise RuntimeError(f"Model refused the request: {refusal}")

        output_text = self._extract_output_text(parsed_body)
        try:
            return json.loads(output_text)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Model returned non-JSON output: {output_text}") from exc

    def _message(self, role: str, text: str) -> dict[str, Any]:
        return {
            "role": role,
            "content": [
                {
                    "type": "input_text",
                    "text": text,
                }
            ],
        }

    def _extract_refusal(self, response_payload: dict[str, Any]) -> Optional[str]:
        for output_item in response_payload.get("output", []):
            if output_item.get("type") != "message":
                continue
            for content_item in output_item.get("content", []):
                if content_item.get("type") == "refusal":
                    return content_item.get("refusal")
        return None

    def _extract_output_text(self, response_payload: dict[str, Any]) -> str:
        for output_item in response_payload.get("output", []):
            if output_item.get("type") != "message":
                continue
            for content_item in output_item.get("content", []):
                if content_item.get("type") == "output_text":
                    return content_item.get("text", "")
        raise RuntimeError(f"Responses API output did not include output_text: {json_dumps(response_payload)}")


@dataclass
class FieldBinding:
    role: str
    entity_name: str
    field_name: str
    question_phrase: str

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "FieldBinding":
        return cls(
            role=payload["role"],
            entity_name=payload["entity_name"],
            field_name=payload["field_name"],
            question_phrase=payload["question_phrase"],
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "role": self.role,
            "entity_name": self.entity_name,
            "field_name": self.field_name,
            "question_phrase": self.question_phrase,
        }


@dataclass
class PlanningDecision:
    status: str
    reasoning: str
    clarification_question: Optional[str]
    unsupported_reason: Optional[str]
    selected_entities: list[str]
    field_bindings: list[FieldBinding]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "PlanningDecision":
        return cls(
            status=payload["status"],
            reasoning=payload["reasoning"],
            clarification_question=payload.get("clarification_question"),
            unsupported_reason=payload.get("unsupported_reason"),
            selected_entities=list(payload.get("selected_entities", [])),
            field_bindings=[FieldBinding.from_dict(item) for item in payload.get("field_bindings", [])],
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "reasoning": self.reasoning,
            "clarification_question": self.clarification_question,
            "unsupported_reason": self.unsupported_reason,
            "selected_entities": self.selected_entities,
            "field_bindings": [binding.to_dict() for binding in self.field_bindings],
        }


@dataclass
class SqlReference:
    entity_name: str
    field_name: str

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "SqlReference":
        return cls(entity_name=payload["entity_name"], field_name=payload["field_name"])

    def to_dict(self) -> dict[str, Any]:
        return {
            "entity_name": self.entity_name,
            "field_name": self.field_name,
        }


@dataclass
class SqlDraft:
    status: str
    reasoning: str
    clarification_question: Optional[str]
    unsupported_reason: Optional[str]
    sql: Optional[str]
    table_references: list[str]
    referenced_fields: list[SqlReference]
    assumptions: list[str]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "SqlDraft":
        return cls(
            status=payload["status"],
            reasoning=payload["reasoning"],
            clarification_question=payload.get("clarification_question"),
            unsupported_reason=payload.get("unsupported_reason"),
            sql=payload.get("sql"),
            table_references=list(payload.get("table_references", [])),
            referenced_fields=[SqlReference.from_dict(item) for item in payload.get("referenced_fields", [])],
            assumptions=list(payload.get("assumptions", [])),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "reasoning": self.reasoning,
            "clarification_question": self.clarification_question,
            "unsupported_reason": self.unsupported_reason,
            "sql": self.sql,
            "table_references": self.table_references,
            "referenced_fields": [reference.to_dict() for reference in self.referenced_fields],
            "assumptions": self.assumptions,
        }


@dataclass
class SqlPlanResult:
    status: str
    question: str
    sql: Optional[str]
    selected_entities: list[str]
    planning_decision: Optional[PlanningDecision]
    sql_draft: Optional[SqlDraft]
    trace: list[str]
    warnings: list[str]
    clarification_question: Optional[str]
    unsupported_reason: Optional[str]

    @property
    def chosen_entity(self) -> Optional[EntityInfo]:
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "question": self.question,
            "sql": self.sql,
            "selected_entities": self.selected_entities,
            "planning_decision": self.planning_decision.to_dict() if self.planning_decision else None,
            "sql_draft": self.sql_draft.to_dict() if self.sql_draft else None,
            "trace": self.trace,
            "warnings": self.warnings,
            "clarification_question": self.clarification_question,
            "unsupported_reason": self.unsupported_reason,
        }


class SemanticSqlAgent:
    def __init__(
        self,
        catalog: SemanticCatalog,
        llm_client: LLMJsonClient,
        *,
        max_repair_attempts: int = 1,
    ):
        self.catalog = catalog
        self.llm_client = llm_client
        self.max_repair_attempts = max_repair_attempts

    @classmethod
    def from_path(
        cls,
        semantic_model_path: Path | str,
        *,
        llm_client: Optional[LLMJsonClient] = None,
        model: str = "gpt-5.4",
    ) -> "SemanticSqlAgent":
        catalog = SemanticCatalog.from_path(semantic_model_path)
        client = llm_client or OpenAIResponsesClient(model=model)
        return cls(catalog, client)

    def plan(self, question: str) -> SqlPlanResult:
        trace: list[str] = []
        warnings: list[str] = []

        planning_decision = self._run_planning(question=question, trace=trace)
        if planning_decision.status == "needs_clarification":
            return SqlPlanResult(
                status="needs_clarification",
                question=question,
                sql=None,
                selected_entities=planning_decision.selected_entities,
                planning_decision=planning_decision,
                sql_draft=None,
                trace=trace,
                warnings=warnings,
                clarification_question=planning_decision.clarification_question,
                unsupported_reason=None,
            )

        if planning_decision.status == "unsupported":
            return SqlPlanResult(
                status="unsupported",
                question=question,
                sql=None,
                selected_entities=planning_decision.selected_entities,
                planning_decision=planning_decision,
                sql_draft=None,
                trace=trace,
                warnings=warnings,
                clarification_question=None,
                unsupported_reason=planning_decision.unsupported_reason,
            )

        if len(planning_decision.selected_entities) > 1 and not self.catalog.relationships:
            reason = "The semantic model has no relationships, so safe multi-entity SQL cannot be generated."
            trace.append(reason)
            return SqlPlanResult(
                status="unsupported",
                question=question,
                sql=None,
                selected_entities=planning_decision.selected_entities,
                planning_decision=planning_decision,
                sql_draft=None,
                trace=trace,
                warnings=warnings,
                clarification_question=None,
                unsupported_reason=reason,
            )

        sql_draft = self._run_sql_generation(
            question=question,
            planning_decision=planning_decision,
            trace=trace,
        )
        if sql_draft.status == "needs_clarification":
            return SqlPlanResult(
                status="needs_clarification",
                question=question,
                sql=None,
                selected_entities=planning_decision.selected_entities,
                planning_decision=planning_decision,
                sql_draft=sql_draft,
                trace=trace,
                warnings=warnings,
                clarification_question=sql_draft.clarification_question,
                unsupported_reason=None,
            )

        if sql_draft.status == "unsupported":
            return SqlPlanResult(
                status="unsupported",
                question=question,
                sql=None,
                selected_entities=planning_decision.selected_entities,
                planning_decision=planning_decision,
                sql_draft=sql_draft,
                trace=trace,
                warnings=warnings,
                clarification_question=None,
                unsupported_reason=sql_draft.unsupported_reason,
            )

        trace.append("Generated validated SQL using only semantic-model-bound entities and fields.")
        return SqlPlanResult(
            status="ok",
            question=question,
            sql=sql_draft.sql,
            selected_entities=planning_decision.selected_entities,
            planning_decision=planning_decision,
            sql_draft=sql_draft,
            trace=trace,
            warnings=warnings,
            clarification_question=None,
            unsupported_reason=None,
        )

    def generate_sql(self, question: str) -> str:
        result = self.plan(question)
        if result.status != "ok" or not result.sql:
            raise ValueError(json_dumps(result.to_dict()))
        return result.sql

    def _run_planning(self, *, question: str, trace: list[str]) -> PlanningDecision:
        user_prompt = self._planning_prompt(question)
        raw = self.llm_client.generate_json(
            system_prompt=PLANNER_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            schema=PLANNING_SCHEMA,
        )
        trace.append(f"Planner output: {json_dumps(raw)}")

        for attempt in range(self.max_repair_attempts + 1):
            decision = PlanningDecision.from_dict(raw)
            errors = self._validate_planning_decision(decision)
            if not errors:
                return decision
            if attempt >= self.max_repair_attempts:
                raise ValueError("Planner returned invalid bindings: " + "; ".join(errors))

            repair_prompt = self._planning_repair_prompt(question=question, bad_payload=raw, errors=errors)
            raw = self.llm_client.generate_json(
                system_prompt=PLAN_REPAIR_SYSTEM_PROMPT,
                user_prompt=repair_prompt,
                schema=PLANNING_SCHEMA,
            )
            trace.append(f"Planner repair output: {json_dumps(raw)}")

        raise AssertionError("Planner repair loop exhausted unexpectedly.")

    def _run_sql_generation(
        self,
        *,
        question: str,
        planning_decision: PlanningDecision,
        trace: list[str],
    ) -> SqlDraft:
        user_prompt = self._sql_prompt(question, planning_decision)
        raw = self.llm_client.generate_json(
            system_prompt=SQL_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            schema=SQL_SCHEMA,
        )
        trace.append(f"SQL draft output: {json_dumps(raw)}")

        for attempt in range(self.max_repair_attempts + 1):
            draft = SqlDraft.from_dict(raw)
            errors = self._validate_sql_draft(draft, planning_decision)
            if not errors:
                return draft
            if attempt >= self.max_repair_attempts:
                raise ValueError("SQL generator returned invalid output: " + "; ".join(errors))

            repair_prompt = self._sql_repair_prompt(
                question=question,
                planning_decision=planning_decision,
                bad_payload=raw,
                errors=errors,
            )
            raw = self.llm_client.generate_json(
                system_prompt=SQL_REPAIR_SYSTEM_PROMPT,
                user_prompt=repair_prompt,
                schema=SQL_SCHEMA,
            )
            trace.append(f"SQL repair output: {json_dumps(raw)}")

        raise AssertionError("SQL repair loop exhausted unexpectedly.")

    def _planning_prompt(self, question: str) -> str:
        payload = {
            "question": question,
            "semantic_model": self.catalog.prompt_context(),
        }
        return json_dumps(payload)

    def _planning_repair_prompt(self, *, question: str, bad_payload: dict[str, Any], errors: list[str]) -> str:
        payload = {
            "question": question,
            "validation_errors": errors,
            "invalid_output": bad_payload,
            "semantic_model": self.catalog.prompt_context(),
        }
        return json_dumps(payload)

    def _sql_prompt(self, question: str, planning_decision: PlanningDecision) -> str:
        payload = {
            "question": question,
            "validated_plan": planning_decision.to_dict(),
            "allowed_context": self.catalog.prompt_context_for_entities(planning_decision.selected_entities),
        }
        return json_dumps(payload)

    def _sql_repair_prompt(
        self,
        *,
        question: str,
        planning_decision: PlanningDecision,
        bad_payload: dict[str, Any],
        errors: list[str],
    ) -> str:
        payload = {
            "question": question,
            "validation_errors": errors,
            "invalid_sql_output": bad_payload,
            "validated_plan": planning_decision.to_dict(),
            "allowed_context": self.catalog.prompt_context_for_entities(planning_decision.selected_entities),
        }
        return json_dumps(payload)

    def _validate_planning_decision(self, decision: PlanningDecision) -> list[str]:
        errors: list[str] = []

        if decision.status == "ok":
            if not decision.selected_entities:
                errors.append("selected_entities cannot be empty when status is ok")
            for entity_name in decision.selected_entities:
                if not self.catalog.get_entity(entity_name):
                    errors.append(f"unknown entity: {entity_name}")
            if not decision.field_bindings:
                errors.append("field_bindings cannot be empty when status is ok")
            for binding in decision.field_bindings:
                if binding.entity_name not in decision.selected_entities:
                    errors.append(
                        f"binding entity {binding.entity_name} is not present in selected_entities"
                    )
                if not self.catalog.field_exists(binding.entity_name, binding.field_name):
                    errors.append(
                        f"unknown field binding: {binding.entity_name}.{binding.field_name}"
                    )

        if decision.status == "needs_clarification" and not decision.clarification_question:
            errors.append("clarification_question is required when status is needs_clarification")

        if decision.status == "unsupported" and not decision.unsupported_reason:
            errors.append("unsupported_reason is required when status is unsupported")

        return errors

    def _validate_sql_draft(
        self,
        draft: SqlDraft,
        planning_decision: PlanningDecision,
    ) -> list[str]:
        errors: list[str] = []

        if draft.status == "ok":
            if not draft.sql:
                errors.append("sql is required when status is ok")
            else:
                if not READ_ONLY_SQL_PATTERN.search(draft.sql):
                    errors.append("sql must begin with SELECT or WITH")
                if BLOCKED_SQL_PATTERN.search(draft.sql):
                    errors.append("sql contains blocked write/destructive keywords")

            if not draft.table_references:
                errors.append("table_references cannot be empty when status is ok")
            else:
                allowed_tables = self.catalog.qualified_names_for_entities(planning_decision.selected_entities)
                for table_name in draft.table_references:
                    if table_name not in allowed_tables:
                        errors.append(f"table reference is not allowed: {table_name}")

            allowed_fields = {
                field_key(binding.entity_name, binding.field_name)
                for binding in planning_decision.field_bindings
            }
            if not draft.referenced_fields:
                errors.append("referenced_fields cannot be empty when status is ok")
            else:
                for reference in draft.referenced_fields:
                    if not self.catalog.field_exists(reference.entity_name, reference.field_name):
                        errors.append(
                            f"sql references unknown field: {reference.entity_name}.{reference.field_name}"
                        )
                    if field_key(reference.entity_name, reference.field_name) not in allowed_fields:
                        errors.append(
                            f"sql references field outside validated plan: {reference.entity_name}.{reference.field_name}"
                        )

        if draft.status == "needs_clarification" and not draft.clarification_question:
            errors.append("clarification_question is required when status is needs_clarification")

        if draft.status == "unsupported" and not draft.unsupported_reason:
            errors.append("unsupported_reason is required when status is unsupported")

        return errors


def _build_cli() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Light CLI for testing semantic-model-to-SQL generation.")
    parser.add_argument("question", nargs="?", help="Natural-language analytics question")
    parser.add_argument(
        "--semantic-model",
        help="Path to the semantic model JSON payload",
    )
    parser.add_argument(
        "--env-file",
        help="Optional env file that contains OPENAI_API_KEY or other settings",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("OPENAI_MODEL", "gpt-5.4"),
        help="OpenAI model for the Responses API",
    )
    parser.add_argument(
        "--reasoning-effort",
        default=os.environ.get("OPENAI_REASONING_EFFORT", "medium"),
        help="Responses API reasoning effort",
    )
    parser.add_argument(
        "--interactive",
        action="store_true",
        help="Start an interactive prompt instead of running one question and exiting",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print the full JSON result instead of the compact human-readable output",
    )
    parser.add_argument(
        "--show-trace",
        action="store_true",
        help="Include planner and SQL trace output in human-readable mode",
    )
    return parser


def _print_human_result(result: SqlPlanResult, *, show_trace: bool = False) -> None:
    print(f"Status: {result.status}")
    if result.selected_entities:
        print("Entities:", ", ".join(result.selected_entities))

    reasoning_lines: list[str] = []
    if result.planning_decision and result.planning_decision.reasoning:
        reasoning_lines.append(result.planning_decision.reasoning)
    if result.sql_draft and result.sql_draft.reasoning:
        reasoning_lines.append(result.sql_draft.reasoning)
    if reasoning_lines:
        print("Reasoning:")
        for line in reasoning_lines:
            print(f"- {line}")

    if result.status == "ok" and result.sql:
        print("SQL:")
        print(result.sql)
        if result.sql_draft and result.sql_draft.assumptions:
            print("Assumptions:")
            for item in result.sql_draft.assumptions:
                print(f"- {item}")
    elif result.status == "needs_clarification" and result.clarification_question:
        print("Clarification:")
        print(result.clarification_question)
    elif result.status == "unsupported" and result.unsupported_reason:
        print("Unsupported:")
        print(result.unsupported_reason)

    if show_trace and result.trace:
        print("Trace:")
        for line in result.trace:
            print(f"- {line}")


def _run_question(
    agent: SemanticSqlAgent,
    question: str,
    *,
    json_mode: bool,
    show_trace: bool,
) -> None:
    result = agent.plan(question)
    if json_mode:
        print(json_dumps(result.to_dict()))
        return
    _print_human_result(result, show_trace=show_trace)


def _interactive_loop(
    agent: SemanticSqlAgent,
    *,
    json_mode: bool,
    show_trace: bool,
    semantic_model_path: str,
    model: str,
) -> None:
    print("Semantic SQL CLI")
    print(f"Model: {model}")
    print(f"Semantic model: {semantic_model_path}")
    print("Enter a question. Type 'exit' or 'quit' to stop.")
    while True:
        try:
            question = input("> ").strip()
        except EOFError:
            print()
            break

        if not question:
            continue
        if norm(question) in {"exit", "quit"}:
            break

        try:
            _run_question(agent, question, json_mode=json_mode, show_trace=show_trace)
        except Exception as exc:
            print(f"Error: {exc}")
        print()


def main() -> None:
    parser = _build_cli()
    args = parser.parse_args()

    if args.env_file:
        _load_env_file(Path(args.env_file))
    else:
        _auto_load_env_file()

    semantic_model_path = _discover_semantic_model_path(args.semantic_model)
    if not semantic_model_path:
        parser.error(
            "--semantic-model is required unless SEMANTIC_MODEL_PATH is set "
            "or exactly one semantic-model JSON file is present in the current directory."
        )

    client = OpenAIResponsesClient(model=args.model, reasoning_effort=args.reasoning_effort)
    agent = SemanticSqlAgent(SemanticCatalog.from_path(semantic_model_path), client)

    if args.interactive or not args.question:
        _interactive_loop(
            agent,
            json_mode=args.json,
            show_trace=args.show_trace,
            semantic_model_path=semantic_model_path,
            model=args.model,
        )
        return

    _run_question(agent, args.question, json_mode=args.json, show_trace=args.show_trace)


if __name__ == "__main__":
    main()
