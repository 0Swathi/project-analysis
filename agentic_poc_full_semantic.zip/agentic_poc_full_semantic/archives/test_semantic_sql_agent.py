import unittest

from semantic_sql_agent import SemanticCatalog, SemanticSqlAgent


class FakeLLMClient:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def generate_json(self, *, system_prompt, user_prompt, schema):
        self.calls.append(
            {
                "system_prompt": system_prompt,
                "user_prompt": user_prompt,
                "schema_name": schema["name"],
            }
        )
        if not self.responses:
            raise AssertionError("FakeLLMClient ran out of scripted responses.")
        return self.responses.pop(0)


class SemanticSqlAgentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.catalog = SemanticCatalog.from_path("medicare-physician-4t-semantic.payload.json")
        cls.billing_table = "vertex-poc-465616.medicarePhysicianFT.MedicareBillingData"

    def test_ok_single_entity_flow(self) -> None:
        llm = FakeLLMClient(
            [
                {
                    "status": "ok",
                    "reasoning": "The billing fact table contains the measure, time field, and grouping field.",
                    "clarification_question": None,
                    "unsupported_reason": None,
                    "selected_entities": ["MedicareBillingData"],
                    "field_bindings": [
                        {
                            "role": "dimension",
                            "entity_name": "MedicareBillingData",
                            "field_name": "Rndrng_Prvdr_State_Abrvtn",
                            "question_phrase": "state",
                        },
                        {
                            "role": "time",
                            "entity_name": "MedicareBillingData",
                            "field_name": "year",
                            "question_phrase": "2020",
                        },
                        {
                            "role": "metric",
                            "entity_name": "MedicareBillingData",
                            "field_name": "Avg_Mdcr_Pymt_Amt",
                            "question_phrase": "medicare reimbursement",
                        },
                    ],
                },
                {
                    "status": "ok",
                    "reasoning": "Use the validated billing fields only.",
                    "clarification_question": None,
                    "unsupported_reason": None,
                    "sql": (
                        "SELECT `Rndrng_Prvdr_State_Abrvtn` AS state, "
                        "SUM(SAFE_CAST(`Avg_Mdcr_Pymt_Amt` AS NUMERIC)) AS total_payment "
                        f"FROM `{self.billing_table}` "
                        "GROUP BY state"
                    ),
                    "table_references": [self.billing_table],
                    "referenced_fields": [
                        {
                            "entity_name": "MedicareBillingData",
                            "field_name": "Rndrng_Prvdr_State_Abrvtn",
                        },
                        {
                            "entity_name": "MedicareBillingData",
                            "field_name": "Avg_Mdcr_Pymt_Amt",
                        },
                    ],
                    "assumptions": [],
                },
            ]
        )

        agent = SemanticSqlAgent(self.catalog, llm)
        result = agent.plan("by state give me medicare reimbursement for the year 2020")

        self.assertEqual(result.status, "ok")
        self.assertEqual(result.selected_entities, ["MedicareBillingData"])
        self.assertIn("FROM `vertex-poc-465616.medicarePhysicianFT.MedicareBillingData`", result.sql)
        self.assertEqual(len(llm.calls), 2)

    def test_planner_repair_when_initial_binding_is_invalid(self) -> None:
        llm = FakeLLMClient(
            [
                {
                    "status": "ok",
                    "reasoning": "Initial guess.",
                    "clarification_question": None,
                    "unsupported_reason": None,
                    "selected_entities": ["MedicareBillingData"],
                    "field_bindings": [
                        {
                            "role": "metric",
                            "entity_name": "MedicareBillingData",
                            "field_name": "NotARealField",
                            "question_phrase": "payment",
                        }
                    ],
                },
                {
                    "status": "ok",
                    "reasoning": "Repaired to a real field.",
                    "clarification_question": None,
                    "unsupported_reason": None,
                    "selected_entities": ["MedicareBillingData"],
                    "field_bindings": [
                        {
                            "role": "metric",
                            "entity_name": "MedicareBillingData",
                            "field_name": "Avg_Mdcr_Pymt_Amt",
                            "question_phrase": "payment",
                        }
                    ],
                },
                {
                    "status": "ok",
                    "reasoning": "Generate SQL from the repaired plan.",
                    "clarification_question": None,
                    "unsupported_reason": None,
                    "sql": (
                        "SELECT SUM(SAFE_CAST(`Avg_Mdcr_Pymt_Amt` AS NUMERIC)) AS payment_total "
                        f"FROM `{self.billing_table}`"
                    ),
                    "table_references": [self.billing_table],
                    "referenced_fields": [
                        {
                            "entity_name": "MedicareBillingData",
                            "field_name": "Avg_Mdcr_Pymt_Amt",
                        }
                    ],
                    "assumptions": [],
                },
            ]
        )

        agent = SemanticSqlAgent(self.catalog, llm)
        result = agent.plan("total payment")

        self.assertEqual(result.status, "ok")
        self.assertEqual(len(llm.calls), 3)
        self.assertTrue(any("Planner repair output" in line for line in result.trace))

    def test_sql_repair_when_initial_sql_uses_invalid_field(self) -> None:
        llm = FakeLLMClient(
            [
                {
                    "status": "ok",
                    "reasoning": "The billing table matches the question.",
                    "clarification_question": None,
                    "unsupported_reason": None,
                    "selected_entities": ["MedicareBillingData"],
                    "field_bindings": [
                        {
                            "role": "metric",
                            "entity_name": "MedicareBillingData",
                            "field_name": "Avg_Mdcr_Pymt_Amt",
                            "question_phrase": "payment",
                        }
                    ],
                },
                {
                    "status": "ok",
                    "reasoning": "Initial SQL draft.",
                    "clarification_question": None,
                    "unsupported_reason": None,
                    "sql": (
                        "SELECT SUM(SAFE_CAST(`Wrong_Field` AS NUMERIC)) AS payment_total "
                        f"FROM `{self.billing_table}`"
                    ),
                    "table_references": [self.billing_table],
                    "referenced_fields": [
                        {
                            "entity_name": "MedicareBillingData",
                            "field_name": "Wrong_Field",
                        }
                    ],
                    "assumptions": [],
                },
                {
                    "status": "ok",
                    "reasoning": "Repaired SQL draft.",
                    "clarification_question": None,
                    "unsupported_reason": None,
                    "sql": (
                        "SELECT SUM(SAFE_CAST(`Avg_Mdcr_Pymt_Amt` AS NUMERIC)) AS payment_total "
                        f"FROM `{self.billing_table}`"
                    ),
                    "table_references": [self.billing_table],
                    "referenced_fields": [
                        {
                            "entity_name": "MedicareBillingData",
                            "field_name": "Avg_Mdcr_Pymt_Amt",
                        }
                    ],
                    "assumptions": [],
                },
            ]
        )

        agent = SemanticSqlAgent(self.catalog, llm)
        result = agent.plan("total payment")

        self.assertEqual(result.status, "ok")
        self.assertEqual(len(llm.calls), 3)
        self.assertTrue(any("SQL repair output" in line for line in result.trace))

    def test_multi_entity_question_is_rejected_when_model_has_no_relationships(self) -> None:
        llm = FakeLLMClient(
            [
                {
                    "status": "ok",
                    "reasoning": "The question needs billing and provider master data.",
                    "clarification_question": None,
                    "unsupported_reason": None,
                    "selected_entities": ["MedicareBillingData", "npidata"],
                    "field_bindings": [
                        {
                            "role": "metric",
                            "entity_name": "MedicareBillingData",
                            "field_name": "Avg_Mdcr_Pymt_Amt",
                            "question_phrase": "payment",
                        },
                        {
                            "role": "dimension",
                            "entity_name": "npidata",
                            "field_name": "healthcare_provider_taxonomy_code_1",
                            "question_phrase": "specialty",
                        },
                    ],
                }
            ]
        )

        agent = SemanticSqlAgent(self.catalog, llm)
        result = agent.plan("total payment by provider specialty")

        self.assertEqual(result.status, "unsupported")
        self.assertIsNone(result.sql)
        self.assertEqual(len(llm.calls), 1)
        self.assertIn("no relationships", " ".join(result.trace).lower())

    def test_clarification_passthrough(self) -> None:
        llm = FakeLLMClient(
            [
                {
                    "status": "needs_clarification",
                    "reasoning": "The metric is ambiguous.",
                    "clarification_question": "Which payment metric do you want: allowed, paid, or standardized?",
                    "unsupported_reason": None,
                    "selected_entities": [],
                    "field_bindings": [],
                }
            ]
        )

        agent = SemanticSqlAgent(self.catalog, llm)
        result = agent.plan("payment by state")

        self.assertEqual(result.status, "needs_clarification")
        self.assertIsNone(result.sql)
        self.assertEqual(
            result.clarification_question,
            "Which payment metric do you want: allowed, paid, or standardized?",
        )
        self.assertEqual(len(llm.calls), 1)


if __name__ == "__main__":
    unittest.main()
