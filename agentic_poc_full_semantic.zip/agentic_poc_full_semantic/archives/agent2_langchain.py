"""
LangChain agent version of `agent2.py`.

Install dependencies:
  pip install -U langchain langchain-openai
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
from typing import Optional

try:
    from langchain.agents import AgentExecutor, create_tool_calling_agent, tool
    from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
    from langchain_openai import ChatOpenAI
    import tiktoken
except ModuleNotFoundError as exc:
    missing = exc.name or "required package"
    raise SystemExit(
        f"Missing dependency: {missing}. Install with: pip install -U langchain langchain-openai"
    ) from exc


DEFAULT_MODEL = "gpt-5.4"
DEFAULT_QUESTIONS = [
    "by state give me medicare reimbursement for the year 2020",
    "top 10 providers by total payment in 2021",
    "average reimbursement by specialty in 2020",
]
AUTO_ENV_FILENAMES = (".env", "openaikeys.txt")
PROMPT_SUFFIX = "\nYou must finish by calling the submit_sql tool exactly once. Do not answer in plain text."
MODEL_CONTEXT_WINDOWS = {
    "gpt-5.4": 1_050_000,
    "gpt-5.4-2026-03-05": 1_050_000,
    "gpt-5.4-pro": 1_050_000,
}


def load_env_file(path: Path) -> bool:
    if not path.exists() or not path.is_file():
        return False

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())
    return True


def auto_load_env() -> Path | None:
    for filename in AUTO_ENV_FILENAMES:
        candidate = Path(filename)
        if load_env_file(candidate):
            return candidate
    return None


def resolve_payload_path(path_arg: str) -> Path:
    path = Path(path_arg)
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"Semantic model file not found: {path}")
    if path.suffix.lower() != ".json":
        raise ValueError(f"Semantic model file must be JSON: {path}")
    return path


def load_payload(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict) or not isinstance(payload.get("entities"), list):
        raise ValueError(f"{path} is not a valid semantic model payload.")
    return payload


def build_schema_text(payload: dict) -> str:
    entity_blocks: list[str] = []
    for entity in payload.get("entities", []):
        table_name = entity.get("base_table", {}).get("qualified_name") or entity.get("name", "<unknown>")
        description = entity.get("description", "")
        field_lines: list[str] = []
        for field in entity.get("fields", []):
            field_name = field.get("name", "<unknown>")
            data_type = field.get("data_type", "UNKNOWN")
            kind = field.get("kind", "UNKNOWN")
            field_desc = f": {field['description']}" if field.get("description") else ""
            field_lines.append(f"  - {field_name} ({data_type}, {kind}){field_desc}")
        entity_blocks.append(
            f"Table: {table_name}\n"
            f"Description: {description}\n"
            f"Fields:\n" + "\n".join(field_lines)
        )

    return "\n\n".join(entity_blocks)


def build_system_prompt(payload: dict) -> str:
    schema_text = build_schema_text(payload)
    return f"""You are a BigQuery SQL expert. Given a semantic data model and a natural language question, generate a precise BigQuery SQL query.

SEMANTIC MODEL:
{schema_text}

RULES:
1. Use only fully qualified table names from the schema.
2. Use only fields that appear in the schema.
3. Cast STRING fields to FLOAT64 or INT64 before arithmetic or aggregation when needed.
4. For DATE fields, use EXTRACT(YEAR FROM field) for year filtering.
5. When the user asks for a total over an average-like metric, only derive it when a clearly relevant count/volume field exists in the same table.
6. Always include ORDER BY for ranking or grouped results.
7. Return only the final SQL and explanation through the submit_sql tool.
"""


def get_context_window(model_name: str, explicit_context_window: Optional[int]) -> Optional[int]:
    if explicit_context_window is not None:
        return explicit_context_window
    return MODEL_CONTEXT_WINDOWS.get(model_name)


def estimate_tokens(text: str, model_name: str) -> int:
    try:
        encoding = tiktoken.encoding_for_model(model_name)
    except KeyError:
        encoding = tiktoken.get_encoding("o200k_base")
    return len(encoding.encode(text))


def build_context_report(
    *,
    payload: dict,
    question: str,
    model_name: str,
    context_window: Optional[int],
) -> dict[str, Optional[float]]:
    schema_text = build_schema_text(payload)
    system_prompt = build_system_prompt(payload) + PROMPT_SUFFIX
    semantic_layer_tokens = estimate_tokens(schema_text, model_name)
    system_prompt_tokens = estimate_tokens(system_prompt, model_name)
    question_tokens = estimate_tokens(question, model_name)
    estimated_input_tokens = system_prompt_tokens + question_tokens

    remaining_tokens: Optional[int] = None
    semantic_layer_pct: Optional[float] = None
    remaining_pct: Optional[float] = None
    input_pct: Optional[float] = None
    exceeds_window = False
    near_window = False

    if context_window is not None:
        remaining_tokens = context_window - estimated_input_tokens
        semantic_layer_pct = (semantic_layer_tokens / context_window) * 100
        input_pct = (estimated_input_tokens / context_window) * 100
        remaining_pct = (remaining_tokens / context_window) * 100
        exceeds_window = estimated_input_tokens > context_window
        near_window = estimated_input_tokens >= int(context_window * 0.8)

    return {
        "context_window": context_window,
        "semantic_layer_tokens": semantic_layer_tokens,
        "system_prompt_tokens": system_prompt_tokens,
        "question_tokens": question_tokens,
        "estimated_input_tokens": estimated_input_tokens,
        "semantic_layer_pct": semantic_layer_pct,
        "input_pct": input_pct,
        "remaining_tokens": remaining_tokens,
        "remaining_pct": remaining_pct,
        "near_window": near_window,
        "exceeds_window": exceeds_window,
    }


def format_context_report(report: dict[str, Optional[float]]) -> str:
    context_window = report["context_window"]
    if context_window is None:
        return (
            "CONTEXT WINDOW REPORT:\n"
            f"- semantic layer tokens ingested: {report['semantic_layer_tokens']}\n"
            f"- system prompt tokens: {report['system_prompt_tokens']}\n"
            f"- user question tokens: {report['question_tokens']}\n"
            f"- estimated input tokens: {report['estimated_input_tokens']}\n"
            "- context window: unknown\n"
        )

    return (
        "CONTEXT WINDOW REPORT:\n"
        f"- context window: {context_window}\n"
        f"- semantic layer tokens ingested: {report['semantic_layer_tokens']} ({report['semantic_layer_pct']:.2f}% of window)\n"
        f"- system prompt tokens: {report['system_prompt_tokens']}\n"
        f"- user question tokens: {report['question_tokens']}\n"
        f"- estimated input tokens: {report['estimated_input_tokens']} ({report['input_pct']:.2f}% of window)\n"
        f"- estimated remaining tokens: {report['remaining_tokens']} ({report['remaining_pct']:.2f}% remaining)\n"
        f"- near max context window: {'yes' if report['near_window'] else 'no'}\n"
        f"- exceeds context window: {'yes' if report['exceeds_window'] else 'no'}"
    )


def build_agent_input(question: str, report: dict[str, Optional[float]]) -> str:
    return (
        f"{format_context_report(report)}\n\n"
        "Use the semantic layer already provided in the system prompt. "
        "The context report is informational and should help you stay concise if the remaining window is low.\n\n"
        f"USER QUESTION:\n{question}"
    )


def parse_questions_file(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    quoted = re.findall(r'"([^"\n]+)"', text)
    if quoted:
        return quoted

    questions = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        questions.append(line)
    return questions


def get_questions(path: Path | None) -> list[str]:
    if path is None:
        return DEFAULT_QUESTIONS

    questions = parse_questions_file(path)
    if not questions:
        raise ValueError(f"No questions found in {path}.")
    return questions


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate BigQuery SQL from natural language using a LangChain agent.")
    parser.add_argument("--payload", required=True, help="Path to the semantic model payload JSON.")
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"OpenAI model to use. Default: {DEFAULT_MODEL}")
    parser.add_argument(
        "--questions-file",
        help="Optional text file of questions. If omitted, built-in sample questions are used.",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=120,
        help="Model timeout in seconds. Default: 120",
    )
    parser.add_argument(
        "--context-window",
        type=int,
        help="Optional explicit context window override in tokens. If omitted, known model defaults are used when available.",
    )
    return parser


def create_sql_agent(payload: dict, *, model_name: str, timeout_seconds: int) -> AgentExecutor:
    @tool("submit_sql", return_direct=True)
    def submit_sql(sql: str, explanation: str) -> str:
        """Submit the final SQL answer and explanation for the user's question."""
        return json.dumps({"sql": sql, "explanation": explanation})

    llm = ChatOpenAI(
        model=model_name,
        timeout=timeout_seconds,
        reasoning_effort="medium",
        use_responses_api=True,
    )

    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                build_system_prompt(payload) + PROMPT_SUFFIX,
            ),
            ("human", "{input}"),
            MessagesPlaceholder("agent_scratchpad"),
        ]
    )

    tools = [submit_sql]
    runnable_agent = create_tool_calling_agent(llm, tools, prompt)
    return AgentExecutor(agent=runnable_agent, tools=tools, max_iterations=3)


def nl_to_sql(question: str, sql_agent) -> dict[str, str]:
    result = sql_agent.invoke({"input": question})
    output = result.get("output")
    if not isinstance(output, str):
        raise RuntimeError(f"Agent did not return output text: {result}")

    try:
        structured = json.loads(output)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Agent returned non-JSON output: {output}") from exc

    sql = structured.get("sql")
    explanation = structured.get("explanation")
    if not isinstance(sql, str) or not isinstance(explanation, str):
        raise RuntimeError(f"Agent returned an unexpected shape: {structured}")

    return {"sql": sql, "explanation": explanation}


def main() -> None:
    args = build_arg_parser().parse_args()
    auto_load_env()

    payload_path = resolve_payload_path(args.payload)
    payload = load_payload(payload_path)
    questions = get_questions(Path(args.questions_file) if args.questions_file else None)
    context_window = get_context_window(args.model, args.context_window)
    sql_agent = create_sql_agent(payload, model_name=args.model, timeout_seconds=args.timeout)

    for question in questions:
        report = build_context_report(
            payload=payload,
            question=question,
            model_name=args.model,
            context_window=context_window,
        )
        print(f"\n{'-' * 70}")
        print(f"Q: {question}")
        print("-" * 70)
        print(format_context_report(report))
        if report["exceeds_window"]:
            print("\n-> Skipped: estimated input exceeds the model context window.")
            continue

        result = nl_to_sql(build_agent_input(question, report), sql_agent)
        print(result["sql"])
        print(f"\n-> {result['explanation']}")


if __name__ == "__main__":
    main()
