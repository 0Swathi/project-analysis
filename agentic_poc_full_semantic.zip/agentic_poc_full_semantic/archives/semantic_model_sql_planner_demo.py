# Generated from semantic_model_sql_planner_demo.ipynb

# %% [markdown]
# # Semantic Model to SQL Planner Demo
#
# This notebook shows a reusable pipeline for turning a user question into SQL using a semantic model JSON.
#
# It covers:
# - semantic model loading
# - entity and field normalization
# - intent extraction
# - entity scoring
# - field resolution
# - metric planning
# - compact context construction
# - SQL generation
#
# Assumption: the semantic model file already exists at `/mnt/data/medicare-physician-4t-semantic.payload.json`.

# %%
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# %% [markdown]
# ## 1) Load the semantic model

# %%
SEMANTIC_MODEL_PATH = Path('medicare-physician-4t-semantic.payload.json')

with SEMANTIC_MODEL_PATH.open('r', encoding='utf-8') as f:
    semantic_model_raw = json.load(f)

semantic_model_raw.keys()

# %% [markdown]
# ## 2) Normalize the semantic model into Python objects

# %%
def norm(text: Optional[str]) -> str:
    return re.sub(r'\s+', ' ', (text or '').strip().lower())


@dataclass
class FieldInfo:
    name: str
    expression: Optional[str]
    kind: Optional[str]
    data_type: Optional[str]
    description: Optional[str]
    default_aggregation: Optional[str] = None

    @property
    def search_text(self) -> str:
        return ' '.join([
            norm(self.name),
            norm(self.expression),
            norm(self.kind),
            norm(self.data_type),
            norm(self.description),
        ])


@dataclass
class EntityInfo:
    name: str
    qualified_name: Optional[str]
    database: Optional[str]
    schema: Optional[str]
    table: Optional[str]
    description: Optional[str]
    fields: List[FieldInfo] = field(default_factory=list)

    @property
    def search_text(self) -> str:
        parts = [norm(self.name), norm(self.description)]
        parts.extend(f.search_text for f in self.fields)
        return ' '.join(parts)


@dataclass
class RelationshipInfo:
    raw: Dict[str, Any]


class SemanticCatalog:
    def __init__(self, raw_model: Dict[str, Any]):
        self.raw_model = raw_model
        self.entities = self._load_entities(raw_model)
        self.relationships = [RelationshipInfo(r) for r in raw_model.get('relationships', [])]

    def _load_entities(self, raw_model: Dict[str, Any]) -> List[EntityInfo]:
        entities: List[EntityInfo] = []
        for e in raw_model.get('entities', []):
            base_table = e.get('base_table', {})
            fields = [
                FieldInfo(
                    name=f.get('name'),
                    expression=f.get('expression'),
                    kind=f.get('kind'),
                    data_type=f.get('data_type'),
                    description=f.get('description'),
                    default_aggregation=f.get('default_aggregation'),
                )
                for f in e.get('fields', [])
            ]
            entities.append(
                EntityInfo(
                    name=e.get('name'),
                    qualified_name=base_table.get('qualified_name'),
                    database=base_table.get('database'),
                    schema=base_table.get('schema'),
                    table=base_table.get('table'),
                    description=e.get('description'),
                    fields=fields,
                )
            )
        return entities

    def get_entity(self, name: str) -> Optional[EntityInfo]:
        for entity in self.entities:
            if entity.name == name:
                return entity
        return None


catalog = SemanticCatalog(semantic_model_raw)
[(e.name, e.qualified_name) for e in catalog.entities]

# %% [markdown]
# ## 3) Intent parsing
#
# This is intentionally simple and rule-based so it is easy to understand and extend.

# %%
@dataclass
class Intent:
    raw_question: str
    metric_concepts: List[str]
    dimension_concepts: List[str]
    filters: List[Dict[str, Any]]


class IntentParser:
    def parse(self, question: str) -> Intent:
        q = norm(question)

        metric_concepts: List[str] = []
        dimension_concepts: List[str] = []
        filters: List[Dict[str, Any]] = []

        if 'reimbursement' in q or 'payment' in q or 'medicare reimbursement' in q:
            metric_concepts.append('medicare reimbursement')

        if 'state' in q:
            dimension_concepts.append('state')

        year_match = re.search(r'\b(20\d{2}|19\d{2})\b', q)
        if year_match:
            filters.append({'concept': 'year', 'op': '=', 'value': int(year_match.group(1))})

        return Intent(
            raw_question=question,
            metric_concepts=metric_concepts,
            dimension_concepts=dimension_concepts,
            filters=filters,
        )


intent_parser = IntentParser()
intent = intent_parser.parse('by state give me medicare reimbursement for the year 2020')
intent

# %% [markdown]
# ## 4) Entity scoring
#
# This chooses the best table before any SQL generation happens.

# %%
class EntityRanker:
    def score_entity(self, entity: EntityInfo, intent: Intent) -> Dict[str, Any]:
        score = 0
        reasons: List[str] = []
        text_blob = entity.search_text
        entity_name = norm(entity.name)

        fact_words = ['billing', 'fact', 'claim', 'claims', 'payment', 'utilization']
        if any(word in entity_name for word in fact_words) or any(word in norm(entity.description) for word in fact_words):
            score += 20
            reasons.append('looks like a fact/payment table')

        if 'state' in intent.dimension_concepts:
            if any('state' in norm(f.name) for f in entity.fields):
                score += 15
                reasons.append('has state-like field')

        if any(filt['concept'] == 'year' for filt in intent.filters):
            if any(('year' in norm(f.name) or 'date' in norm(f.name) or f.kind == 'time_dimension') for f in entity.fields):
                score += 15
                reasons.append('has time-like field')

        if 'medicare reimbursement' in intent.metric_concepts:
            if any(any(tok in norm(f.name) for tok in ['pymt', 'payment', 'allowed', 'stdzd', 'amt']) for f in entity.fields):
                score += 25
                reasons.append('has payment-like field')

        if any(any(tok in norm(f.name) for tok in ['srvcs', 'services', 'benes', 'count']) for f in entity.fields):
            score += 10
            reasons.append('has volume/count field')

        if any(word in entity_name for word in ['crosswalk', 'taxonomy', 'reference', 'lookup']):
            score -= 20
            reasons.append('penalty: looks like reference/lookup table')

        overlap_terms = ['state', 'year', 'medicare', 'payment', 'reimbursement']
        overlap = sum(1 for term in overlap_terms if term in norm(intent.raw_question) and term in text_blob)
        if overlap:
            score += overlap * 3
            reasons.append(f'question/schema overlap={overlap}')

        return {'entity': entity, 'score': score, 'reasons': reasons}

    def rank(self, catalog: SemanticCatalog, intent: Intent) -> List[Dict[str, Any]]:
        ranked = [self.score_entity(entity, intent) for entity in catalog.entities]
        ranked.sort(key=lambda x: x['score'], reverse=True)
        return ranked


entity_ranker = EntityRanker()
entity_rankings = entity_ranker.rank(catalog, intent)
[(r['entity'].name, r['score'], r['reasons']) for r in entity_rankings]

# %% [markdown]
# ## 5) Field resolution inside the chosen entity

# %%
class FieldResolver:
    def score_field(self, field: FieldInfo, concept: str) -> int:
        text = field.search_text
        score = 0

        if concept == 'state':
            if 'state' in norm(field.name):
                score += 30
            if field.kind == 'dimension':
                score += 5

        elif concept == 'year':
            if 'year' in norm(field.name):
                score += 30
            if field.kind == 'time_dimension':
                score += 10
            if 'date' in text:
                score += 5

        elif concept == 'medicare reimbursement':
            if 'mdcr' in norm(field.name) or 'medicare' in text:
                score += 15
            if 'pymt' in norm(field.name) or 'payment' in text:
                score += 25
            if 'allowed' in norm(field.name):
                score += 8
            if 'stdzd' in norm(field.name) or 'standardized' in text:
                score += 4

        return score

    def best_field_for_concept(self, entity: EntityInfo, concept: str) -> Tuple[Optional[FieldInfo], List[Tuple[str, int]]]:
        scored = [(field, self.score_field(field, concept)) for field in entity.fields]
        scored.sort(key=lambda x: x[1], reverse=True)
        top_preview = [(f.name, s) for f, s in scored[:5]]
        best_field = scored[0][0] if scored and scored[0][1] > 0 else None
        return best_field, top_preview


field_resolver = FieldResolver()
best_entity = entity_rankings[0]['entity']

state_field, state_preview = field_resolver.best_field_for_concept(best_entity, 'state')
year_field, year_preview = field_resolver.best_field_for_concept(best_entity, 'year')
metric_field, metric_preview = field_resolver.best_field_for_concept(best_entity, 'medicare reimbursement')

best_entity.name, state_field.name, year_field.name, metric_field.name

# %% [markdown]
# ## 6) Metric planning
#
# This is where we detect that an average field may need a supporting volume field.

# %%
@dataclass
class MetricPlan:
    metric_field: FieldInfo
    supporting_fields: List[FieldInfo]
    sql_expression: str
    explanation: str


class MetricPlanner:
    def find_supporting_volume_field(self, entity: EntityInfo) -> Optional[FieldInfo]:
        preferred = ['Tot_Srvcs', 'Tot_Benes', 'Tot_Bene_Day_Srvcs']
        by_name = {f.name: f for f in entity.fields}
        for name in preferred:
            if name in by_name:
                return by_name[name]

        for field in entity.fields:
            if any(tok in norm(field.name) for tok in ['srvcs', 'services', 'count', 'benes']):
                return field
        return None

    def build_metric_plan(self, entity: EntityInfo, metric_field: FieldInfo) -> MetricPlan:
        metric_name = metric_field.name
        metric_desc = norm(metric_field.description)

        if metric_name.startswith('Avg_') or 'average' in metric_desc:
            support = self.find_supporting_volume_field(entity)
            if support:
                return MetricPlan(
                    metric_field=metric_field,
                    supporting_fields=[support],
                    sql_expression=(
                        f"SUM(SAFE_CAST({metric_field.name} AS NUMERIC) * "
                        f"SAFE_CAST({support.name} AS NUMERIC))"
                    ),
                    explanation=(
                        f"{metric_field.name} is an average-like field, so estimate total by multiplying "
                        f"it with {support.name} and summing across rows."
                    ),
                )

        return MetricPlan(
            metric_field=metric_field,
            supporting_fields=[],
            sql_expression=f"SUM(SAFE_CAST({metric_field.name} AS NUMERIC))",
            explanation=f"{metric_field.name} is treated as directly summable.",
        )


metric_planner = MetricPlanner()
metric_plan = metric_planner.build_metric_plan(best_entity, metric_field)
metric_plan

# %% [markdown]
# ## 7) Build a compact context packet
#
# This is the small, query-specific context you would pass to an LLM instead of the full JSON.

# %%
class ContextBuilder:
    def build(
        self,
        intent: Intent,
        entity: EntityInfo,
        state_field: FieldInfo,
        year_field: FieldInfo,
        metric_plan: MetricPlan,
    ) -> Dict[str, Any]:
        relevant_fields = [state_field, year_field, metric_plan.metric_field, *metric_plan.supporting_fields]
        deduped = []
        seen = set()
        for field in relevant_fields:
            if field.name not in seen:
                seen.add(field.name)
                deduped.append(field)

        return {
            'question': intent.raw_question,
            'entity': {
                'name': entity.name,
                'qualified_name': entity.qualified_name,
                'description': entity.description,
            },
            'fields': [
                {
                    'name': f.name,
                    'kind': f.kind,
                    'data_type': f.data_type,
                    'description': f.description,
                }
                for f in deduped
            ],
            'metric_plan': {
                'sql_expression': metric_plan.sql_expression,
                'explanation': metric_plan.explanation,
            },
            'filters': intent.filters,
        }


context_builder = ContextBuilder()
context_packet = context_builder.build(intent, best_entity, state_field, year_field, metric_plan)
print(json.dumps(context_packet, indent=2))

# %% [markdown]
# ## 8) Deterministic SQL builder
#
# Even if you later add an LLM, deterministic SQL assembly is a strong baseline.

# %%
class SqlBuilder:
    def build(
        self,
        entity: EntityInfo,
        dimension_field: FieldInfo,
        year_field: FieldInfo,
        metric_plan: MetricPlan,
        year_value: int,
    ) -> str:
        table = entity.qualified_name
        dimension_expr = dimension_field.name
        year_expr = year_field.name
        metric_expr = metric_plan.sql_expression

        sql = f"""
SELECT
  {dimension_expr} AS state,
  {metric_expr} AS total_medicare_reimbursement_{year_value}
FROM `{table}`
WHERE EXTRACT(YEAR FROM {year_expr}) = {year_value}
  AND {dimension_expr} IS NOT NULL
GROUP BY state
ORDER BY total_medicare_reimbursement_{year_value} DESC;
""".strip()
        return sql


sql_builder = SqlBuilder()
year_value = next(f['value'] for f in intent.filters if f['concept'] == 'year')
sql_query = sql_builder.build(best_entity, state_field, year_field, metric_plan, year_value)
print(sql_query)

# %% [markdown]
# ## 9) Wrap everything into a reusable planner

# %%
class SemanticSqlPlanner:
    def __init__(self, catalog: SemanticCatalog):
        self.catalog = catalog
        self.intent_parser = IntentParser()
        self.entity_ranker = EntityRanker()
        self.field_resolver = FieldResolver()
        self.metric_planner = MetricPlanner()
        self.context_builder = ContextBuilder()
        self.sql_builder = SqlBuilder()

    def plan(self, question: str) -> Dict[str, Any]:
        intent = self.intent_parser.parse(question)
        ranked_entities = self.entity_ranker.rank(self.catalog, intent)
        chosen_entity = ranked_entities[0]['entity']

        state_field, _ = self.field_resolver.best_field_for_concept(chosen_entity, 'state')
        year_field, _ = self.field_resolver.best_field_for_concept(chosen_entity, 'year')
        metric_field, _ = self.field_resolver.best_field_for_concept(chosen_entity, 'medicare reimbursement')

        if not state_field or not year_field or not metric_field:
            raise ValueError('Could not resolve one or more required fields.')

        metric_plan = self.metric_planner.build_metric_plan(chosen_entity, metric_field)
        context_packet = self.context_builder.build(intent, chosen_entity, state_field, year_field, metric_plan)

        year_filters = [f for f in intent.filters if f['concept'] == 'year']
        if not year_filters:
            raise ValueError('This demo expects a year filter.')

        sql = self.sql_builder.build(chosen_entity, state_field, year_field, metric_plan, year_filters[0]['value'])

        return {
            'intent': intent,
            'entity_rankings': ranked_entities,
            'chosen_entity': chosen_entity,
            'state_field': state_field,
            'year_field': year_field,
            'metric_field': metric_field,
            'metric_plan': metric_plan,
            'context_packet': context_packet,
            'sql': sql,
        }


planner = SemanticSqlPlanner(catalog)
result = planner.plan('by state give me medicare reimbursement for the year 2020')
print(result['sql'])

# %% [markdown]
# ## 10) Debug and inspection helpers
#
# Useful when you are tuning table selection and metric logic.

# %%
def show_entity_rankings(result: Dict[str, Any]) -> None:
    for rank in result['entity_rankings']:
        entity = rank['entity']
        print(f"Entity: {entity.name} | Score: {rank['score']}")
        for reason in rank['reasons']:
            print(f"  - {reason}")
        print()


def show_selected_fields(result: Dict[str, Any]) -> None:
    print('Chosen entity:', result['chosen_entity'].name)
    print('State field:', result['state_field'].name)
    print('Year field:', result['year_field'].name)
    print('Metric field:', result['metric_field'].name)
    print('Metric plan:', result['metric_plan'].explanation)
    if result['metric_plan'].supporting_fields:
        print('Supporting fields:', [f.name for f in result['metric_plan'].supporting_fields])


show_entity_rankings(result)
show_selected_fields(result)

# %% [markdown]
# ## 11) How to expand this to multi-table planning
#
# Your current semantic model has no explicit relationships, so true join planning is not possible yet.
#
# To support multi-table questions, add relationship metadata like:
#
# ```json
# {
#   "from_entity": "MedicareBillingData",
#   "from_field": "Rndrng_NPI",
#   "to_entity": "npidata",
#   "to_field": "npi",
#   "relationship_type": "many_to_one"
# }
# ```
#
# Then add a join planner that:
# 1. finds candidate fields across entities
# 2. builds an entity graph
# 3. searches for the smallest connected subgraph covering all concepts
# 4. ranks join plans by coverage, number of joins, and grain safety
# 5. generates SQL from the chosen join path

# %%
# Placeholder sketch for future multi-table support

class JoinPlanner:
    def __init__(self, relationships: List[RelationshipInfo]):
        self.relationships = relationships

    def find_join_plan(self, required_entities: List[str]) -> Dict[str, Any]:
        if not self.relationships:
            return {
                'status': 'unavailable',
                'reason': 'No relationships are defined in the semantic model.'
            }
        return {
            'status': 'todo',
            'reason': 'Implement graph search over entity relationships.'
        }


join_planner = JoinPlanner(catalog.relationships)
join_planner.find_join_plan(['MedicareBillingData', 'npidata'])

# %% [markdown]
# ## 12) Final notes
#
# This notebook gives you a reusable baseline for a semantic-model-driven analytical bot.
#
# Recommended next steps:
# - improve the intent parser
# - add a richer synonym dictionary
# - add explicit relationships to the semantic model
# - add validation and repair loops
# - optionally add an LLM only after compact context construction

