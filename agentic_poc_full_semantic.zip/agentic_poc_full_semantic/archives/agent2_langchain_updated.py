"""
LangChain agent version of `agent2.py`.

This intentionally reuses the default semantic-layer discovery and payload
loading logic from `agent2.py` so the two CLIs do not drift.

Install dependencies:
  pip install -U langchain langchain-openai tiktoken
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Optional

try:
    from langchain.agents import AgentExecutor, create_tool_calling_agent, tool
    from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
    from langchain_openai import ChatOpenAI
    import tiktoken
except ModuleNotFoundError as exc:
    missing = exc.name or "required package"
    raise SystemExit(
        f"Missing dependency: {missing}. Install with: pip install -U langchain langchain-openai tiktoken"
    ) from exc

from archives.agent2 import (
    DEFAULT_MODEL,
    auto_load_env,
    build_system_prompt,
    discover_payload_path,
    load_payload,
    resolve_questions,
)


PROMPT_SUFFIX = "\nYou must finish by calling the submit_sql tool exactly once. Do not answer in plain text."
MODEL_CONTEXT_WINDOWS = {
    "gpt-5.4": 1_050_000,
    "gpt-5.4-2026-03-05": 1_050_000,
    "gpt-5.4-pro": 1_050_000,
}


def get_context_window(model_name: str, explicit_context_window: Optional[int]) -> Optional[int]:
    if explicit_context_window is not None:
        return explicit_context_window
    return MODEL_CONTEXT_WINDOWS.get(model_name)


def estimate_tokens(text: str, model_name: str) -> int:
    try:
        encoding = tiktoken.encoding_for_model(model_name)
    except KeyError:
        encoding = tiktoken.get_encoding("o200k_base")
    return len(encoding.encode(text))


def build_context_report(
    *,
    payload: dict,
    question: str,
    model_name: str,
    context_window: Optional[int],
) -> dict[str, Optional[float]]:
    system_prompt = build_system_prompt(payload) + PROMPT_SUFFIX
    semantic_layer_tokens = estimate_tokens(build_system_prompt(payload), model_name)
    system_prompt_tokens = estimate_tokens(system_prompt, model_name)
    question_tokens = estimate_tokens(question, model_name)
    estimated_input_tokens = system_prompt_tokens + question_tokens

    remaining_tokens: Optional[int] = None
    semantic_layer_pct: Optional[float] = None
    remaining_pct: Optional[float] = None
    input_pct: Optional[float] = None
    exceeds_window = False
    near_window = False

    if context_window is not None:
        remaining_tokens = context_window - estimated_input_tokens
        semantic_layer_pct = (semantic_layer_tokens / context_window) * 100
        input_pct = (estimated_input_tokens / context_window) * 100
        remaining_pct = (remaining_tokens / context_window) * 100
        exceeds_window = estimated_input_tokens > context_window
        near_window = estimated_input_tokens >= int(context_window * 0.8)

    return {
        "context_window": context_window,
        "semantic_layer_tokens": semantic_layer_tokens,
        "system_prompt_tokens": system_prompt_tokens,
        "question_tokens": question_tokens,
        "estimated_input_tokens": estimated_input_tokens,
        "semantic_layer_pct": semantic_layer_pct,
        "input_pct": input_pct,
        "remaining_tokens": remaining_tokens,
        "remaining_pct": remaining_pct,
        "near_window": near_window,
        "exceeds_window": exceeds_window,
    }


def format_context_report(report: dict[str, Optional[float]]) -> str:
    context_window = report["context_window"]
    if context_window is None:
        return (
            "CONTEXT WINDOW REPORT:\n"
            f"- semantic layer tokens ingested: {report['semantic_layer_tokens']}\n"
            f"- system prompt tokens: {report['system_prompt_tokens']}\n"
            f"- user question tokens: {report['question_tokens']}\n"
            f"- estimated input tokens: {report['estimated_input_tokens']}\n"
            "- context window: unknown\n"
        )

    return (
        "CONTEXT WINDOW REPORT:\n"
        f"- context window: {context_window}\n"
        f"- semantic layer tokens ingested: {report['semantic_layer_tokens']} ({report['semantic_layer_pct']:.2f}% of window)\n"
        f"- system prompt tokens: {report['system_prompt_tokens']}\n"
        f"- user question tokens: {report['question_tokens']}\n"
        f"- estimated input tokens: {report['estimated_input_tokens']} ({report['input_pct']:.2f}% of window)\n"
        f"- estimated remaining tokens: {report['remaining_tokens']} ({report['remaining_pct']:.2f}% remaining)\n"
        f"- near max context window: {'yes' if report['near_window'] else 'no'}\n"
        f"- exceeds context window: {'yes' if report['exceeds_window'] else 'no'}"
    )


def build_agent_input(question: str, report: dict[str, Optional[float]]) -> str:
    return (
        f"{format_context_report(report)}\n\n"
        "Use the semantic layer already provided in the system prompt. "
        "The context report is informational and should help you stay concise if the remaining window is low.\n\n"
        f"USER QUESTION:\n{question}"
    )


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate BigQuery SQL from natural language using a LangChain agent.",
    )
    parser.add_argument(
        "--payload",
        help="Path to the semantic model payload JSON. Defaults to the same discovery logic as agent2.py.",
    )
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"OpenAI model to use. Default: {DEFAULT_MODEL}")
    parser.add_argument("--question", help="Single natural-language question to convert to SQL.")
    parser.add_argument(
        "--questions-file",
        help="Optional text file of questions to convert to SQL.",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=120,
        help="Model timeout in seconds. Default: 120",
    )
    parser.add_argument(
        "--context-window",
        type=int,
        help="Optional explicit context window override in tokens. If omitted, known model defaults are used when available.",
    )
    parser.add_argument(
        "--print-prompt",
        action="store_true",
        help="Print the exact system prompt and user input sent to the model before execution.",
    )
    return parser


def create_sql_agent(payload: dict, *, model_name: str, timeout_seconds: int) -> AgentExecutor:
    @tool("submit_sql", return_direct=True)
    def submit_sql(sql: str, explanation: str) -> str:
        """Submit the final SQL answer and explanation for the user's question."""
        return json.dumps({"sql": sql, "explanation": explanation})

    llm = ChatOpenAI(
        model=model_name,
        timeout=timeout_seconds,
        reasoning_effort="medium",
        use_responses_api=True,
    )

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", build_system_prompt(payload) + PROMPT_SUFFIX),
            ("human", "{input}"),
            MessagesPlaceholder("agent_scratchpad"),
        ]
    )

    tools = [submit_sql]
    runnable_agent = create_tool_calling_agent(llm, tools, prompt)
    return AgentExecutor(agent=runnable_agent, tools=tools, max_iterations=3)


def nl_to_sql(question: str, sql_agent: AgentExecutor) -> dict[str, str]:
    result = sql_agent.invoke({"input": question})
    output = result.get("output")
    if not isinstance(output, str):
        raise RuntimeError(f"Agent did not return output text: {result}")

    try:
        structured = json.loads(output)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Agent returned non-JSON output: {output}") from exc

    sql = structured.get("sql")
    explanation = structured.get("explanation")
    if not isinstance(sql, str) or not isinstance(explanation, str):
        raise RuntimeError(f"Agent returned an unexpected shape: {structured}")

    return {"sql": sql, "explanation": explanation}


def print_prompt_payload(*, payload_path: Path, payload: dict, question: str, report: dict[str, Optional[float]]) -> None:
    system_prompt = build_system_prompt(payload) + PROMPT_SUFFIX
    user_input = build_agent_input(question, report)
    print("\n" + "=" * 70)
    print("PROMPT PAYLOAD")
    print("=" * 70)
    print(f"Payload file: {payload_path}")
    print("-" * 70)
    print("SYSTEM PROMPT:")
    print(system_prompt)
    print("-" * 70)
    print("USER INPUT:")
    print(user_input)
    print("=" * 70)


def _run_question(
    *,
    question: str,
    payload: dict,
    payload_path: Path,
    model_name: str,
    context_window: Optional[int],
    sql_agent,
    print_prompt: bool,
) -> None:
    report = build_context_report(
        payload=payload,
        question=question,
        model_name=model_name,
        context_window=context_window,
    )
    print(f"\n{'-' * 70}")
    print(f"Q: {question}")
    print("-" * 70)
    print(format_context_report(report))
    if report["exceeds_window"]:
        print("\n-> Skipped: estimated input exceeds the model context window.")
        return

    if print_prompt:
        print_prompt_payload(
            payload_path=payload_path,
            payload=payload,
            question=question,
            report=report,
        )

    result = nl_to_sql(build_agent_input(question, report), sql_agent)
    print(result["sql"])
    print(f"\n-> {result['explanation']}")


def main() -> None:
    args = build_arg_parser().parse_args()
    auto_load_env()

    payload_path = discover_payload_path(args.payload)
    payload = load_payload(payload_path)
    context_window = get_context_window(args.model, args.context_window)
    sql_agent = create_sql_agent(payload, model_name=args.model, timeout_seconds=args.timeout)

    run_kwargs = dict(
        payload=payload,
        payload_path=payload_path,
        model_name=args.model,
        context_window=context_window,
        sql_agent=sql_agent,
        print_prompt=args.print_prompt,
    )

    if args.question or args.questions_file:
        questions = resolve_questions(
            question=args.question,
            questions_file=Path(args.questions_file) if args.questions_file else None,
        )
        for question in questions:
            _run_question(question=question, **run_kwargs)
    else:
        print("Interactive mode — type your question and press Enter. Type 'exit' or Ctrl+C to quit.\n")
        while True:
            try:
                question = input("Ask a question: ").strip()
            except (KeyboardInterrupt, EOFError):
                print("\nBye.")
                break
            if not question:
                continue
            if question.lower() in ("exit", "quit"):
                break
            try:
                _run_question(question=question, **run_kwargs)
            except Exception as exc:
                print(f"Error: {exc}")


if __name__ == "__main__":
    main()
