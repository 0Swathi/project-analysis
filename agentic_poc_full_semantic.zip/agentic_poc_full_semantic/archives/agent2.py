"""
Natural-language -> BigQuery SQL using the OpenAI Responses API.

This version uses only the Python standard library. It auto-loads
`OPENAI_API_KEY` from `.env` or `openaikeys.txt` when present.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


DEFAULT_PAYLOAD_PATH = "medicare-physician-4t-semantic.payload.json"
DEFAULT_MODEL = "gpt-5.4"
AUTO_ENV_FILENAMES = (".env", "openaikeys.txt")

RESPONSE_SCHEMA = {
    "name": "nl_to_sql_result",
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "sql": {"type": "string"},
            "explanation": {"type": "string"},
        },
        "required": ["sql", "explanation"],
    },
}


def load_env_file(path: Path) -> bool:
    if not path.exists() or not path.is_file():
        return False

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())
    return True


def auto_load_env() -> Path | None:
    for filename in AUTO_ENV_FILENAMES:
        candidate = Path(filename)
        if load_env_file(candidate):
            return candidate
    return None


def looks_like_semantic_model(path: Path) -> bool:
    if path.suffix.lower() != ".json" or not path.is_file():
        return False
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return isinstance(payload, dict) and isinstance(payload.get("entities"), list)


def discover_payload_path(explicit_path: str | None) -> Path:
    if explicit_path:
        return Path(explicit_path)

    env_path = os.environ.get("SEMANTIC_MODEL_PATH")
    if env_path:
        return Path(env_path)

    default = Path(DEFAULT_PAYLOAD_PATH)
    if default.exists():
        return default

    candidates = [path for path in sorted(Path.cwd().glob("*.json")) if looks_like_semantic_model(path)]
    if len(candidates) == 1:
        return candidates[0]

    raise FileNotFoundError(
        "Could not determine the semantic model path. Pass --payload or set SEMANTIC_MODEL_PATH."
    )


def load_payload(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict) or not isinstance(payload.get("entities"), list):
        raise ValueError(f"{path} is not a valid semantic model payload.")
    return payload


_NUMERIC_KEYWORDS = ("number", "count", "total", "amount", "avg", "average", "sum", "rate", "percent", "pct", "qty", "quantity")


def _infer_string_numeric_fields(entities: list[dict]) -> list[str]:
    """Returns 'table.field' pairs for STRING fields that are likely numeric based on description."""
    hits = []
    for entity in entities:
        table = entity.get("base_table", {}).get("qualified_name") or entity.get("name", "")
        for field in entity.get("fields", []):
            if field.get("data_type", "").upper() != "STRING":
                continue
            name_lower = field.get("name", "").lower()
            desc_lower = (field.get("description") or "").lower()
            if any(kw in name_lower or kw in desc_lower for kw in _NUMERIC_KEYWORDS):
                hits.append(f"{table}.{field['name']}")
    return hits


def _find_spaced_column_tables(entities: list[dict]) -> list[str]:
    """Returns table names that have at least one column name containing spaces."""
    tables = []
    for entity in entities:
        table = entity.get("base_table", {}).get("qualified_name") or entity.get("name", "")
        if any(" " in (f.get("name") or "") for f in entity.get("fields", [])):
            tables.append(table)
    return tables


def _find_join_candidates(entities: list[dict]) -> list[str]:
    """Returns join hints derived from shared field names/descriptions across tables."""
    from collections import defaultdict
    name_to_tables: dict[str, list[str]] = defaultdict(list)
    for entity in entities:
        table = entity.get("base_table", {}).get("qualified_name") or entity.get("name", "")
        for field in entity.get("fields", []):
            fname = field.get("name", "").strip().upper()
            if fname and field.get("kind") != "measure":
                name_to_tables[fname].append(table)

    hints = []
    for fname, tables in name_to_tables.items():
        if len(tables) >= 2:
            hint = " = ".join(f"{t}.{fname}" for t in tables)
            hints.append(hint)
    return hints


def build_system_prompt(payload: dict[str, Any]) -> str:
    entities = payload.get("entities", [])

    entity_blocks: list[str] = []
    for entity in entities:
        table_name = entity.get("base_table", {}).get("qualified_name") or entity.get("name", "<unknown>")
        description = entity.get("description", "")
        field_lines: list[str] = []
        for field in entity.get("fields", []):
            field_name = field.get("name", "<unknown>")
            data_type = field.get("data_type", "UNKNOWN")
            kind = field.get("kind", "UNKNOWN")
            flags = []
            if " " in field_name:
                flags.append("needs-backtick-quoting")
            if data_type.upper() == "STRING" and any(
                kw in (field.get("description") or "").lower() or kw in field_name.lower()
                for kw in _NUMERIC_KEYWORDS
            ):
                flags.append("likely-numeric-STRING")
            flag_str = f" [{', '.join(flags)}]" if flags else ""
            field_desc = f": {field['description']}" if field.get("description") else ""
            field_lines.append(f"  - {field_name} ({data_type}, {kind}){flag_str}{field_desc}")
        entity_blocks.append(
            f"Table: {table_name}\n"
            f"Description: {description}\n"
            f"Fields:\n" + "\n".join(field_lines)
        )

    schema_text = "\n\n".join(entity_blocks)

    string_numeric_fields = _infer_string_numeric_fields(entities)
    spaced_column_tables = _find_spaced_column_tables(entities)
    join_candidates = _find_join_candidates(entities)

    data_quality_lines = [
        "- Real-world source data may contain NULLs, empty strings, and dirty values in any field.",
        "- String fields used in comparisons or filters may have inconsistent casing — always normalize with LOWER().",
    ]
    if string_numeric_fields:
        data_quality_lines.append(
            f"- The following fields are typed STRING but likely contain numeric values; always use SAFE_CAST before arithmetic or aggregation: {', '.join(string_numeric_fields)}"
        )
    if spaced_column_tables:
        data_quality_lines.append(
            f"- Column names with spaces exist in: {', '.join(spaced_column_tables)}. Always wrap those column names in backticks."
        )

    join_section = ""
    if join_candidates:
        join_lines = "\n".join(f"  - {h}" for h in join_candidates)
        join_section = f"\n--- POTENTIAL JOIN KEYS (shared field names across tables) ---\n{join_lines}\n"

    data_quality_section = "\n".join(data_quality_lines)

    return f"""You are a careful analytics engineer and BigQuery SQL expert. Given a semantic data model and a natural language question, generate ONE correct, production-quality BigQuery SQL query.

SEMANTIC MODEL:
{schema_text}
{join_section}
--- DATA QUALITY NOTES ---
{data_quality_section}

--- CORE RULES ---
1.  Use only fully qualified table names from the schema.
2.  Use only fields that appear in the schema. Do NOT invent tables or columns.
3.  Do NOT use SELECT *. Return only the columns needed to answer the question.
4.  Use clear and meaningful table aliases throughout the query.

--- JOIN AND GRAIN RULES ---
5.  Join tables using the most reliable shared business keys supported by the schema (see POTENTIAL JOIN KEYS above when present).
6.  Preserve the business grain implied by the user query — avoid join fanout and duplicate counting.
7.  If a related table is only needed to filter the base table, prefer EXISTS or a deduplicated subquery rather than a direct join.
8.  Use COUNT(DISTINCT entity_key) for counting business entities when joins could duplicate rows.
9.  Prefer INNER JOIN unless the query clearly requires unmatched rows to be kept; use LEFT JOIN only then.

--- DATA QUALITY RULES ---
10. Fields flagged [likely-numeric-STRING]: always use SAFE_CAST(field AS FLOAT64) before arithmetic or aggregation. Never use plain CAST — it throws on dirty values.
11. Wrap SAFE_CAST results in COALESCE(..., 0) when summing, to treat NULLs as zero.
12. For ratios and percentages, use SAFE_DIVIDE(numerator, denominator) or protect the denominator with NULLIF(..., 0).
13. Treat blank strings as missing: use NULLIF(TRIM(column), '') when avoiding bad matches.
14. String filters: normalize with LOWER(TRIM(column)) = LOWER(TRIM(literal)). Prefer exact = or IN for codes, flags, and identifiers; use LIKE only for genuine partial-match intent.
15. Fields flagged [needs-backtick-quoting]: always wrap the column name in backticks in the SQL.
16. For DATE/TIMESTAMP fields, use EXTRACT(YEAR FROM field) for year filtering.

--- RESULT SHAPING RULES ---
17. If the user asks "how many", return an aggregated count — not detail rows.
18. Apply WHERE filters, GROUP BY, ORDER BY, and LIMIT only when they help answer the question.
19. Always include ORDER BY for ranked or grouped results; add a secondary sort on a unique key for deterministic output.
20. Add LIMIT 1000 to open-ended exploratory queries where no explicit row limit was requested.
21. Use CTEs (WITH clauses) to break down multi-step logic into readable steps.
22. When the time period is ambiguous, include the time field in SELECT and query all available periods.
23. Keep the query as simple as possible while still being correct and robust.
"""


class OpenAIResponsesClient:
    def __init__(
        self,
        *,
        model: str,
        api_key: str | None = None,
        timeout_seconds: int = 120,
    ) -> None:
        self.model = model
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self.timeout_seconds = timeout_seconds
        self.base_url = "https://api.openai.com/v1/responses"
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY is not set.")

    def generate_json(self, *, system_prompt: str, user_prompt: str, schema: dict[str, Any]) -> dict[str, Any]:
        payload = {
            "model": self.model,
            "input": [
                self._message("system", system_prompt),
                self._message("user", user_prompt),
            ],
            "reasoning": {"effort": "medium"},
            "text": {
                "format": {
                    "type": "json_schema",
                    "name": schema["name"],
                    "strict": True,
                    "schema": schema["schema"],
                }
            },
        }

        request = urllib.request.Request(
            self.base_url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                response_body = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            details = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Responses API request failed: {exc.code} {details}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Responses API request failed: {exc.reason}") from exc

        parsed = json.loads(response_body)
        refusal = self._extract_refusal(parsed)
        if refusal:
            raise RuntimeError(f"Model refused the request: {refusal}")

        output_text = self._extract_output_text(parsed)
        try:
            return json.loads(output_text)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Model returned invalid JSON: {output_text}") from exc

    def _message(self, role: str, text: str) -> dict[str, Any]:
        return {
            "role": role,
            "content": [{"type": "input_text", "text": text}],
        }

    def _extract_refusal(self, response_payload: dict[str, Any]) -> str | None:
        for output_item in response_payload.get("output", []):
            if output_item.get("type") != "message":
                continue
            for content_item in output_item.get("content", []):
                if content_item.get("type") == "refusal":
                    return content_item.get("refusal")
        return None

    def _extract_output_text(self, response_payload: dict[str, Any]) -> str:
        for output_item in response_payload.get("output", []):
            if output_item.get("type") != "message":
                continue
            for content_item in output_item.get("content", []):
                if content_item.get("type") == "output_text":
                    return content_item.get("text", "")
        raise RuntimeError(f"Responses API output did not include output_text: {json.dumps(response_payload)}")


def parse_questions_file(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    quoted = re.findall(r'"([^"\n]+)"', text)
    if quoted:
        return quoted

    questions = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        questions.append(line)
    return questions


def resolve_questions(*, question: str | None, questions_file: Path | None) -> list[str]:
    if question and question.strip():
        return [question.strip()]

    if questions_file is not None:
        questions = parse_questions_file(questions_file)
        if not questions:
            raise ValueError(f"No questions found in {questions_file}.")
        return questions

    prompt = input("Ask a question: ").strip()
    if not prompt:
        raise ValueError("A question is required.")
    return [prompt]


def nl_to_sql(question: str, payload: dict[str, Any], client: OpenAIResponsesClient) -> dict[str, str]:
    result = client.generate_json(
        system_prompt=build_system_prompt(payload),
        user_prompt=question,
        schema=RESPONSE_SCHEMA,
    )
    sql = result.get("sql")
    explanation = result.get("explanation")
    if not isinstance(sql, str) or not isinstance(explanation, str):
        raise RuntimeError(f"Model returned an unexpected shape: {result}")
    return {"sql": sql, "explanation": explanation}


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate BigQuery SQL from natural language.")
    parser.add_argument("--payload", help="Path to the semantic model payload JSON.")
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"OpenAI model to use. Default: {DEFAULT_MODEL}")
    parser.add_argument("--question", help="Single natural-language question to convert to SQL.")
    parser.add_argument(
        "--questions-file",
        help="Optional text file of questions to convert to SQL.",
    )
    return parser


def main() -> None:
    args = build_arg_parser().parse_args()
    auto_load_env()

    payload_path = discover_payload_path(args.payload)
    payload = load_payload(payload_path)
    questions = resolve_questions(
        question=args.question,
        questions_file=Path(args.questions_file) if args.questions_file else None,
    )
    client = OpenAIResponsesClient(model=args.model)

    for question in questions:
        print(f"\n{'-' * 70}")
        print(f"Q: {question}")
        print("-" * 70)
        result = nl_to_sql(question, payload, client)
        print(result["sql"])
        print(f"\n-> {result['explanation']}")


if __name__ == "__main__":
    main()
