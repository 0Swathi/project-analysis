# Plan: Fix Follow-up SQL Regression (Structural Drift on Refinement Turns)

## The Problem

### Observed symptom

When a user asks a follow-up like "filter for oncologists" after a complex first query, the
system generates an entirely new SQL query from scratch rather than surgically adding the
filter to the previous query. The result is a structurally different query that changes:

- Taxonomy count logic (slot-counting vs. `COUNT(DISTINCT)`)
- NPI normalization (TRIM-only vs. LOWER + TRIM)
- Crosswalk deduplication (`ARRAY_AGG` vs. `MIN`)
- Ranking population (pre-filtered vs. rank-all-then-filter)

Only the oncologist filter was requested. Everything else changed as a side effect.

### Root cause 1 — SQL generator is stateless

`_invoke_sql_generation` in `backend/app/memory/graph.py` passes three inputs to the SQL
executor on every turn, regardless of whether the turn is a follow-up:

```
question  ← resolved standalone question
semantic_model  ← schema
asset_selection_plan  ← which tables/joins to use
```

The **previous SQL is never passed in**. `active_context.last_sql` exists in session memory
but is never forwarded to the executor. So the SQL LLM re-derives the entire query from
scratch on every turn, making independent implementation decisions each time.

### Root cause 2 — Snapshots are only created at fresh boundaries

In a linear follow-up chain Q1 → Q2 → Q3 → Q4 (all `follow_up` turns), snapshots are only
created when a `fresh` turn displaces the active context. Q1's SQL is never persisted as a
snapshot. By the time Q5 arrives, `active_context.last_sql` holds Q4's SQL and Q1's SQL is
gone.

This means for non-linear branches ("Q5 is a follow-up of Q1, not Q4"), the system has no
SQL to anchor from — even if the memory reasoner correctly classifies Q5 as a
`historical_callback` to Q1, `_find_snapshot` returns `None` and the code silently falls
through to Q4's context.

### Root cause 3 — Snapshot candidate selection is too narrow

`_select_snapshot_candidates` passes only the last 3 snapshots to the memory reasoner. In a
long follow-up chain where even if per-turn snapshots were being created, the memory reasoner
would not see early snapshots (e.g. Q1 in a Q1→Q15 chain). It cannot reason about rewinding
to a turn it cannot see.

---

## How to Resolve It

### Fix 1 — Thread prior SQL into the SQL generator for follow-up turns

For `follow_up` and `historical_callback` turns, pass the relevant prior SQL as an explicit
input to `_invoke_sql_generation`. The SQL executor uses it as an anchor and applies only the
described delta, preserving all other structural decisions from the prior query.

Which SQL to use as anchor:

| `turn_type`          | Anchor SQL source                                      |
|----------------------|--------------------------------------------------------|
| `fresh`              | None — generate from scratch (current behavior)        |
| `follow_up`          | `session.active_context.last_sql`                      |
| `historical_callback`| `target_snapshot.last_sql` (resolved via `target_snapshot_id`) |

For Q1 → Q10 (linear follow-up chain):
- Q2 gets Q1's SQL as anchor
- Q3 gets Q2's SQL as anchor (which already embeds Q2's change on top of Q1)
- Q10 gets Q9's SQL as anchor (which already embeds all Q2–Q9 changes)

Accumulated changes are preserved naturally because each turn builds on the prior SQL output,
not on a reconstructed intent.

### Fix 2 — Add a "SQL editing" mode to `SqlPromptBuilder`

Currently the prompt builder has two modes:
- **Unconstrained** — full schema, generate from scratch
- **Grounded** — narrowed schema + asset plan, generate from scratch

Add a third mode: **Grounded-with-prior-SQL**.

In this mode the system prompt says:
> "Here is the SQL from the previous turn. Apply only the described change. Preserve all
> other aspects of the query — table aliases, CTE structure, normalization patterns, join
> logic, NPI handling."

Use `semantic_change_request` from the memory reasoner as the change description (it is
already structured as `filters_to_add`, `filters_to_replace`, `grouping_changes`,
`measure_change`, `time_scope_change`, `ranking_change`). Do **not** use the expanded
`resolved_question` alone — it restates everything and causes the LLM to re-derive rather
than patch.

Mode selection logic:
```
prior_sql is None  →  unconstrained or grounded (current behavior)
prior_sql present  →  grounded-with-prior-sql
```

### Fix 3 — Snapshot after every SQL-generating turn, not just at fresh boundaries

Change snapshot creation in `_update_session_memory` to also capture the current active
context **before it is overwritten on every follow-up turn that produces SQL**.

This means Q1's state is persisted when Q2 runs, Q2's state when Q3 runs, and so on. Every
prior turn becomes addressable by `historical_callback` via `target_snapshot_id`. No new
mechanism is needed — the existing snapshot rewind logic handles it.

### Fix 4 — Smarter snapshot candidate selection

Change `_select_snapshot_candidates` to include:
- The **oldest** snapshot (so early turns in long chains remain reachable)
- The **most recent** N-1 snapshots

This ensures the memory reasoner can always reason about returning to the earliest state in
the session, even after many follow-up turns.

---

## Implementation

### Files to change

| File | What changes |
|------|-------------|
| `backend/app/memory/graph.py` | 4 changes — see below |
| `backend/app/prompts/sql_prompt_builder.py` | Add grounded-with-prior-sql mode |
| `backend/app/services/sql_generation_service.py` (or wherever `SqlExecutor.execute` is implemented) | Accept `prior_sql` param |
| `backend/app/memory/graph.py` — `SqlExecutor` protocol | Add `prior_sql: str \| None` to signature |

### graph.py — Change 1: `_select_snapshot_candidates`

Current: returns last `max_candidate_snapshots` (= 3) snapshots.

Change: return the **oldest** snapshot + the last `max_candidate_snapshots - 1` snapshots,
deduplicated. If there is only one snapshot it appears once.

```python
# Pseudocode
oldest = session.snapshots[:1]
recent = session.snapshots[-(self.max_candidate_snapshots - 1):]
candidates = deduplicate(oldest + recent)
```

### graph.py — Change 2: `_update_session_memory` — per-turn snapshot

Before overwriting `active_context` on a follow-up turn that produced SQL, snapshot the
current active context:

```python
# Add this block before active_context is resolved for follow-up turns
if (
    decision.turn_type == "follow_up"
    and previous_active_context is not None
    and state.get("sql_result") is not None  # only snapshot if SQL was produced
):
    per_turn_snapshot = _snapshot_from_active_context(
        previous_active_context,
        created_at_turn=session.turn_index,
        snapshot_index=len(session.snapshots) + 1,
    )
    if per_turn_snapshot is not None:
        session.snapshots.append(per_turn_snapshot)
```

### graph.py — Change 3: `_select_assets` — pass `turn_type` anchor hint

No change needed — the asset selector already receives `turn_type` and `operation_type`.
The asset plan may add new tables required by the follow-up change (e.g. a new join for the
oncologist filter). This still works correctly.

### graph.py — Change 4: `_invoke_sql_generation` — pass prior SQL

```python
def _invoke_sql_generation(self, state: MemoryGraphState) -> MemoryGraphState:
    decision = state["reasoner_output"]
    prior_sql = self._resolve_prior_sql(state, decision)

    sql_result = self.sql_executor.execute(
        question=state["resolved_question"] or state["incoming_message"],
        semantic_model=state.get("projected_semantic_model") or state["semantic_model"],
        asset_selection_plan=state.get("asset_selection_plan"),
        prior_sql=prior_sql,
        semantic_change_request=decision.semantic_change_request if prior_sql else None,
        model=state.get("model"),
        debug=state.get("debug", False),
    )
    ...

def _resolve_prior_sql(self, state: MemoryGraphState, decision: ReasonerDecision) -> str | None:
    turn_type = decision.turn_type
    if turn_type == "fresh":
        return None
    if turn_type == "follow_up":
        active = state["session"].active_context
        return active.last_sql if active else None
    if turn_type == "historical_callback":
        snapshot = _find_snapshot(state["session"], decision.target_snapshot_id)
        return snapshot.last_sql if snapshot else None
    return None
```

### `SqlPromptBuilder` — new method `build_followup_system_prompt`

```python
def build_followup_system_prompt(
    self,
    semantic_model: SemanticModel,
    asset_selection_plan: AssetSelectionPlan | None,
    prior_sql: str,
    semantic_change_request: ...,
) -> str:
    # Render prior SQL block
    # Render change request as structured bullet list
    # Render narrowed schema (same as grounded mode)
    # System instruction: "Apply only the described change. Preserve everything else."
```

Mode selection in `build_system_prompt`:

```python
def build_system_prompt(self, semantic_model, asset_selection_plan=None, prior_sql=None, ...):
    if prior_sql:
        return self._build_followup_system_prompt(...)
    if _has_grounded_plan(asset_selection_plan):
        return self._build_grounded_system_prompt(...)
    return self._build_unconstrained_system_prompt(...)
```

### `SqlExecutor` protocol — add `prior_sql` and `semantic_change_request`

```python
class SqlExecutor(Protocol):
    def execute(
        self,
        *,
        question: str,
        semantic_model: dict[str, Any],
        asset_selection_plan: AssetSelectionPlan | None = None,
        prior_sql: str | None = None,
        semantic_change_request: ... | None = None,
        model: str | None = None,
        debug: bool = False,
    ) -> GenerateSqlResponse: ...
```

---

## Behaviour After the Fix

| Scenario | Before fix | After fix |
|----------|-----------|-----------|
| Q1 (fresh) | Generates from scratch | Generates from scratch (unchanged) |
| Q2 = follow-up of Q1 | Regenerates everything | Anchors to Q1 SQL, applies delta only |
| Q5 = follow-up of Q4 (linear chain) | Regenerates everything | Anchors to Q4 SQL |
| Q5 = rewind to Q1 (historical_callback) | No snapshot → falls through to Q4 SQL | Q1 snapshotted per-turn → anchors to Q1 SQL |
| Q10 in long chain, early snapshot pruned | N/A | Oldest snapshot kept in candidates, Q1 still reachable |

---

## What This Does NOT Change

- The memory reasoner classification logic (`fresh` / `follow_up` / `historical_callback`)
- The asset selector — it still runs on every turn and may add tables needed by the change
- The `SqlPlanValidator` — it still enforces that generated SQL stays within selected assets
- The stateless `/api/v1/sql/generate` endpoint — no prior SQL concept, unchanged
- Session memory bounds (20 messages, 10 snapshots) — snapshot count grows faster but
  bounded by the same cap; oldest snapshots roll off naturally

---

# Plan: Fix Follow-up Resolver Misclassification (Fresh Questions Classified as Follow-ups)

## The Problem

### Observed symptom

Self-contained, standalone questions are sometimes classified as `follow_up` by the memory
reasoner even when they have no linguistic or semantic connection to the prior turn. This
causes the system to:

- Expand the `resolved_question` by injecting prior-turn context the user never referenced
- Pass `use_active_context = True` into the asset selector, biasing table/join selection
  toward the previous topic
- Thread stale filters, groupings, or metrics from the active context into the new query

The result is a query that answers a hybrid of what the user just asked and what they asked
before.

### Root cause 1 — `fresh` and `follow_up` are defined vaguely with no concrete signals

The system prompt ([`backend/app/prompts/memory_reasoner_prompt.py`](backend/app/prompts/memory_reasoner_prompt.py))
defines the three turn types as:

> `fresh`: a new topic or self-contained new request
> `follow_up`: a continuation/modification of the active context

There are no concrete linguistic criteria. The LLM must infer what "self-contained" means.
When the active context and the new question share the same dataset or table family (which is
common — users stay in the same domain), the LLM may decide the context "fits" and classify
as `follow_up` even though the user asked an entirely different question.

### Root cause 2 — No tie-breaker rule; implicit bias toward `follow_up`

Rule 1 of the system prompt says:
> "Prefer the active context only when it clearly fits the current message."

There is no counterpart rule: *"When the message is self-contained and could stand alone
without prior context, default to `fresh`."* Because the full `active_context` dump is always
visible in the user prompt, the LLM is tempted to find a relationship and classify as
`follow_up`. Ambiguous cases resolve in the wrong direction.

### Root cause 3 — `resolved_question` requirement incentivises `follow_up`

Rule 4 of the system prompt:
> "resolved_question must be a complete standalone user request when clarification is not
> required."

For a `follow_up` turn the resolved question incorporates prior context and reads as more
"complete." For a `fresh` turn it is just the user's message rephrased. The LLM may
unconsciously classify as `follow_up` to justify enriching the resolved question with context
— because a fuller question feels more faithful to rule 4.

### Root cause 4 — No explicit linguistic signals listed for follow-up detection

The clearest indicator that a message is a `follow_up` is that it *refers back* to the prior
turn through:
- **Pronouns**: "them", "it", "those", "that", "they"
- **Contextual modifiers**: "also", "instead", "additionally", "too", "now", "just",
  "filter that", "break that down", "do the same for"
- **Implicit references**: "from the previous query", "in that result", "among those"

A message with none of these signals is almost always a new standalone question. The prompt
never states this rule, so the LLM derives it inconsistently.

### Root cause 5 — `active_context` has no staleness signal

The user prompt always sends the full `active_context` dump via `model_dump()`. The LLM
cannot tell whether this context is 1 turn old or 10 turns old. A context from many turns
ago about a vaguely related topic can still "fit" a new self-contained question if the tables
overlap. The `ActiveContext` model has `last_turn_type` but no `last_updated_turn_index` and
no timestamp — the reasoner has no basis to discount stale context.

---

## How to Resolve It

### Fix 1 — Add explicit linguistic classification criteria to the system prompt

Replace the vague turn-type descriptions with concrete decision rules:

**Classify as `follow_up` when the message contains any of:**
- Pronouns referring to prior results ("them", "it", "those", "that", "they")
- Additive or replacement modifiers ("also", "instead", "additionally", "filter that",
  "break that down", "do the same for", "now do it by")
- Implicit references that only make sense in the context of the prior turn

**Classify as `fresh` when the message:**
- Contains none of the above signals AND
- Introduces an entity, metric, table, or analytical intent not present in the active context
- OR could be submitted as a first question to a new session and make complete sense

**Tie-breaker:** When genuinely ambiguous between `fresh` and `follow_up`, default to
`fresh`. The cost of incorrectly starting fresh (user re-specifies context) is lower than
incorrectly inheriting stale context (user gets a contaminated answer with no indication of
why).

### Fix 2 — Add staleness-aware context discounting to the system prompt

Add a rule: "If `active_context.last_updated_turn_index` is more than 3 turns behind the
current `turn_index`, treat the active context as background reference only — do not classify
the turn as `follow_up` solely because the tables overlap."

This requires `last_updated_turn_index` to be stored on `ActiveContext` (see implementation
below), which gives the LLM a concrete age signal rather than forcing it to guess.

### Fix 3 — Clarify `resolved_question` expectations per turn type

Add explicit instructions to the system prompt:
- For `fresh`: "resolved_question should be the user's message rephrased for clarity, with
  no injected context from the active session."
- For `follow_up`: "resolved_question should be the user's message expanded into a standalone
  question by incorporating the minimal necessary context from the active session."

This removes the implicit incentive to classify as `follow_up` to produce a richer
resolved_question.

---

## Implementation

### Files to change

| File | What changes |
|------|-------------|
| `backend/app/prompts/memory_reasoner_prompt.py` | Rewrite system prompt rules (main fix) |
| `backend/app/memory/state.py` | Add `last_updated_turn_index` to `ActiveContext` |
| `backend/app/memory/graph.py` | Set `last_updated_turn_index` when active context is updated |

### `memory_reasoner_prompt.py` — Rewrite system prompt rules

Replace the current rules block with:

```
Rules:
1.  Classify as follow_up ONLY when the message contains explicit back-references to the
    prior turn: pronouns (it, them, those, that, they), contextual modifiers (also, instead,
    additionally, filter that, break that down, now do it by), or phrases that are
    semantically incomplete without the prior context.

2.  Classify as fresh when the message contains none of the above signals AND introduces a
    new entity, metric, table, or analytical intent — or when it could stand alone as a
    first question in a new session.

3.  Tie-breaker: when genuinely ambiguous between fresh and follow_up, prefer fresh. The
    cost of incorrectly starting fresh is lower than incorrectly inheriting stale context.

4.  Classify as historical_callback only when the message explicitly requests a return to
    an earlier topic captured in a snapshot (e.g. "go back to...", "return to the earlier
    question about...").

5.  If active_context.last_updated_turn_index is present and more than 3 turns behind the
    current turn_index, treat the active context as background reference only — do not
    classify as follow_up solely because the tables or domain overlap.

6.  Only set clarification_required=true if the ambiguity changes which table or metric is
    used AND no reasonable default can be inferred. Prefer resolving with a sensible
    assumption over asking.

7.  resolved_question rules by turn type:
    - fresh: rephrase the user's message for clarity only. Do NOT inject active context.
    - follow_up: expand into a standalone question using the minimal necessary context.
    - historical_callback: expand using the target snapshot's context.

8.  operation_type must reflect the best semantic action for this turn.

9.  semantic_change_request must describe business-intent changes, not SQL syntax. Use
    filters_to_add for additive refinements, filters_to_replace when replacing an old
    filter, time_scope_change for time changes, grouping_changes for breakdown changes,
    measure_change for metric changes, ranking_change for top/bottom/rank intents.

10. Keep state_patch as a minimal legacy compatibility patch. Return null for fields not
    being changed.

11. When updating state_patch.filters, return it as a list of {key, value} objects.

12. Do not generate SQL. Do not answer the user's business question.

13. Return only structured output matching the provided schema.
```

### `state.py` — Add `last_updated_turn_index` to `ActiveContext`

```python
class ActiveContext(BaseModel):
    ...
    last_updated_turn_index: int | None = None   # add this field
    ...
```

### `graph.py` — Set `last_updated_turn_index` when active context is written

In `_update_session_memory`, after `active_context` is resolved and before it is saved to
the session, set the turn index:

```python
if active_context is not None:
    active_context.last_updated_turn_index = turn_index
session.active_context = active_context
```

The `MemoryReasonerPromptBuilder.build_user_prompt` already calls
`session.active_context.model_dump(mode="json")`, so `last_updated_turn_index` will appear
in the prompt automatically once it is on the model — no changes needed to the prompt
builder itself.

---

## Behaviour After the Fix

| Scenario | Before fix | After fix |
|----------|-----------|-----------|
| Fully self-contained new question (no pronouns/modifiers) | Sometimes `follow_up` | Always `fresh` |
| "Filter that for oncologists" (pronoun reference) | `follow_up` (correct) | `follow_up` (correct, now explicit) |
| Same domain, different question, 1 turn ago | Sometimes `follow_up` | `fresh` (no back-reference signals) |
| Same domain, active context 8 turns stale | `follow_up` (stale context inherited) | `fresh` (staleness rule discounts context) |
| "Go back to the earlier billing question" | `historical_callback` (correct) | `historical_callback` (correct, unchanged) |
| "Now break it down by state" (contextual modifier) | `follow_up` (correct) | `follow_up` (correct, now rule-based) |

---

## What This Does NOT Change

- The `follow_up` → `historical_callback` rewind logic in `graph.py`
- The asset selector — classification feeds into it but its own logic is unchanged
- The snapshot creation and candidate selection fixes from the SQL regression plan above
- The stateless `/api/v1/sql/generate` endpoint
- `SessionMemory` bounds
