from __future__ import annotations

import json
import os
from collections.abc import Generator
from typing import Any

import requests


DEFAULT_BACKEND_API_BASE_URL = "http://localhost:8000"


class BackendApiError(RuntimeError):
    pass


def get_backend_api_base_url() -> str:
    return os.getenv("BACKEND_API_BASE_URL", DEFAULT_BACKEND_API_BASE_URL).rstrip("/")


def validate_semantic_model(
    *,
    semantic_model: dict[str, Any],
    base_url: str,
    timeout_seconds: int = 120,
) -> dict[str, Any]:
    response = requests.post(
        f"{base_url}/api/v1/semantic-models/validate",
        json={"semantic_model": semantic_model},
        timeout=timeout_seconds,
    )
    return _parse_response(response)


def generate_sql(
    *,
    question: str,
    semantic_model: dict[str, Any],
    model: str,
    debug: bool,
    base_url: str,
    timeout_seconds: int = 120,
) -> dict[str, Any]:
    response = requests.post(
        f"{base_url}/api/v1/sql/generate",
        json={
            "question": question,
            "semantic_model": semantic_model,
            "model": model,
            "debug": debug,
        },
        timeout=timeout_seconds,
    )
    return _parse_response(response)


def chat_turn(
    *,
    session_id: str,
    message: str,
    semantic_model: dict[str, Any],
    semantic_model_key: str | None,
    model: str | None,
    debug: bool,
    base_url: str,
    memory_model: str | None = None,
    timeout_seconds: int = 300,
) -> dict[str, Any]:
    response = requests.post(
        f"{base_url}/api/v1/chat/turn",
        json={
            "session_id": session_id,
            "message": message,
            "semantic_model": semantic_model,
            "semantic_model_key": semantic_model_key,
            "model": model,
            "memory_model": memory_model,
            "debug": debug,
        },
        timeout=timeout_seconds,
    )
    return _parse_response(response)


def chat_turn_stream(
    *,
    session_id: str,
    message: str,
    semantic_model: dict[str, Any],
    semantic_model_key: str | None,
    model: str | None,
    debug: bool,
    base_url: str,
    memory_model: str | None = None,
    timeout_seconds: int = 300,
) -> Generator[dict[str, Any], None, None]:
    response = requests.post(
        f"{base_url}/api/v1/chat/turn/stream",
        json={
            "session_id": session_id,
            "message": message,
            "semantic_model": semantic_model,
            "semantic_model_key": semantic_model_key,
            "model": model,
            "memory_model": memory_model,
            "debug": debug,
        },
        stream=True,
        timeout=timeout_seconds,
    )
    if not response.ok:
        try:
            payload = response.json()
            error_msg = (
                (payload.get("error") or {}).get("message")
                or f"Request failed with status {response.status_code}."
            )
        except ValueError:
            error_msg = f"Request failed with status {response.status_code}."
        raise BackendApiError(error_msg)

    for line in response.iter_lines(decode_unicode=True):
        if not line or not line.startswith("data: "):
            continue
        try:
            yield json.loads(line[len("data: "):])
        except json.JSONDecodeError:
            continue


def _parse_response(response: requests.Response) -> dict[str, Any]:
    try:
        payload = response.json()
    except ValueError as exc:
        raise BackendApiError(
            f"Backend returned a non-JSON response with status {response.status_code}."
        ) from exc

    if response.ok:
        return payload

    error = payload.get("error", {}) if isinstance(payload, dict) else {}
    message = error.get("message") or f"Request failed with status {response.status_code}."
    raise BackendApiError(message)
