from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
from typing import Any
import uuid

import streamlit as st

if not __package__:
    FRONTEND_DIR = Path(__file__).resolve().parent
    if str(FRONTEND_DIR) not in sys.path:
        sys.path.insert(0, str(FRONTEND_DIR))

if __package__:
    from frontend.api_client import (
        BackendApiError,
        chat_turn,
        chat_turn_stream,
        get_backend_api_base_url,
        validate_semantic_model,
    )
    from frontend.storage import (
        list_saved_semantic_model_paths,
        save_semantic_model_upload,
    )
else:
    from api_client import (
        BackendApiError,
        chat_turn,
        chat_turn_stream,
        get_backend_api_base_url,
        validate_semantic_model,
    )
    from storage import (
        list_saved_semantic_model_paths,
        save_semantic_model_upload,
    )


DEFAULT_MODEL = "gpt-5.4"
FALLBACK_SEMANTIC_MODEL = json.dumps(
    {
        "dataset_name": "demo_dataset",
        "dataset_description": "Provider registry demo",
        "tables": [
            {
                "table_name": "providers",
                "table_description": "Provider master data",
                "fields": [
                    {
                        "name": "entity_type_code",
                        "description": "Entity type code for the provider",
                    },
                    {
                        "name": "provider_state",
                        "description": "State for the provider mailing address",
                    },
                ],
            }
        ],
    },
    indent=2,
)
DEFAULT_SEMANTIC_MODEL_PATH = (
    Path(__file__).resolve().parents[1]
    / "archives"
    / "medicare-physician-4t-semantic.payload.json"
)
BUILTIN_MODEL_KEY = "__builtin_demo__"
DEFAULT_ARCHIVE_MODEL_KEY = "__default_archive__"


def main() -> None:
    st.set_page_config(
        page_title="Semantic SQL Workbench",
        page_icon=":speech_balloon:",
        layout="wide",
    )
    _bootstrap_state()
    semantic_model_options = get_semantic_model_options()
    option_map = {option["key"]: option for option in semantic_model_options}
    _ensure_selected_semantic_model_key(option_map)

    with st.sidebar:
        render_sidebar(option_map)

    render_chat_panel()


def render_sidebar(option_map: dict[str, dict[str, str]]) -> None:
    st.title("SQL Workbench")

    semantic_model_keys = list(option_map)
    selected_semantic_model_key = st.selectbox(
        "Semantic model",
        options=semantic_model_keys,
        index=semantic_model_keys.index(st.session_state.selected_semantic_model_key),
        format_func=lambda key: option_map[key]["label"],
    )
    if selected_semantic_model_key != st.session_state.selected_semantic_model_key:
        st.session_state.selected_semantic_model_key = selected_semantic_model_key
        st.session_state.loaded_semantic_model_key = None
    try:
        _load_selected_semantic_model(option_map)
    except ValueError as exc:
        st.error(str(exc))

    uploaded_file = st.file_uploader(
        "Upload semantic model",
        type=["json"],
        accept_multiple_files=False,
    )
    if uploaded_file is not None:
        try:
            saved_path = _persist_uploaded_semantic_model(
                filename=uploaded_file.name,
                payload=uploaded_file.getvalue(),
            )
            st.session_state.selected_semantic_model_key = str(saved_path.resolve())
            st.session_state.loaded_semantic_model_key = None
            st.success(f"Saved {saved_path.name}")
            st.rerun()
        except ValueError as exc:
            st.error(str(exc))

    selected_option = option_map[st.session_state.selected_semantic_model_key]
    st.caption(f"Using {selected_option['label']}")
    st.caption("Uploaded semantic models are saved in data/semantic-models/.")

    if st.button("Check selected model", use_container_width=True):
        try:
            semantic_model = parse_semantic_model(st.session_state.semantic_model_text)
            st.session_state.validation_result = validate_semantic_model(
                semantic_model=semantic_model,
                base_url=st.session_state.backend_api_base_url,
            )
        except (BackendApiError, ValueError) as exc:
            st.session_state.validation_result = {
                "valid": False,
                "warnings": [],
                "errors": [str(exc)],
            }

    validation_result = st.session_state.validation_result
    if validation_result:
        if validation_result.get("valid"):
            st.success("Semantic model is valid.")
        else:
            st.error("Semantic model needs fixes.")

        summary = validation_result.get("summary")
        if summary:
            st.caption(
                f"{summary['table_count']} tables, {summary['field_count']} fields, {summary['relationship_count']} relationships"
            )

        for warning in validation_result.get("warnings", []):
            st.warning(warning)
        for error in validation_result.get("errors", []):
            st.error(error)

    st.divider()

    st.text_input(
        "Model",
        key="model_name",
        help="Model name sent to the backend chat endpoint.",
    )
    st.checkbox(
        "Include debug trace",
        key="debug_enabled",
    )
    backend_api_base_url = st.text_input(
        "Backend API URL",
        value=st.session_state.backend_api_base_url,
        help="FastAPI base URL used by the Streamlit UI.",
    ).rstrip("/")
    st.session_state.backend_api_base_url = backend_api_base_url

    if st.button("Clear chat", use_container_width=True):
        st.session_state.chat_history = []
        st.session_state.last_result = None
        st.session_state.chat_session_id = _new_chat_session_id()
        st.rerun()


def render_chat_panel() -> None:
    for message in st.session_state.chat_history:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    if not st.session_state.chat_history:
        with st.chat_message("assistant"):
            st.markdown("Select a semantic model in the sidebar, then ask a question.")

    question = st.chat_input("Use question")
    if not question:
        return

    st.session_state.chat_history.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        response_content = _generate_assistant_response(question)
        st.markdown(response_content)

    st.session_state.chat_history.append(
        {"role": "assistant", "content": response_content}
    )


def get_semantic_model_options() -> list[dict[str, str]]:
    options: list[dict[str, str]] = []

    if DEFAULT_SEMANTIC_MODEL_PATH.exists():
        options.append(
            {
                "key": DEFAULT_ARCHIVE_MODEL_KEY,
                "label": f"Default - {DEFAULT_SEMANTIC_MODEL_PATH.name}",
            }
        )

    for path in list_saved_semantic_model_paths():
        options.append(
            {
                "key": str(path.resolve()),
                "label": path.name,
                "path": str(path.resolve()),
            }
        )

    if not options:
        options.append(
            {
                "key": BUILTIN_MODEL_KEY,
                "label": "Built-in demo model",
            }
        )

    return options


def _ensure_selected_semantic_model_key(
    option_map: dict[str, dict[str, str]]
) -> None:
    selected_key = st.session_state.selected_semantic_model_key
    if selected_key in option_map:
        return
    st.session_state.selected_semantic_model_key = next(iter(option_map))
    st.session_state.loaded_semantic_model_key = None


def _load_selected_semantic_model(
    option_map: dict[str, dict[str, str]]
) -> None:
    selected_key = st.session_state.selected_semantic_model_key
    if st.session_state.loaded_semantic_model_key == selected_key:
        return

    selected_option = option_map[selected_key]
    try:
        st.session_state.semantic_model_text = _read_semantic_model_text(selected_option)
    except OSError as exc:
        raise ValueError(
            f"Could not read semantic model {selected_option['label']}."
        ) from exc

    st.session_state.loaded_semantic_model_key = selected_key
    st.session_state.validation_result = None


def _read_semantic_model_text(option: dict[str, str]) -> str:
    if option["key"] == DEFAULT_ARCHIVE_MODEL_KEY:
        return DEFAULT_SEMANTIC_MODEL_PATH.read_text(encoding="utf-8")
    if option["key"] == BUILTIN_MODEL_KEY:
        return FALLBACK_SEMANTIC_MODEL
    return Path(option["path"]).read_text(encoding="utf-8")


def _generate_assistant_response(question: str) -> str:
    try:
        semantic_model = parse_semantic_model(st.session_state.semantic_model_text)
    except ValueError as exc:
        st.session_state.last_result = None
        return f"**Error**\n\n{exc}"

    try:
        with st.status("Working...", expanded=True) as status:
            for event in chat_turn_stream(
                session_id=st.session_state.chat_session_id,
                message=question,
                semantic_model=semantic_model,
                semantic_model_key=st.session_state.selected_semantic_model_key,
                model=st.session_state.model_name or None,
                debug=st.session_state.debug_enabled,
                base_url=st.session_state.backend_api_base_url,
            ):
                event_type = event.get("type")
                if event_type == "progress":
                    parts = [event.get("message", "")]
                    if event.get("turn_type"):
                        parts.append(f"Turn type: **{event['turn_type']}**")
                    if event.get("context_mode"):
                        parts.append(f"Context: **{event['context_mode']}**")
                    if event.get("resolved_question"):
                        parts.append(f"Question: *{event['resolved_question']}*")
                    if event.get("base_table"):
                        parts.append(f"Base table: **{event['base_table']}**")
                    if event.get("tables"):
                        parts.append("Tables: " + ", ".join(f"`{t}`" for t in event["tables"]))
                    if event.get("joins"):
                        parts.append("Joins: " + " | ".join(f"`{j}`" for j in event["joins"]))
                    if event.get("rationale"):
                        parts.append(f"*{event['rationale']}*")
                    status.write("  \n".join(parts))
                elif event_type == "result":
                    payload = event.get("payload", {})
                    st.session_state.last_result = payload
                    status.update(label="Done", state="complete", expanded=False)
                    return _format_chat_response(payload)
                elif event_type == "error":
                    status.update(label="Failed", state="error", expanded=True)
                    st.session_state.last_result = None
                    return f"**Error**\n\n{event.get('message', 'Unknown error')}"
    except (BackendApiError, Exception) as exc:
        st.session_state.last_result = None
        return f"**Error**\n\n{exc}"

    st.session_state.last_result = None
    return "I could not prepare a response."


def _format_chat_response(result: dict[str, Any]) -> str:
    assistant_message = result.get("assistant_message")
    if isinstance(assistant_message, str) and assistant_message.strip():
        return assistant_message

    sql_result = result.get("sql_result")
    if isinstance(sql_result, dict):
        return _format_sql_result(sql_result)

    return "I could not prepare a response."


def _format_sql_result(result: dict[str, Any]) -> str:
    sections = [f"```sql\n{result.get('sql', '-- SQL not returned.')}\n```"]

    explanation = result.get("explanation")
    if explanation:
        sections.append(explanation)

    warnings = result.get("warnings", [])
    if warnings:
        warning_lines = "\n".join(f"- {warning}" for warning in warnings)
        sections.append(f"**Warnings**\n{warning_lines}")

    return "\n\n".join(sections)


def parse_semantic_model(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Semantic model JSON is invalid: line {exc.lineno}, column {exc.colno}.") from exc
    if not isinstance(parsed, dict):
        raise ValueError("Semantic model JSON must be an object.")
    return parsed


def _persist_uploaded_semantic_model(*, filename: str, payload: bytes) -> Path:
    upload_signature = f"{filename}:{hashlib.sha256(payload).hexdigest()}"
    if (
        st.session_state.last_uploaded_signature == upload_signature
        and st.session_state.last_saved_model_path
    ):
        return Path(st.session_state.last_saved_model_path)

    try:
        semantic_model_text = payload.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError("Uploaded semantic model file must be UTF-8 encoded JSON.") from exc

    saved_path = save_semantic_model_upload(
        filename=filename,
        content=payload,
    )
    st.session_state.semantic_model_text = semantic_model_text
    st.session_state.last_uploaded_signature = upload_signature
    st.session_state.last_saved_model_path = str(saved_path)
    st.session_state.validation_result = None
    return saved_path


def _bootstrap_state() -> None:
    if "backend_api_base_url" not in st.session_state:
        st.session_state.backend_api_base_url = get_backend_api_base_url()
    if "model_name" not in st.session_state:
        st.session_state.model_name = DEFAULT_MODEL
    if "debug_enabled" not in st.session_state:
        st.session_state.debug_enabled = False
    if "semantic_model_text" not in st.session_state:
        st.session_state.semantic_model_text = load_default_semantic_model_text()
    if "validation_result" not in st.session_state:
        st.session_state.validation_result = None
    if "last_uploaded_signature" not in st.session_state:
        st.session_state.last_uploaded_signature = None
    if "last_saved_model_path" not in st.session_state:
        st.session_state.last_saved_model_path = None
    if "selected_semantic_model_key" not in st.session_state:
        if DEFAULT_SEMANTIC_MODEL_PATH.exists():
            st.session_state.selected_semantic_model_key = DEFAULT_ARCHIVE_MODEL_KEY
        else:
            st.session_state.selected_semantic_model_key = BUILTIN_MODEL_KEY
    if "loaded_semantic_model_key" not in st.session_state:
        st.session_state.loaded_semantic_model_key = None
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    if "last_result" not in st.session_state:
        st.session_state.last_result = None
    if "chat_session_id" not in st.session_state:
        st.session_state.chat_session_id = _new_chat_session_id()


def load_default_semantic_model_text() -> str:
    if DEFAULT_SEMANTIC_MODEL_PATH.exists():
        try:
            return DEFAULT_SEMANTIC_MODEL_PATH.read_text(encoding="utf-8")
        except OSError:
            pass
    return FALLBACK_SEMANTIC_MODEL


def _new_chat_session_id() -> str:
    return uuid.uuid4().hex


if __name__ == "__main__":
    main()
