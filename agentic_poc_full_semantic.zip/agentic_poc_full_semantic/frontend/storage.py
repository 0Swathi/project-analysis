from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import re


SEMANTIC_MODEL_STORAGE_DIR = (
    Path(__file__).resolve().parents[1] / "data" / "semantic-models"
)


def get_semantic_model_storage_dir() -> Path:
    SEMANTIC_MODEL_STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    return SEMANTIC_MODEL_STORAGE_DIR


def list_saved_semantic_model_paths(storage_dir: Path | None = None) -> list[Path]:
    target_dir = storage_dir or get_semantic_model_storage_dir()
    if not target_dir.exists():
        return []

    return sorted(
        (path for path in target_dir.glob("*.json") if path.is_file()),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )


def save_semantic_model_upload(
    *,
    filename: str,
    content: bytes,
    storage_dir: Path | None = None,
) -> Path:
    target_dir = storage_dir or get_semantic_model_storage_dir()
    target_dir.mkdir(parents=True, exist_ok=True)

    safe_stem = _sanitize_stem(Path(filename).stem) or "semantic-model"
    suffix = ".json"
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    candidate = target_dir / f"{safe_stem}-{timestamp}{suffix}"

    counter = 1
    while candidate.exists():
        candidate = target_dir / f"{safe_stem}-{timestamp}-{counter}{suffix}"
        counter += 1

    candidate.write_bytes(content)
    return candidate


def _sanitize_stem(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip()).strip("-._")
    return cleaned.lower()
