# Plan: SSE Streaming + Faster Orchestration Model

## Context

Every chat turn makes 3 sequential blocking LLM calls — Memory Reasoner → Asset Selector → SQL Generator — all using the same heavy model (`gpt-5.4`). Total wall-clock time is ~50s+. The single HTTP connection idles for that entire duration, causing `ReadTimeout` errors in the Streamlit frontend.

Two permanent fixes applied together:
1. **SSE streaming** — stream progress events back as each pipeline stage completes; the HTTP connection stays alive regardless of total duration, and the user sees live progress
2. **Faster orchestration model** — Memory Reasoner and Asset Selector are lightweight structured-output classification tasks; use `gpt-4o-mini` for them; only SQL Generator keeps the heavy model

---

## Files to Change (in implementation order)

| # | File | What changes |
|---|------|-------------|
| 1 | `backend/app/core/config.py` | Add `openai_memory_model` field |
| 2 | `backend/app/llm/openai_client.py` | Suppress `reasoning` block for non-reasoning models |
| 3 | `backend/app/memory/reasoner.py` | Default client uses `openai_memory_model`, no reasoning effort |
| 4 | `backend/app/services/asset_selector_service.py` | Same as step 3 |
| 5 | `backend/app/memory/graph.py` | Add `stream_events()` method |
| 6 | `backend/app/services/chat_session_service.py` | Add `handle_turn_stream()` generator, extract `_build_response_from_graph_result()` helper |
| 7 | `backend/app/api/routes/chat.py` | Add `POST /turn/stream` returning `StreamingResponse` |
| 8 | `frontend/api_client.py` | Add `chat_turn_stream()` with `stream=True` + SSE parsing |
| 9 | `frontend/app.py` | Replace blocking call with streaming loop + `st.status()` |
| 10 | `docker-compose.yml` | Add `OPENAI_MEMORY_MODEL` env var |

Steps 3+4 are independent (parallel). Steps 8+9 are independent of backend steps.

---

## Step-by-Step Implementation

### Step 1 — `backend/app/core/config.py`

Add one field to `Settings` dataclass after `openai_model`:
```python
openai_memory_model: str
```

Add to `from_env()` after the `openai_model=` line:
```python
openai_memory_model=os.getenv("OPENAI_MEMORY_MODEL", "gpt-4o-mini").strip(),
```

---

### Step 2 — `backend/app/llm/openai_client.py` ⚠️ Required before Step 3/4

**Critical bug:** `gpt-4o-mini` rejects the `{"reasoning": {"effort": "medium"}}` payload field with HTTP 400. The client currently sends it unconditionally.

Add a module-level predicate and gate the payload:
```python
_NO_REASONING_PREFIXES = ("gpt-4o-mini", "gpt-3.5", "gpt-4-turbo")

def _model_supports_reasoning(model: str) -> bool:
    return not any(model.startswith(p) for p in _NO_REASONING_PREFIXES)
```

In `generate_json()`, replace:
```python
if self.reasoning_effort:
    payload["reasoning"] = {"effort": self.reasoning_effort}
```
with:
```python
effective_model = model or self.model
if self.reasoning_effort and _model_supports_reasoning(effective_model):
    payload["reasoning"] = {"effort": self.reasoning_effort}
```
Also change `"model": model or self.model` to use `effective_model`.

---

### Step 3 — `backend/app/memory/reasoner.py`

In `OpenAIMemoryReasoner.__init__`, change the default client construction:
```python
self.client = client or OpenAIResponsesClient(
    settings=self.settings,
    model=self.settings.openai_memory_model,  # was: self.settings.openai_model
    reasoning_effort=None,                    # gpt-4o-mini doesn't support reasoning
)
```

The per-call `model` override still flows through to `generate_json(model=model)` unchanged.

---

### Step 4 — `backend/app/services/asset_selector_service.py`

Same change as Step 3:
```python
self.client = client or OpenAIResponsesClient(
    settings=self.settings,
    model=self.settings.openai_memory_model,
    reasoning_effort=None,
)
```

---

### Step 5 — `backend/app/memory/graph.py`

Add `stream_events()` to `MemoryWrapperGraph`. Uses `self._graph.stream()` (LangGraph built-in, yields `{node_name: state_diff}` per completed node).

```python
_NODE_PROGRESS_AFTER: dict[str, dict] = {
    "reason_turn":   {"type": "progress", "stage": "select_assets",        "message": "Selecting data assets..."},
    "select_assets": {"type": "progress", "stage": "invoke_sql_generation", "message": "Generating SQL..."},
}

def stream_events(self, state: GraphTurnState) -> Generator[str, None, None]:
    def _sse(payload: dict) -> str:
        return f"data: {json.dumps(payload)}\n\n"

    yield _sse({"type": "progress", "stage": "reason_turn", "message": "Analyzing your question..."})

    try:
        final_state: dict = {}
        for chunk in self._graph.stream(state.model_dump(mode="python")):
            for node_name, node_output in chunk.items():
                final_state.update(node_output)
                if node_name in self._NODE_PROGRESS_AFTER:
                    yield _sse(self._NODE_PROGRESS_AFTER[node_name])

        allowed = set(GraphTurnState.model_fields)
        graph_result = GraphTurnState.model_validate(
            {k: v for k, v in final_state.items() if k in allowed}
        )
        yield _sse({"type": "result", "payload": graph_result.model_dump(mode="python")})
    except Exception as exc:
        yield _sse({"type": "error", "message": str(exc)})
```

Also update the `GraphInvoker` Protocol to add:
```python
def stream_events(self, state: GraphTurnState) -> Generator[str, None, None]: ...
```

**Clarification branch note:** When `reason_turn` routes to `respond_with_clarification`, `select_assets` never fires — its progress event is skipped. Stream goes directly `progress(reason_turn)` → `result`. This is correct UX.

---

### Step 6 — `backend/app/services/chat_session_service.py`

1. Extract the response-assembly logic from `handle_turn()` (lines ~113–160) into a private helper:
```python
def _build_response_from_graph_result(
    self, *, graph_result: GraphTurnState, request: ChatTurnRequest,
) -> ChatTurnResponse:
    # move existing assembly logic here
```

2. Refactor `handle_turn()` to call `_build_response_from_graph_result()`.

3. Add `handle_turn_stream()` generator:
```python
def handle_turn_stream(self, request: ChatTurnRequest) -> Generator[str, None, None]:
    def _sse(d: dict) -> str:
        return f"data: {json.dumps(d)}\n\n"

    try:
        adapted = self.semantic_model_service.normalize_or_raise(request.semantic_model)
        normalized = adapted.semantic_model.model_dump(mode="python", exclude_none=True)
        resolved_key = request.semantic_model_key or adapted.semantic_model.name
    except Exception as exc:
        yield _sse({"type": "error", "message": str(exc)})
        return

    graph_state = GraphTurnState(
        session_id=request.session_id,
        incoming_message=request.message,
        semantic_model=normalized,
        semantic_model_key=resolved_key,
        model=request.model,
        memory_model=request.memory_model,
        debug=request.debug,
    )
    result_payload = None

    for raw in self.graph.stream_events(graph_state):
        event = json.loads(raw[len("data: "):].strip())
        if event.get("type") == "result":
            result_payload = event["payload"]
        else:
            yield raw  # forward progress/error events unchanged

    if result_payload is None:
        yield _sse({"type": "error", "message": "No result produced."})
        return

    graph_result = GraphTurnState.model_validate(result_payload)
    response = self._build_response_from_graph_result(
        graph_result=graph_result, request=request
    )
    yield _sse({"type": "result", "payload": response.model_dump(mode="python")})
```

---

### Step 7 — `backend/app/api/routes/chat.py`

Add new sync endpoint (sync `def` so FastAPI runs it in a thread executor):
```python
from fastapi.responses import StreamingResponse

@router.post("/turn/stream")
def chat_turn_stream(
    request: ChatTurnRequest,
    service: ChatSessionService = Depends(get_chat_session_service),
) -> StreamingResponse:
    return StreamingResponse(
        service.handle_turn_stream(request),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
```

The existing `POST /turn` endpoint is untouched — no breaking changes.

---

### Step 8 — `frontend/api_client.py`

Add `chat_turn_stream()`:
```python
import json
from collections.abc import Generator

def chat_turn_stream(
    *,
    session_id: str,
    message: str,
    semantic_model: dict[str, Any],
    semantic_model_key: str | None,
    model: str | None,
    debug: bool,
    base_url: str,
    memory_model: str | None = None,
    timeout_seconds: int = 300,
) -> Generator[dict[str, Any], None, None]:
    response = requests.post(
        f"{base_url}/api/v1/chat/turn/stream",
        json={
            "session_id": session_id,
            "message": message,
            "semantic_model": semantic_model,
            "semantic_model_key": semantic_model_key,
            "model": model,
            "memory_model": memory_model,
            "debug": debug,
        },
        stream=True,
        timeout=timeout_seconds,
    )
    if not response.ok:
        try:
            payload = response.json()
            error_msg = (payload.get("error") or {}).get("message") or f"HTTP {response.status_code}"
        except ValueError:
            error_msg = f"HTTP {response.status_code}"
        raise BackendApiError(error_msg)

    for line in response.iter_lines(decode_unicode=True):
        if not line or not line.startswith("data: "):
            continue
        try:
            yield json.loads(line[len("data: "):])
        except json.JSONDecodeError:
            continue
```

---

### Step 9 — `frontend/app.py`

Add import for `chat_turn_stream` alongside `chat_turn` in both import paths.

Replace `_generate_assistant_response()` with:
```python
def _generate_assistant_response(question: str) -> str:
    try:
        semantic_model = parse_semantic_model(st.session_state.semantic_model_text)
    except ValueError as exc:
        return f"**Error**\n\n{exc}"

    try:
        with st.status("Working...", expanded=True) as status:
            for event in chat_turn_stream(
                session_id=st.session_state.chat_session_id,
                message=question,
                semantic_model=semantic_model,
                semantic_model_key=st.session_state.selected_semantic_model_key,
                model=st.session_state.model_name or None,
                debug=st.session_state.debug_enabled,
                base_url=st.session_state.backend_api_base_url,
            ):
                if event["type"] == "progress":
                    status.write(event["message"])
                elif event["type"] == "result":
                    st.session_state.last_result = event["payload"]
                    final = _format_chat_response(event["payload"])
                    status.update(label="Done", state="complete", expanded=False)
                    return final
                elif event["type"] == "error":
                    status.update(label="Failed", state="error")
                    return f"**Error**\n\n{event['message']}"
    except (BackendApiError, Exception) as exc:
        return f"**Error**\n\n{exc}"

    return "I could not prepare a response."
```

The call site in `render_chat_panel()` is unchanged — same function name, same `st.markdown()` afterwards.

---

### Step 10 — `docker-compose.yml`

Add to backend `environment` block:
```yaml
OPENAI_MEMORY_MODEL: ${OPENAI_MEMORY_MODEL:-gpt-4o-mini}
```

---

## SSE Event Flow

```
Client connects → server immediately yields:
  data: {"type": "progress", "stage": "reason_turn",        "message": "Analyzing your question..."}

  [Memory Reasoner LLM call ~5s with gpt-4o-mini]

  data: {"type": "progress", "stage": "select_assets",       "message": "Selecting data assets..."}

  [Asset Selector LLM call ~5s with gpt-4o-mini]

  data: {"type": "progress", "stage": "invoke_sql_generation","message": "Generating SQL..."}

  [SQL Generator LLM call ~20s with gpt-5.4]

  data: {"type": "result", "payload": { ...ChatTurnResponse... }}
```

If clarification is needed, the stream skips straight from the first progress event to the result.

---

## Verification

1. `Settings.from_env()` defaults `openai_memory_model="gpt-4o-mini"`, reads `OPENAI_MEMORY_MODEL` env var
2. `generate_json(model="gpt-4o-mini")` — captured request body must NOT contain `reasoning` key
3. `graph.stream_events()` with fakes — assert event sequence: `progress` × 3 → `result`
4. Clarification branch — assert only `progress(reason_turn)` → `result(clarification_required=True)`
5. Error propagation — fake reasoner raises → generator yields `type=error`, terminates cleanly
6. `curl -N -X POST .../chat/turn/stream` — verify `data:` lines arrive incrementally
7. Browser E2E — `st.status()` shows live stages, collapses to "Done" with SQL result
8. Regression — `POST /chat/turn` (non-streaming) still returns same response shape
