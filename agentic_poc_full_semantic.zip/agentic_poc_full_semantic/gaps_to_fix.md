# Gaps to Fix

Goal: generate high-quality SQL queries that sustain context awareness at low cost and minimum time.

Priority order:
1. SQL quality — correct, complete, matches user intent
2. Context awareness — follow-ups, topic switches, historical callbacks work correctly
3. Cost — minimum tokens per turn, compact accurate state
4. Speed — fewer and smaller LLM calls

Status legend: `open` | `decided` | `fixed`

---

## Context Engineering

| # | Gap | Status | Decision |
|---|-----|--------|----------|
| CE-1 | Reasoner prompt dumps full `active_context` including duplicate thin fields AND nested `analytical_context` — same data sent twice after Gap #8 fix | open | — |
| CE-2 | Snapshot dumps in reasoner prompt are full 20-field objects; reasoner only needs 4-5 fields (`snapshot_id`, `topic_label`, `summary`, `metric`, `dataset_name`) | open | — |
| CE-3 | Asset selector prompt has the same full-dump problem as CE-1 and CE-2 | open | — |
| CE-4 | `recent_messages` window is 6 for reasoner and 4 for asset selector — larger than needed for classification | open | — |
| CE-5 | `rolling_summary` field exists in `SessionMemory` but is never written — always null in every prompt | open | — |
| CE-6 | No prompt differentiation by turn type — fresh, follow-up, and historical callback all go through the same full pipeline with the same token load | open | — |

---

## Architecture

| # | Gap | Status | Decision |
|---|-----|--------|----------|
| AR-1 | Asset selector re-selects tables from scratch every turn even when tables haven't changed; for follow-ups a delta-only or plan-reuse approach would be cheaper | open | — |
| AR-2 | Three LLM calls per turn minimum with no skip path; reasoner + asset selector + SQL generator fire unconditionally every turn | open | — |
| AR-3 | Reasoner and asset selector make independent table decisions — reasoner sets `state_patch.tables`, asset selector independently sets `AssetSelectionPlan`; if they disagree the SQL generator silently gets the asset selector's version | open | — |
| AR-4 | No SQL caching — same question asked twice in a session runs all 3 LLM calls again | open | — |
| AR-5 | Sessions don't survive backend restarts — `InMemorySessionStore` is process-local only | open | — |

---

## Reasoner Design

| # | Gap | Status | Decision |
|---|-----|--------|----------|
| RD-1 | Turn classification is binary with no confidence score — a barely-ambiguous question gets the same treatment as an obvious one; wrong classifications produce wrong SQL silently | open | — |
| RD-2 | Long follow-up chains can drift undetected — no mechanism to detect that `active_context` has semantically drifted after 15+ follow-ups | open | — |
| RD-3 | `active_context.last_turn_type` is stored but never used by the reasoner to apply stricter rules on long follow-up chains | open | — |

---

## SQL Generation

| # | Gap | Status | Decision |
|---|-----|--------|----------|
| SG-1 | Follow-up edit mode may not reliably trigger — `followup_edit` prompt mode requires `previous_sql` to be threaded through correctly; if `last_sql` is null for any reason it silently falls back to full schema generation | open | — |
| SG-2 | Retry loop re-sends full schema on each validation-failure attempt instead of sending only the violations + prior SQL | open | — |
| SG-3 | Full-schema fallback when asset selection fails (Gap #5 fallback) degrades SQL quality silently — no warning logged about quality risk | open | — |
| SG-4 | No semantic validation of SQL output — `SqlPlanValidator` checks structural correctness (right tables used) but not semantic correctness (right metric aggregated, right filters applied) | open | — |

---

## Validation

| # | Gap | Status | Decision |
|---|-----|--------|----------|
| VA-1 | `SqlPlanValidator` verifies that joined tables are in the plan but does not verify that join conditions match the plan's declared join field definitions | open | — |
| VA-2 | CTE presence silently skips the base-table ordering check — documented known quirk but could mask real violations if a CTE shadows a real table name | open | — |

---

## Cost & Performance

| # | Gap | Status | Decision |
|---|-----|--------|----------|
| CP-1 | Asset selector uses the expensive SQL model (`gpt-5.4`) as fallback when no `memory_model` override is set — both reasoner and asset selector are cheap decision calls and should use the cheap model | open | — |
| CP-2 | Retry/backoff status on `OpenAIResponsesClient` — original audit flagged this as missing but current file appears to have retry logic; needs verification | open | — |
| CP-3 | `ChatSessionService.reasoner` is `None` when a graph is injected via the `graph=` parameter — any code accessing `service.reasoner` directly gets a `NoneType` error with no clear message | open | — |
| CP-4 | Context window protection in `SqlPromptBuilder` only covers 3 model IDs (`gpt-5.4`, `gpt-5.4-pro`); any other model silently uses a conservative fallback with no warning | open | — |
| CP-5 | Reasoning-capable model detection uses a hardcoded prefix list `_NO_REASONING_PREFIXES` — new models not in the list get wrong behavior silently | open | — |
| CP-6 | `assert` statements guard runtime invariants in the generation loop — Python's `-O` flag silently disables them; should be explicit `if not ... raise` guards | open | — |
| CP-7 | No partial result caching across retries — a turn that fails on LLM call 3 discards calls 1 and 2; on client retry all 3 run again | open | — |
| CP-8 | No OpenAI prompt caching — system prompts and semantic model schema are re-sent verbatim on every call; prompt prefix caching would cut costs on long sessions | open | — |

---

## Already Fixed (from previous sessions)

| # | Gap | What was done |
|---|-----|---------------|
| F-1 | Double SHA-256 hash per turn | Computed once in service, passed via `GraphTurnState.semantic_model_fingerprint`, reused in graph |
| F-2 | Snapshot picker was positional (oldest + 2 newest) | Replaced with keyword overlap scoring; anchors oldest; breaks ties by recency; deduplicates |
| F-3 | Snapshot eviction was silent | Added WARNING log naming evicted snapshot IDs when cap is exceeded |
| F-4 | One LLM blip killed the whole turn | Wrapped reasoner and asset selector in try/except with fallback to fresh / empty plan |
| F-5 | Fragile SemanticChangeRequest type coercion | Added `_coerce_semantic_change_request()` with proper isinstance chain |
| F-6 | `last_sql_result` dead field in SessionMemory | Removed the field entirely |
| F-7 | Sessions lived forever (memory leak) | Added TTL eviction to `InMemorySessionStore` with `time.monotonic()` tracking |
| F-8 | Two parallel memory shapes synced manually | `ActiveContext._sync_thin_fields()` auto-fires via `model_post_init` + `__setattr__` override |
| F-9 | `state_patch` was an untyped dict | Added `StatePatch` Pydantic model; 3 merge functions use typed attribute access |
| F-10 | `_select_relationships` key mismatch dropped all relationships when no `selected_joins` (else branch) | Short vs qualified name mismatch; fixed with `short_keys` set in else branch |
| F-11 | Projected model missing join endpoint tables — asset selector returns joins referencing tables not in `selected_tables`; projection service dropped all those joins, leaving 0 relationships and triggering "no declared relationships" warning | `_select_tables` now auto-adds any table referenced in `selected_joins` that is absent from `selected_tables`, ensuring the projected model is internally consistent |
| F-12 | Declared relationships between selected tables dropped when `selected_joins` is present — `if selected_joins` branch only processed explicit joins, never looked at `semantic_model.relationships`; so if A+B were selected but their declared relationship wasn't in `selected_joins`, it was silently dropped | After processing `selected_joins`, also scan `semantic_model.relationships` for any declared relationship where both endpoint tables are in the projected model; deduplication ensures no double-counting |
